﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJPOK
{
    public class IndividualMovements
    {
        Movements typemovement;

        public IndividualMovements(Movements movements)
        {
            typemovement = movements;
        }
        //List<IndividualMovements> Movement = new List<IndividualMovements>();
        //IndividualMovements pound = new IndividualMovements("Destructor", 1, 35, 40, 100, false, "P");
        public IndividualMovements Pound()
        {
            Movements typemovement = new Movements("Destructor", 1, 35, 40, 100, false, "P");
            IndividualMovements single = new IndividualMovements(typemovement);
            return single;
        }
        public IndividualMovements KarateChop()
        {
            Movements typemovement = new Movements("Golpe Karate", 2, 25, 50, 100, false, "P");
            IndividualMovements single = new IndividualMovements(typemovement);
            return single;
        }    
        public IndividualMovements DoubleSlap()
        {
            Movements typemovement = new Movements("Doble Bofetón", 3, 10, 30, 85, false, "P");
            IndividualMovements single = new IndividualMovements(typemovement);
            return single;
        }
        public IndividualMovements CometPunch()
        {
            Movements typemovement = new Movements("Puño Cometa", 4, 15, 32, 85, false, "P");
            IndividualMovements single = new IndividualMovements(typemovement);
            return single;
        }
        public IndividualMovements MegaPunch()
        {
            Movements typemovement = new Movements("Mega Puño", 5, 20, 80, 100, false, "P");
            IndividualMovements single = new IndividualMovements(typemovement);
            return single;
        }
        public IndividualMovements PayDay()
        {
            Movements typemovement = new Movements("Dia De Pago", 6, 20, 40, 100, false, "P");
            IndividualMovements single = new IndividualMovements(typemovement);
            return single;
        }
        public IndividualMovements FirePunch()
        {
            Movements typemovement = new Movements("Puño Fuego", 7, 15, 75, 100, false, "P");
            IndividualMovements single = new IndividualMovements(typemovement);
            return single;
        }
        public IndividualMovements IcePunch()
        {
            Movements typemovement = new Movements("Puño Hielo", 8, 15, 75, 100, false, "P");
            IndividualMovements single = new IndividualMovements(typemovement);
            return single;
        }
        public IndividualMovements ThunderPunch()
        {
            Movements typemovement = new Movements("Puño Trueno", 9, 15, 75, 100, false, "P");
            IndividualMovements single = new IndividualMovements(typemovement);
            return single;
        }
        public IndividualMovements WingAttack()
        {
            Movements typemovement = new Movements("Ataque Ala", 17, 35, 60, 100, false, "P");
            IndividualMovements single = new IndividualMovements(typemovement);
            return single;
        }
        public IndividualMovements RapidAttack()
        {
            Movements typemovement = new Movements("Ataque Rápido", 98, 30, 40, 100, true, "P");
            IndividualMovements single = new IndividualMovements(typemovement);
            return single;
        }
        public IndividualMovements ExtremeSpeed()
        {
            Movements typemovement = new Movements("Velocidad Extrema", 245, 5, 80, 100, true, "P");
            IndividualMovements single = new IndividualMovements(typemovement);
            return single;
        }
        public IndividualMovements RazorWind()
        {
            Movements typemovement = new Movements("Viento Cortante", 13, 10, 80, 100, true, "E");
            IndividualMovements single = new IndividualMovements(typemovement);
            return single;
        }
    }
}
