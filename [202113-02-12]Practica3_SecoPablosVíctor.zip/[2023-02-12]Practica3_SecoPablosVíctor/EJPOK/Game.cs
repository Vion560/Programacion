﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace EJPOK
{
    public class Game
    {
        public void Run()
        {
            IndividualPokemon pokemon = new IndividualPokemon();
            IndividualPokemon[] introPokemon = StarterPokemon(pokemon);
            IndividualPokemon[] team = MyTeam(pokemon);
            IndividualPokemon[] enemypok = EnemyPokemon(pokemon);            
            Teacher(introPokemon,team);
            ShowMenu();
            MainMenu(team,enemypok);
        }
        Random randomvalue = new Random();
        int[] numrandom = new int[5];
        IO iO;
        int maxhp;
        int specienum;
        int actualhp;
        int attack;
        int defense;
        int speed;
        int saveenemypok;
        int damage;
        int crit;
        float rcm;
        int asknumber;
        float ratiocapture;
        int death = 0;
        bool catched;
        int attemps = 1;
        bool finished = false;
        Trainer trainer = new Trainer();
        Bag bag = new Bag();
        Item item = new Item();

        public Game(IO iO)
        {
            this.iO = iO;
        }
        public IndividualPokemon[] StarterPokemon(IndividualPokemon pokemon) //lista de los pokemon iniciales para elegir uno
        {
            IndividualPokemon[] starterpok = new IndividualPokemon[3];
            starterpok[0] = pokemon.Charmander();
            starterpok[1] = pokemon.Bulbasaur();
            starterpok[2] = pokemon.Squirtle();
            return starterpok;
        }
        public IndividualPokemon[] MyTeam(IndividualPokemon pokemon) //lista de los pokemon iniciales para elegir uno
        {

            IndividualPokemon[] teammates = new IndividualPokemon[6];
            return teammates;
        }

        public IndividualPokemon[] EnemyPokemon(IndividualPokemon pokemon) //lista de los rivales pokemon rivales posibles
        {

            IndividualPokemon[] enemypokemon = new IndividualPokemon[22];
            enemypokemon[0] = pokemon.Bulbasaur();
            enemypokemon[1] = pokemon.Ivysaur();
            enemypokemon[2] = pokemon.Venusaur();
            enemypokemon[3] = pokemon.Charmander();
            enemypokemon[4] = pokemon.Charmeleon();
            enemypokemon[5] = pokemon.Charizard();
            enemypokemon[6] = pokemon.Squirtle();
            enemypokemon[7] = pokemon.Wartortle();
            enemypokemon[8] = pokemon.Blastoise();
            enemypokemon[9] = pokemon.Caterpie();
            enemypokemon[10] = pokemon.Metapod();
            enemypokemon[11] = pokemon.Butterfree();
            enemypokemon[12] = pokemon.Weedle();
            enemypokemon[13] = pokemon.Kakuna();
            enemypokemon[14] = pokemon.Beedrill();
            enemypokemon[15] = pokemon.Pidgey();
            enemypokemon[16] = pokemon.Pidgeotto();
            enemypokemon[17] = pokemon.Pidgeot();
            enemypokemon[18] = pokemon.Rattata();
            enemypokemon[19] = pokemon.Raticate();
            enemypokemon[20] = pokemon.Spearow();
            enemypokemon[21] = pokemon.Fearow();
            return enemypokemon;
        }
        public IndividualMovements[] Movements(IndividualMovements move)
        {
            IndividualMovements[] movement = new IndividualMovements[12];
            movement[0] = move.Pound();
            movement[1] = move.KarateChop();
            movement[2] = move.DoubleSlap();
            movement[3] = move.CometPunch();
            movement[4] = move.MegaPunch();
            movement[5] = move.PayDay();
            movement[6] = move.FirePunch();
            movement[7] = move.IcePunch();
            movement[8] = move.ThunderPunch();
            movement[9] = move.WingAttack();      //Luego cambiar posicion, solo estan para prueba
            movement[10] = move.RapidAttack();    //Luego cambiar posicion, solo estan para prueba
            movement[11] = move.ExtremeSpeed();   //Luego cambiar posicion, solo estan para prueba
            movement[12] = move.RazorWind();      //Luego cambiar posicion, solo estan para prueba
            return movement;
        }

        public void Teacher(IndividualPokemon[] starter,IndividualPokemon[] team) //Esta es la opción para que el profe te de la bienvenida
        {
            iO.WriteCyan(" Hola, soy el profesor Ciprés. Bienvenido al mundo pokemon donde encontrarás muchos tipos de pokemon. \n");
            iO.WriteCyan("Primero dime tu nombre porfavor \n");
            string playername = iO.AskString();
            trainer.SetName(playername);
            iO.WritePink(" Dime tu género entre chico,chica o chique\n");
            string gender = iO.AskString();
            trainer.SetGender(gender);
            if (gender != "chico" && gender != "chica" && gender != "chique")
            {
                do
                {
                    iO.Write("Por favor elige una de las tres opciones");
                    gender = iO.AskString();
                    trainer.SetGender(gender);
                }
                while (gender != "chico" && gender != "chica" && gender != "chique");
            }
            else
            {
                trainer.SetGender(gender);
            }
            iO.WriteCyan(" Ahora elige: 0 si tu continente es Europa, 1 para Norte América, 2 Asia-Australia, 3 África o 4 Sur América\n");
            int Continent = iO.AskNumber();
            int a = GetId(Continent);
            trainer.SetId(a);
            GiveMoney(); //da los tipos de monedas al principio
            RandomNum();
            iO.Write("Para empezar tienes que elegir entre uno de estos tres pokemon y el que eligas te lo puedes quedar y puedas empezar con él tu aventura\n");
            iO.ThreadColorsRed(" Opción 1: Charmander.\n");
            iO.ThreadColorsGreen(" Opción 2: Bulbasaur.\n");
            iO.ThreadColorsBlue(" Opción 3: Squirtle.\n");
            iO.ThreadColorsWhite(" Elige un número\n");
            ChooseOne(starter, team);
        }
        public void NoTeacher() //Opción en la que directamente empiezas con un pokemon aleatorio
        {
            Console.WriteLine("Elige un pokemón: \n");
            iO.ThreadColorsRed(" Opción 1: Charmander.\n");
            iO.ThreadColorsGreen(" Opción 2: Bulbasaur.\n");
            iO.ThreadColorsBlue(" Opción 3: Squirtle.\n");
            iO.Write("\n");
        }
        public int GetId(int cont)
        {
            if (cont == 0)
            {
                int myid = randomvalue.Next(0000000000, 0999999999);
                return myid;
            }
            if (cont == 1)
            {
                int myid = randomvalue.Next(1000000000, 1999999999);
                return myid;
            }
            if (cont == 2)
            {
                int myid = randomvalue.Next(2000000000, 299999999);
                return myid;
            }
            if (cont == 3)
            {
                int myid = randomvalue.Next(300000000, 399999999);
                return myid;
            }
            //if (cont == 4)
            //{
            //    int myid = randomvalue.Next(4000000000, 4999999999);
            //    return myid;
            //}
            else
            {
                return 1000000000;
            }
        }
        public void GiveMoney()
        {
            trainer.SetBattlePoints(1000);
            trainer.SetPokedolLars(1000);
            trainer.SetPokemillas(1000);
        }
        public void ChooseOne(IndividualPokemon[] starter, IndividualPokemon[] team) //elige el starter y lo guarda en la bolsa
        {
            iO.Write("Escriba el número 1, 2 o 3");
            int num = iO.AskNumber();
            ChooseStarter(starter, team,num);
        }
        public int RandomNum()
        {
            int num = randomvalue.Next(000000000, 999999999);
            return num;
        }
        public void AddToShop() //añade objetos a la tienda
        {
            Item potion = new Item("Potion", 10000, 300, 150);
            bag.AddItemKit(potion); //en vez de bag es tienda
            Item superpotion = new Item("Superpotion", 10000, 700, 350);
            bag.AddItemKit(superpotion);
            Item hiperpotion = new Item("Hiperpotion", 10000, 1200, 600);
            bag.AddItemKit(hiperpotion);
            Item maxpotion = new Item("Maxpotion", 10000, 2500, 1250);
            bag.AddItemKit(maxpotion);
            Item restoreall = new Item("RestoreAll", 10000, 3000, 1500);
            bag.AddItemKit(restoreall);
        }
        public void AddToBag() //añade objetos a la mochila
        {
            //bag.AddItemKit(potion);
        }
        public void OpenBag()
        {
            bag.HaveItemKit(item);
            bag.HaveItemMovements(item);
            bag.HaveItemOthers(item);
            bag.HaveItemPokeballs(item);
            bag.HaveItemKeyObjects(item);
            bag.HaveItemTreasures(item);
            bag.HaveItemCombatobjects(item);
        }
        public void ShowMenu() //muestra el menú por pantalla
        {
            iO.ThreadColorsGreen(" Menu:\n");
            iO.ThreadColorsGreen("	Pulsa 1 para ver tus datos como entrenador\n");
            iO.ThreadColorsGreen("	Pulsa 2 para ver los datos de tus pokemon\n");
            iO.ThreadColorsGreen("	Pulsa 3 para Combatir\n");
            iO.ThreadColorsGreen("	Pulsa 4 centro pokemon\n");
            iO.ThreadColorsGreen("	Pulsa 5 abrir la mochila\n");
            iO.ThreadColorsGreen("	Pulsa 6 para salir \n");
            iO.ThreadColorsWhite("\n");
        }
        public void MainMenu(IndividualPokemon[] team,IndividualPokemon[] enemy)
        {
            int opcion = iO.AskNumber();
            switch (opcion)
            {
                case 1:
                    GetTrainerInfo();
                    ExitToMenu(team, enemy);
                    break;
                case 2:
                    BasicStats(team,enemy);
                    ExitToMenu(team, enemy);
                    break;
                case 3:
                    WhichEnemyPokemon(enemy);
                    Fight(team, enemy);
                    break;
                case 4:
                    PokCenter(team, enemy);
                    iO.Write("	Pulsa 4 centro pokemon");
                    ExitToMenu(team, enemy);
                    break;
                case 5:
                    break;
                case 6:
                    iO.Write("Escriba 1 para cerrar el juego definitivamente o 2 para volver al menú");
                    FinishGame(team, enemy);
                    break;

            }
        }
        public void FinishGame(IndividualPokemon[] team, IndividualPokemon[] enemy) //opción para cerrar el juego o no
        {
            int num = iO.AskNumber();         
            switch (num)
            {
                case 1: //para cerrar el juego
                    Environment.Exit(0);
                    break;
                case 2: //volver al menu
                    ExitToMenu(team, enemy);
                    break;
            }
        }
        public void WhichEnemyPokemon(IndividualPokemon[] enemypok)
        {
            int num = randomvalue.Next(0, enemypok.Length);
        }
        public void ChooseStarter(IndividualPokemon[] starterpok, IndividualPokemon[] team,int num) //elige el starter y lo guarda en la bolsa
        {
            //num = iO.AskNumber();
            switch (num)
            {
                case 1:
                    team[0] = starterpok[0];
                    team[0].SetActualHp(starterpok[0].GetMaxHp());
                    iO.Write("Quieres darle un mote a Charmander? Pulsa 1 para si y 2 para no");
                    int n = iO.AskNumber();
                    switch (n)
                    {
                        case 1:
                            string name = iO.AskString();
                            team[0].SetPokName(name);
                            break;
                        case 2:
                            break;
                    }
                    break;
                case 2:
                    team[0] = starterpok[1];
                    team[0].SetActualHp(starterpok[1].GetMaxHp());
                    iO.Write("Quieres darle un mote a Bulbasaur? Pulsa 1 para si y 2 para no");
                    int n1 = iO.AskNumber();
                    switch (n1)
                    {
                        case 1:
                            string name = iO.AskString();
                            team[0].SetPokName(name);
                            break;
                        case 2:
                            break;
                    }
                    break;
                case 3:
                    team[0] = starterpok[2];
                    team[0].SetActualHp(starterpok[2].GetMaxHp());
                    iO.Write("Quieres darle un mote a Squirtle? Pulsa 1 para si y 2 para no");
                    int n2 = iO.AskNumber();
                    switch (n2)
                    {
                        case 1:
                            string name = iO.AskString();
                            team[0].SetPokName(name);
                            break;
                        case 2:
                            break;
                    }
                    break;
                default:
                    iO.Write("Por favor eliga una opción correcta");
                    //ChooseStarter(StarterPokemon, MyTeam);
                    break;
            }
        }
        public void Fight(IndividualPokemon[] team, IndividualPokemon[] enemypok) //Combate
        {
                    iO.Write("Va a comenzar el Menú pelea, que pokemon quieres escoger como primero?");
                    ShowPokemons(team);
                    asknumber = iO.AskNumber();
                    iO.Write("Has escogido a " + team[asknumber].GetName());
                    iO.Write("Pulsa 1 para Comenzar la pelea");
                    iO.Write("Pulsa 2 para cambiar pokemon");
                    iO.Write("Pulsa 3 para ver la Mochila");
                    iO.Write("Pulsa 4 para Capturar");
                    iO.Write("Pulsa 5 para Volver al menú");
                    int num = iO.AskNumber();
                    int num2 = randomvalue.Next(0, enemypok.Length);
                    saveenemypok = num2;
                    switch (num)
                    {
                        case 1: //atacar
                            if (team[asknumber].GetSpeed() >= enemypok[num2].GetSpeed())
                            {
                                int enemy = enemypok[num2].GetActualHp();
                                int ally = team[asknumber].GetActualHp();
                                iO.WriteYellow("\n");
                                iO.Write(" Tu pokemon "+team[asknumber].GetName()+ " ha empezado el combate con " + ally + " de vida\n ");
                                iO.Write(" El pokemon enemigo "+enemypok[num2].GetName()+ " ha empezado el combate con " + enemy + " de vida\n ");
                                do
                                {
                                    iO.Write(" Pulsa el número 1 si quieres volver a atacar, 2 para cambiar pokemon, 3 para mochila y 4 para capturar \n");
                                    int number = iO.AskNumber();
                                    switch (number)
                                    {
                                        case 1:
                                            enemy = enemy - GetDamage(team,enemypok);
                                            CheckEnemyDeath(team, enemy,ally, num2,asknumber, enemypok);
                                            iO.Write("El pokemon enemigo ha sido atacado y tiene " + enemy + " puntos de vida");
                                            break;
                                        case 2: //cambia de pokemon
                                            ChangePok(team);
                                            break;
                                        case 3: //Mochila                 
                                            break;
                                        case 4: //capturar
                                            Capture(team,enemypok);
                                            break;
                                        case 5: //Escapar, ya que mi pokemon es más rápido no hace falta una funcion
                                            iO.Write("Has conseguido escapar!");    
                                            ExitToMenu(team,enemypok);
                                            break;
                                    }
                                    ally = ally - GetDamage(team,enemypok);
                                    CheckAllyDeath(team, ally, asknumber, enemypok);
                                    iO.Write("Tu pokemon ha sido atacado y tiene " + ally + " puntos de vida");
                                }
                                while (finished != true);
                            }
                            else
                            {
                                int ally = team[asknumber].GetActualHp();
                                int enemy = enemypok[num2].GetActualHp();
                                iO.WriteYellow("Tu pokemon "+team[asknumber].GetName() +" ha empezado el combate con " + ally + " de vida \n");
                                iO.WriteYellow("El pokemon enemigo "+enemypok[num2].GetName() +" ha empezado el combate con " + enemy + " de vida \n");
                            do
                            {
                                ally = ally - GetDamage(team, enemypok);
                                CheckAllyDeath(team, ally, asknumber,enemypok);
                                iO.Write(" Tu pokemon ha sido atacado y tiene " + ally + " puntos de vida \n");
                                iO.Write("Pulsa el número 1 si quieres volver a atacar, 2 para cambiar pokemon, 3 para mochila y 4 para capturar");
                                int number = iO.AskNumber();
                                switch (number)
                                {
                                    case 1:
                                        enemy = enemy - GetDamage(team, enemypok);
                                        CheckEnemyDeath(team, enemy,ally, num2,asknumber, enemypok);
                                        iO.Write("El pokemon enemigo ha sido atacado y tiene " + enemy + " puntos de vida");
                                        break;
                                    case 2:
                                        ChangePok(team);
                                        break;
                                    case 3: //Mochila                 
                                        break;
                                    case 4: //capturar
                                        Capture(team, enemypok);
                                        break;
                                    case 5: //escapar
                                        Escape(team, enemypok, num2, asknumber);
                                        break;
                                }
                            }
                            while (finished != true);
                            }
                            break;
                        case 2: //Cambiar pokemon
                            //ChangePok(team,ally); No haria falta ya que pregunto que pokemon quiere sacar antes de empezar el programa
                            break;
                        case 3: //Mochila                 
                            break;
                        case 4: //capturar
                            Capture(team,enemypok);
                            break;
                        case 5: //escapar
                            ExitToMenu(team, enemypok);
                            break;
                    }
        }
        public void ShowPokemons(IndividualPokemon[] team) //muestra los datos de tus pokemons de la bolsa
        {
            for (int i = 0; i < team.Length; i++)
            {
                if (team[i] != null)
                {
                    iO.Write("Tu pokemon "+i+" es: " + team[i].GetName() + ",con " + team[i].GetMaxHp() + " de vidamáxima, " + team[i].GetAttack() + " de ataque, " + team[i].GetDefense() + " de defensa, " + team[i].GetSpeed() + " de velocidad. ");
                }
            }
        }
        public void ChangePok(IndividualPokemon[] team)
        {
            iO.Write("A que pokemon quieres sacar a luchar? ");
            ShowPokemons(team);
            int num = iO.AskNumber();
            team[asknumber] = team[num];
            iO.Write("Tu pokemon " + team[asknumber].GetName()+" ha salido al combate con " + team[asknumber].GetActualHp() +" de vida actual" );
        }
        public void PokCenter(IndividualPokemon[] team, IndividualPokemon[] enemy) //Centro Pokemon
        {
            iO.WritePink(" Bienvenido al centro pokemon, aquí restauraremos al completo la vida de todos tus pokemon\n");
            for (int i = 0; i <= team.Length; i++)
            {
                if (team[i] != null)
                {
                    iO.Write("Tu pokemon "+ team[i].GetName() +" tiene: "+ team[i].GetActualHp()+" de vida actual");
                    team[i].SetActualHp(team[i].GetMaxHp());
                    iO.Write("Tu pokemon "+ team[i].GetName() +" se ha curado y vuelve a tener " + team[i].GetMaxHp()+" de vida máxima");                    
                }
                else
                {
                    iO.Write("Tus pokemon ya estan curados");
                    iO.ThreadColorsWhite("\n");
                    ExitToMenu(team, enemy);
                }
            }
        }
        public void GetTrainerInfo()
        {
            iO.Write("Tu nombre es " + trainer.GetName() + " , tu género es " + trainer.GetGender() + " , tu ID es " + trainer.GetId() + " y tus monedas son:\n Pokemillas="+trainer.GetPokemillas()+" | Pokedollars="+trainer.GetPokedollars()+" | BattlePoints="+trainer.GetBattlePoints());
        }
        public void CheckAllyDeath(IndividualPokemon[] team, int pokcheck, int num, IndividualPokemon[] enemy)
        {
            if(pokcheck <= 0)
            {
                iO.Write("Tu pokemon ha sido derrotado"); //problemas aqui
                team[num].SetActualHp(0);
                finished = true;
                iO.ThreadColorsWhite(" Volviendo al menu...\n");
                ExitToMenu(team, enemy);
            }
        }
        public void CheckEnemyDeath(IndividualPokemon[] team, int epokcheck,int mpokcheck, int num,int num2, IndividualPokemon[] enemy)
        {
            if (epokcheck <= 0)
            {
                iO.Write("El pokemon enemigo ha sido derrotado"); //problemas aqui
                team[num2].SetActualHp(mpokcheck);
                finished = true;
                iO.ThreadColorsWhite("Volviendo al menu...\n");
                ExitToMenu(team, enemy);
            }
        }
        public void BasicStats(IndividualPokemon[] team, IndividualPokemon[] enemy)
        {
            for (int i = 0; i < team.Length; i++)
            {
                if (team[i] != null)
                {
                    iO.Write("Tu pokemon "+team[i].GetName()+ " ,de mote " + team[i].GetPokName() + " con una vida actual de " + team[i].GetActualHp() + " y una vida máxima de " + team[i].GetMaxHp()); //falta lo de especie porque tiene mote pero no nombre de especie bulbasaur
                }
            }
            iO.Write("Si quieres ver todas las estadísticas de uno de tus pokemon pulsa 1 y si no 2");
            int n = iO.AskNumber();
            switch (n)
            {
                case 1:
                    iO.Write("Elige un pokemon de los que tienes para ver más estadísticas , tu primer pokemon es el 0");
                    int num = iO.AskNumber();
                    ShowPokemons(team,num);
                    ExitToMenu(team,enemy);
                    break;
                case 2:
                    ExitToMenu(team, enemy);
                    break;
            }
        }
        public void ShowPokemons(IndividualPokemon[] team,int num) //muestra los datos de tus pokemons de la bolsa
        {
            if(team[num] != null)
            {
            iO.Write("Tu pokemon seleccionado es: \n" + team[num].GetName() +" de mote " + team[num].GetPokName() + " ,con " + team[num].GetMaxHp() + " de vida máxima, " + team[num].GetActualHp() + " de vida actual, " + team[num].GetAttack() + " de ataque, " + team[num].GetDefense() + " de defensa, " + team[num].GetSpeed() + " de velocidad. ");
            }
        }
        public int GetDamage(IndividualPokemon[] team, IndividualPokemon[] enemy) //calcula los daños
        {
            double damage;
            double rand;
            do
            {
                rand = randomvalue.NextDouble();
            } while (rand > 1 || rand < 0.85);
            damage = (((2 * 50 * (team[0].GetAttack() / enemy[saveenemypok].GetDefense())) / (50)) + 2) * rand * Critic();
            return (int)damage;
        }
        public double Critic() //para ver si es critico
        {
            int crit = randomvalue.Next(0, 25);
            if (crit == 0)
            {
                return 1.5;
            }
            else
            {
                return 1;
            }
        }
        public void Capture(IndividualPokemon[] team,IndividualPokemon[] enemy) //para capturar
        {
            rcm = ((3 * enemy[saveenemypok].GetMaxHp() - 2 * enemy[saveenemypok].GetActualHp()) * 4096 * enemy[saveenemypok].GetRatioCapture() / (3 * enemy[saveenemypok].GetMaxHp()));
            double ag = (65536 / (Math.Pow((255 / rcm), 0.1875)));
            int comparednumber = randomvalue.Next(0, 65536);
            for (int i = 0; catched != true; ++i)
            {
                if (comparednumber >= ag)
                {
                    catched = false;
                    iO.Write("Oh! El pokemon ha escapado!");
                }
                else
                {
                    iO.Write("Intento "+i);
                }
                if(i == 3)
                {
                    catched = true;
                    iO.Write("El pokemon " + enemy[saveenemypok].GetName()+" ha sido capturado");
                    iO.Write("Elige una de las siguientes posiciones para dejar al pokemon");
                    for (i = 0; i < team.Length; ++i)
                    {
                        if (team[i] == null)
                        {
                            iO.Write("Posición " + i);
                        }
                    }
                    int num = iO.AskNumber();
                    team[num] = enemy[saveenemypok];
                    iO.Write("Si quieres ponerle un mote a "+ enemy[saveenemypok].GetName() +" pulse 1 y si no 2");
                    int n = iO.AskNumber();
                    switch (n)
                    {
                        case 1:
                            string name = iO.AskString();
                            team[num].SetPokName(name);
                            break;
                        case 2:
                            break;
                        default:
                            break;
                    }
                    iO.Write("Volviendo al menú");
                    ExitToMenu(team,enemy);
                }
            }
        }
        public void Escape(IndividualPokemon[] team, IndividualPokemon[] enemy,int enemynum ,int allynum) //para escapar
        {
            int escp = ((team[allynum].GetSpeed() * 128) / enemy[enemynum].GetSpeed() + (30 * attemps));
            int rnum = randomvalue.Next(0, 256);
            if(rnum < escp)
            {
                ExitToMenu(team, enemy);
            }
            else
            {
                ++attemps;
            }
        }
        public void ExitToMenu(IndividualPokemon[] team, IndividualPokemon[] enemy) //para volver al menu
        {
            finished = false;
            ShowMenu();
            MainMenu(team, enemy);
        }
    }
}
