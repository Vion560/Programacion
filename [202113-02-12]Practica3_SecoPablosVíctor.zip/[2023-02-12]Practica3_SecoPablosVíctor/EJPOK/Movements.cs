﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace EJPOK
{
    public class Movements
    {
        string attackname;
        int identifier;
        int powerpoints;
        int power;
        int precision;
        bool priority;
        string type; //P para ataques físicos y E para Especial

        public Movements(string attackname, int identifier, int powerpoints, int power, int precision, bool priority, string type)
        {
            this.attackname = attackname;
            this.identifier = identifier;
            this.powerpoints = powerpoints;
            this.power = power;
            this.precision = precision;
            this.priority = priority;
            this.type = type;
        }
        public string Name()
        {
            return attackname; 
        }
        public int Power()
        {
            return power; 
        }

        public int Precision()
        {
            return precision; 
        }

        public string Type()
        {
            return type; 
        }
        public int PowerPoints()
        {
            return powerpoints; 
        }
        public enum Tipo
        {
            Normal,
            Fuego,
            Agua,
            Planta,
            Eléctrico,
            Hielo,
            Lucha,
            Veneno,
            Tierra,
            Volador,
            Psíquico,
            Bicho,
            Roca,
            Fantasma,
            Dragón,
            Siniestro,
            Acero,
            Hada
        }
        public enum Categoria
        {
            Físico,
            Especial,
            Estado
        }
        //public override string ToString()
        //{
        //    return ();
        //}
    }
}
