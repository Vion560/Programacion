﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJPOK
{
    public class Notas
    {
        //Vamos a poner notas para ir paso por paso y espabilar 
        //showpokemons con 2 variables esta bien junto a basicstats
        //vamos a dejar los movimientos apartados por ahora
        // hay que crear la clase tienda en la que ya tenemos un metodo para añadir objetos

    }
}
