﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJPOK
{
    public class Bag
    {
        List<Item> kit;
        List<Item> pokeballs;
        List<Item> combatobjects;
        List<Item> movements;
        List<Item> treasures;
        List<Item> keyobjects;
        List<Item> others;
        public Bag()
        {
            kit = new List<Item>();
            pokeballs = new List<Item>();
            combatobjects = new List<Item>();
            movements = new List<Item>();
            treasures = new List<Item>();
            keyobjects = new List<Item>();
            others = new List<Item>();
        }
        public void ShowItems()
        {
            for(int i = 0; i < 7; ++i)
            {
                
            }
        }
        public void AddItemKit(Item item)
        {
            kit.Add(item);
        }

        public void RemoveItemKit(Item item)
        {
            kit.Remove(item);
        }

        public bool HaveItemKit(Item item)
        {
            return kit.Contains(item);
        }

        public List<Item> TakeItemsKit()
        {
            return kit;
        }
        public void AddItemPokeballs(Item item)
        {
            pokeballs.Add(item);
        }

        public void RemoveItemPokeballs(Item item)
        {
            pokeballs.Remove(item);
        }

        public bool HaveItemPokeballs(Item item)
        {
            return pokeballs.Contains(item);
        }
        public List<Item> TakeItemPokeballs()
        {
            return pokeballs;
        }
        public void AddItemCombatobjects(Item item)
        {
            combatobjects.Add(item);
        }
        public void RemoveItemcombatobjects(Item item)
        {
            combatobjects.Remove(item);
        }
        public bool HaveItemCombatobjects(Item item)
        {
            return combatobjects.Contains(item);
        }
        public List<Item> TakeItemCombatobjects()
        {
            return combatobjects;
        }
        public void AddItemMovements(Item item)
        {
            movements.Add(item);
        }
        public void RemoveItemMovements(Item item)
        {
            movements.Remove(item);
        }
        public bool HaveItemMovements(Item item)
        {
            return movements.Contains(item);
        }
        public List<Item> TakeItemMovements()
        {
            return movements;
        }
        public void AddItemTreasures(Item item)
        {
            treasures.Add(item);
        }
        public void RemoveItemTreasures(Item item)
        {
            treasures.Remove(item);
        }
        public bool HaveItemTreasures(Item item)
        {
            return treasures.Contains(item);
        }
        public List<Item> TakeItemTreasures()
        {
            return treasures;
        }
        public void AddItemKeyObjects(Item item)
        {
            keyobjects.Add(item);
        }
        public void RemoveItemKeyObjects(Item item)
        {
            keyobjects.Remove(item);
        }
        public bool HaveItemKeyObjects(Item item)
        {
            return keyobjects.Contains(item);
        }
        public List<Item> TakeItemKeyObjects()
        {
            return keyobjects;
        }
        public void AddItemOthers(Item item)
        {
            others.Add(item);
        }
        public void RemoveItemOthers(Item item)
        {
            others.Remove(item);
        }
        public bool HaveItemOthers(Item item)
        {
            return others.Contains(item);
        }
        public List<Item> TakeItemOthers()
        {
            return others;
        }
    }
}
