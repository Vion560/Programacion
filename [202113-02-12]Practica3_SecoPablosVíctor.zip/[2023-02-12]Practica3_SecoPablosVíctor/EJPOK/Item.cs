﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJPOK
{
    public class Item
    {
        private string name;
        private int amount;
        private int valuebuy;
        private int valuesell;
        public Item()
        {

        }
        public Item(string name, int amount, int buy,int sell)
        {
            this.name = name;
            this.amount = amount;
            this.valuebuy = buy;
            this.valuesell = sell;
        }
        public string GetName()
        {
            return name; 
        }
        public void SetName(string name)
        {
            this.name = name;
        }

        public int GetAmount()
        {
            return amount;
        }
        public void SetAmount(int amount)
        {
            this.amount = amount;
        }
        public int GetValueBuy()
        {
            return valuebuy;
        }
        public void SetValueBuy(int value)
        {
            this.valuebuy = value;
        }
        public int GetValueSell()
        {
            return valuesell;
        }
        public void SetValueSell(int value)
        {
            this.valuesell = value;
        }
    }
}
