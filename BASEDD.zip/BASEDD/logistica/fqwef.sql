use logistica;
insert into camion values('ZZZZZXgvX', 'ford','diesel',50);
insert into camion values('ZrrrZZXX', 'ferrari','diesel',50);

insert into camioneros values('XXXXeeerr','cARLOS','09999','olimpiada',2500,'alcorcon');
insert into camioneros values('XXXXeedqdwerr','cARddLOS','099599','olimpiadsssa',2100,'alcooorcon');

insert into conducir values('30-11-2022','1111X','XXXX');