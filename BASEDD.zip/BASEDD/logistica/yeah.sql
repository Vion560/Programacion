use logistica;
 Create table if not exists Camion(
 matricula varchar(15),
 modelo varchar(15),
 tipo varchar(20),
 potencia int,
 primary key(matricula)
 );
 Create table if not exists Camioneros(
 Dni varchar(10),
 nombre varchar(20),
 telefono varchar(10),
 direccion varchar(10),
 salario varchar(10),
 poblacion varchar(10),
 primary key(Dni)
 );
 Create table if not exists Provincia(
 Cod_Provincia int(30),
 primary key(Cod_Provincia),
 nombre varchar(20)
 );
 Create table if not exists Paquetes(
 codigo int,
 Dni varchar(15),
 descripcion varchar(30),
 destino varchar(30),
 direccion varchar(25),
 Cod_Provincia int,
constraint fk_Dni_Camioneros foreign key(Dni) references Camioneros(Dni),
constraint fk_Cod_Prov foreign key(Cod_Provincia) references Provincia(Cod_Provincia)
 );
 Create table if not exists Conducir(
 fecha date,
 Dni varchar(15),
 matricula varchar(20),
 #los nombres no pueden ser iguales en fk(fk_DniC y fk_Dni_Camioneros);
 constraint fk_DniC foreign key(Dni) references Camioneros(Dni),
 constraint fk_Matricula foreign key(matricula) references Camion(matricula)
 );
 alter table camioneros modify column salario decimal(10,2)