select * from Proveedor;
select * from cliente;
select * from compra;
select * from producto;