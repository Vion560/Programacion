use supermercado;
/*drop table if exists Proveedor,Cliente;*/

CREATE TABLE if not exists Proveedor (
    nif varchar(10),
    nombre varchar(100),
    direccion varchar(255),
    primary key(nif)
);
CREATE TABLE if not exists Cliente (
    nombre varchar(255),
    apellido varchar(255),
    dni varchar(10),
    fecha date,
    direccion varchar(255),
    primary key(dni)
);
CREATE TABLE if not exists Producto (
    nombre varchar(255) not null,
    codigo varchar(255) primary key,
    nif varchar(10) not null,
    precio decimal(10,2) not null,
    constraint fk_nif foreign key (nif) references Proveedor(nif)
);
CREATE TABLE if not exists Compra (
    dni varchar(10) not null,
    codigo varchar(255) not null,
    primary key(codigo,dni),
    constraint fk_dni foreign key (dni) references Cliente(dni),
    constraint fk_cod foreign key (codigo) references Producto(codigo)
);