use consulta1;

select oficio from empleado where apellido='Seco';

select apellido from empleado where oficio='analista';

select apellido from empleado where oficio = (select oficio from empleado where apellido='Seco');

#Muestra apellido,oficio, salario y fecha de alta de aquellos empleados que tengan el mismo oficio que Jimenez o que tengan el mismo o mayor salario que Férnandez;

select oficio from empleado where apellido='Jimenez' ;
select salario from empleado where apellido='Fernandez';

select apellido,oficio,salario,fecha_alt from empleado where oficio = 'analista' or salario='3000';
select apellido,oficio,salario,fecha_alt from empleado where oficio = (select oficio from empleado where apellido='Jimenez') or salario>= (select salario from empleado where apellido='Fernandez');
select * from empleado where oficio = 'director' or oficio='analista';
select * from empleado where oficio in('director','analista');

#obtener aquellos apellidos de empleados cuyo oficio sea alguno de los oficios que hay en el departamento 20
select oficio from empleado where dept_no=20;
select apellido,dept_no,oficio from empleado where oficio in (select oficio from Departamento where dept_no=20);

#departamentos que no tengan epleadors
select distinct dept_no from empleado;
select * from departamento;
select dnombre,dept_no from departamento where exists(select * from empleado where departamento.dept_no=empleado.dept_no);
select dnombre,dept_no from departamento where not exists(select * from empleado where departamento.dept_no=empleado.dept_no);
select dnombre,dept_no from departamento as d where exists(select * from empleado as e where d.dept_no=e.dept_no);
#1. Empleados que están en el mismo departamento que GIL.
select * from empleado where dept_no = (select dept_no from empleado where apellido='Gil');
#2. Empleados con salario superior al salario de TOVAR.
select salario from empleado where apellido = 'TOVAR';
select * from empleado where salario> (select salario from empleado where apellido='Tovar');
#3. Empleados que tienen el mismo oficio que MARTIN o ganan menos que ALONSO
select oficio from empleado where apellido='martin';
select salario from empleado where apellido = 'Alonso';
select * from empleado where oficio = (select oficio from empleado where apellido='martin') or salario< (select salario from empleado where apellido = 'Alonso');
#4. Apellido y salario de los empleados que tienen por director (campo dir) a quien se apellida NEGRO.
select apellido,salario from empleado where dir = (select dir from empleado where apellido='NEGRO');
#5. Empleados en el mismo departamento que GIL y tienen su mismo oficio y salario 
select oficio from empleado where apellido='GIL';
select salario from empleado where apellido = 'GIL';
select dept_no from empleado where apellido = 'GIL';
select * from empleado where dept_no = (select dept_no from empleado where apellido='GIL') 
and oficio = (select oficio from empleado where apellido='Gil') and salario = (select salario from empleado where apellido='Gil');