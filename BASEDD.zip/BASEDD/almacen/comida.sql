use cocina;
Create table if not exists empleado(
dni varchar(15),
primary key(dni),
numss varchar(15) not null unique,
nombre varchar(15),
apellidos varchar(35),
movil int,
fijo int
);
Create table if not exists cocinero(
dni varchar(10),
años_serv int,
primary key(dni),
constraint fk_dni foreign key(dni) references empleado(dni)
);
Create table if not exists pinche(
dni_cocinero varchar(10),
dni varchar(10),
primary key(dni),
fecha date,
constraint fk_dni_cocinero foreign key(dni_cocinero) references cocinero(dni)
);
Create table if not exists tipo(
id_tipo varchar(20),
nombre varchar(20),
primary key(id_tipo)
);
Create table if not exists plato(
nombre varchar(15),
precio decimal(10,2),
codigo varchar(20),
primary key(codigo),
id_tipo varchar(20),
constraint fk_id_tipo foreign key(id_tipo) references tipo(id_tipo)
);
Create table if not exists ingredientes(
cod_ingredientes varchar(30),
primary key(cod_ingredientes),
nombre varchar(15)
);
Create table if not exists formado(
cod_plato varchar(50),
cod_ingredientes varchar(30),
primary key(cod_plato,cod_ingredientes),
constraint fk_cod_plato foreign key(cod_plato) references plato(codigo),
constraint fk_cod_ingred foreign key(cod_ingredientes) references ingredientes(cod_ingredientes)
);
Create table if not exists tienen(
cod_est varchar(20),
cod_ingredientes varchar(30),
numero int,
primary key(numero,cod_ingredientes,cod_est),
constraint fk_cod_ing foreign key(cod_ingredientes) references ingredientes(cod_ingredientes)
);
Create table if not exists cocina(
dni_cocinero varchar(10),
cod_plato varchar(10),
primary key(dni_cocinero),
primary key(cod_plato),
constraint fk_cod_plato foreign key(cod_plato) references plato(codigo),
constraint fk_dni_cocinero foreign key(dni_cocinero) references cocinero(dni)
);
Create table if not exists almacen(
nombre varchar(20),
num_almacen varchar(30),
descrip varchar(30),
primary key(num_almacen)
);
Create table if not exists estanteria(
codigo varchar(20),
num_almacen varchar(30) not null,
tamaño int,
primary key(codigo),
constraint fk_num_almacen foreign key(num_almacen) references almacen(num_almacen)
);

