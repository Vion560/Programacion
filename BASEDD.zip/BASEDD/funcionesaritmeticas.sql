use gimnasios;
select * from personal;
select max(salario_base) from personal;
select min(salario_base) from personal;
select avg(salario_base) from personal;
select sum(salario_base) from personal;