create table Proveedor(
NIF varchar(10),
nombre varchar(25),
dirección varchar(50),
primary key(NIF)
)