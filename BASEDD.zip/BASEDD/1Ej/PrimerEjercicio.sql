insert into Profesor values
	("4444444x","Carlos","del cura");
select * from Profesor