-- elegir bbdd:
use prueba;
create table Cliente(
dni varchar(9),
nombre varchar(50) not null,
dirección varchar(100),
fechanacimiento date,
primary key(dni)
);