use world;

#EJ1: Seleccionar paises que pertenecen a Norte América:
Select code,name, continent from country where Continent='North America';
#EJ2: Paises que pertenecen a Norte America y están en la region del Caribe
select * from country where continent='North America' and region='Caribbean';
#EJ3: Sleccionar los paises que tienen una poblacion  mayor a 1000000 habitantes
select * from country where Population>1000000;
#EJ4: La consulta anterior pero solo mostrando continente, codigo y poblacion
select continent,code,Population from country where Population>1000000;
#EJ5: Selecciona los paises que no tienen año de independencia
select * from country where IndepYear is null;
#EJ6: Selecciona los paises que tienen año de independencia y que la esperanza de vida es mayor de 50
select * from country where IndepYear is not null and LifeExpectancy>50.0;
#EJ7: Selecciona ciudades que su nombre tiene al menos 5 letras
select * from city where length(name>5);
#EJ8: Selecciona las ciudades que empiezan por la letra a, k ó m
select * from city where name like 'a%' or name like 'k%' or name like 'm%';
#EJ9: Ciudades que terminan por la letra a k o m
select * from city where name like '%k' or name like '%m';
#EJ10: ciudades que tienen mas de 3 letras a en el nombre
select * from city where name like '%a%a%a%';
select * from city where length(name) - length(replace(name,'a','')) >=3;
#EJ11: ciudades que contengan la letra a
select * from city where name like '%a%';
#Select length(replace(name,'a','')) from city;
select * from city where substring(name,1,2) = 'a';
#EJ12: muestra las 3 primeras letras de las ciudades
select substring(name,1,3) from city;
#EJ13: muestra las 3 primeras letras de las ciudades que tienen una poblacion entre 10000 y 150000
select substring(name,1,3) from city where Population>10000 and Population<150000;
select substring(name,1,3) from city where Population between 10000 and 150000; #este es mejor
#EJ14: muestra los 10 primeros registros de la tabla countrylanguage
Select * from countrylanguage LIMIT 0,10;
#EJ15:	muestra los paises ordenados de forma ascendente por el año de independencia
select * from country where IndepYear is not null order by 2; # EL 2 es por la segunda columna
#EJ16: muestra los paises que tienen superficie superior a 50000 m2 y en orden descendente
select * from country where SurfaceArea>50000.00 order by surfacearea desc;
#EJ17: Muestra el codigo , continente y año de independencia ordenados por nombre de continente de forma descendente y por año de independencia ascendente
select code,continent,IndepYear from country order by Continent desc, indepyear asc;
#EJ18: Muestra la anterior poniendo el nombre de las columnas en español
select code as Codigo, continent as Continente, Indepyear as aniodeindependecia from country order by Continent desc, indepyear asc;
#EJ19: muestra las ciudades sin año de independencia y en lugar de aparecer null que muestre sin año  y manteniendo el nombre de la columna
select name, ifnull(indepyear,'sin anio') as Indepyear from country where IndepYear is null;
#EJ20:muestre el nombre de las columnas de la tabla country
show columns from country;