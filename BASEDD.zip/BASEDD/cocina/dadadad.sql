use cocina;
insert into empleado values ('111x','101','Alejandro','Sanchez','+685478459','91111');
insert into empleado values ('222y','010','Pedro','Sanchez','+658748595','91222');
insert into empleado values ('333z','100','Mario','Jimenez','+658745896','91333');
insert into cocinero values ('111x','12');
insert into cocinero values ('222y','15');
insert into pinche values ('222y','333z',now());