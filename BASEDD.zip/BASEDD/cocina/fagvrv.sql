select * from empleado;
select * from cocinero;
delete from empleado where dni="111x";
alter table cocinero drop constraint fk_dni;
alter table cocinero add constraint fk_dni foreign key (dni) references Empleado(dni) on delete cascade 