use instituto;
#con los % le da igual lo que hay delante si esta delante y viceversa.
#6. Datos de los alumnos que viven en la misma población que Luis. 
select pobla from alumnos where apenom = '%Luis%';
#ejemplo
select * from asignaturas as a inner join notas as n on a.cod = n.cod;
#7. Nombre de las asignaturas que no han tenido ningún 6. 
select distinct cod from notas where nota=6;
select cod,nota from notas where nota<>6;
select distinct nombre from asignaturas as a inner join notas as n on a.cod = n.cod and n.cod not in(select distinct cod from notas where nota=6);
#8. Visualizar los nombres de asignaturas que no tengan suspensos. 
select distinct nombre from asignaturas as a inner join notas as n on a.cod = n.cod and n.cod not in(select distinct cod from notas where nota < 5);
#9. Visualizar los nombres de alumnos de “Madrid” que tengan alguna asignatura suspensa. 
select distinct apenom from alumnos as a inner join notas as n on a.dni = n.dni where n.nota < 5 and a.pobla = 'Madrid';
#muy importante el substring coge el apenom y vas desde la posicion de la comilla+1 hasta la longitud de apenom
select distinct substring(apenom,locate(',',apenom)+1,length(apenom)) from alumnos as a inner join notas as n on a.dni=n.dni where pobla='Madrid' and a.dni in(select distinct dni from notas where nota<5);
#10. Mostrar los nombres de alumnos que tengan la misma nota que tiene María en Marcas en cualquier asignatura 
select distinct substring(apenom,locate(',',apenom)+1,length(apenom)) as nombre from alumnos inner join notas on alumnos.dni = notas.dni where notas.nota = (select nota from notas where cod = (select cod from asignaturas where nombre like '%marca%') and dni = (select dni from alumnos where apenom like '%maria%')); 
#11. Mostrar los nombres de alumnos que tengan en Programación la misma nota que tiene Luis en Programación 
SELECT distinct substring(apenom,locate(',',apenom)+1,length(apenom)) as nombre from alumnos inner join notas on alumnos.dni = notas.dni where notas.nota = 
(select nota from notas where cod = (select cod from asignatura where nombre like '%programacion%') and dni = (select dni from alumnos where apenom like '%luis%')) 
and notas.cod = (select cod from asignaturas where nombre like '%programacion%');
