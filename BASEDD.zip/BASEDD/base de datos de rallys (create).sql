CREATE DATABASE IF NOT EXISTS rally 
DEFAULT CHARACTER SET utf8 
DEFAULT COLLATE utf8_general_ci;

USE rally;
/*drop database rally;*/

/* TABLA: PAIS   */
create table pais(
cod_pais tinyint not null AUTO_INCREMENT,
nombre varchar(20) not null,
constraint pais_pk primary key (cod_pais)
)engine=InnoDB;

INSERT INTO pais VALUES (NULL, "España");
INSERT INTO pais VALUES (NULL, "Francia");
INSERT INTO pais VALUES (NULL, "Italia");
INSERT INTO pais VALUES (NULL, "Dinamarca");
INSERT INTO pais VALUES (NULL, "Bélgica");
INSERT INTO pais VALUES (NULL, "Kazajistán");

create table zona(
cod_zona tinyint not null AUTO_INCREMENT,
ubicacion varchar(20) not null,
cod_pais tinyint not null,
constraint zona_pk primary key (cod_zona),
foreign key (cod_pais) references pais (cod_pais)
)engine=InnoDB;

INSERT INTO zona VALUES (NULL, "Toledo ", 1);
INSERT INTO zona VALUES (NULL, "Andalucía ", 1);
INSERT INTO zona VALUES (NULL, "Piamonte", 3);
INSERT INTO zona VALUES (NULL, " Lombardía", 3);
INSERT INTO zona VALUES (NULL, "Emba", 6);
INSERT INTO zona VALUES (NULL, " Monte Khan Tengri", 6);

create table rally(
ID_rally int not null AUTO_INCREMENT,
descripcion varchar(50) not null,
año YEAR not null,
cod_zona tinyint not null,
constraint rally_pk primary key (ID_rally),
constraint pais_fk foreign key (cod_zona) references zona (cod_zona)
)engine=InnoDB;

INSERT INTO rally VALUES (NULL, " Madrid-Talavera 2022", "2021",1);
INSERT INTO rally VALUES (NULL, " Milan", "2021",3);

INSERT INTO rally VALUES (NULL, " Madrid-Talavera 2020", "2020",1);
INSERT INTO rally VALUES (NULL, " Milan", "2020",3);


INSERT INTO rally VALUES (NULL, "  Kazajistán 2021", "2021",5);
INSERT INTO rally VALUES (NULL, " Kazajistán 2020", "2020",5);



create table etapas(
cod_etapa int not null AUTO_INCREMENT,
desnivel int not null,
distancia int not null,
dificultad varchar(15) not null,
pendiente int not null,
tipo_de_suelo varchar(15) not null,
cod_zona  tinyint not null,
ID_rally int,
constraint etapas_pk primary key (cod_etapa),
constraint zona_fk foreign key (cod_zona) references zona (cod_zona),
constraint rally_fk foreign key (ID_rally) references rally (ID_rally)
)engine=InnoDB;
/*  hasta aqui revisado por elena*/
/* tres estapas por rally"*/
INSERT INTO  etapas values  (NULL, 840 ,60 ,"alta ",30 , "calizo", 1, 1);
INSERT INTO  etapas values  (NULL, 840 ,80 ,"alta ",40 , "Asfalto", 1, 1);
INSERT INTO  etapas values  (NULL, 80 ,80 ,"alta ",50 , "Asfalto", 1, 1);

INSERT INTO  etapas values  (NULL, 840 ,60 ,"alta ",30 , "calizo", 2, 2);
INSERT INTO  etapas values  (NULL, 840 ,80 ,"alta ",40 , "Asfalto", 2, 2);
INSERT INTO  etapas values  (NULL, 80 ,80 ,"alta ",50 , "Asfalto", 2, 2);



create table equipos(
cod_equipo varchar(10) not null,
nombre_equipo varchar(20) not null,
fecha_fundacion date not null,
presupuesto int not null,
constraint equipos_pk primary key (cod_equipo)
)engine=InnoDB;
create table coches(
dorsal smallint not null AUTO_INCREMENT,
matricula varchar(7) unique not null,
modelo varchar(15) not null,
motor varchar(15) not null,
neumáticos varchar(10) not null,
tipo_traccion varchar(3) not null,
cod_equipo varchar(10) not null,
constraint coches_pk primary key (dorsal),
constraint equipos_fk foreign key (cod_equipo) references equipos(cod_equipo)
);
create table etapas_equipos(
cod_etapa int not null,
cod_equipo varchar(10) not null,
constraint etapas_equipos_pk primary key (cod_etapa, cod_equipo),
foreign key (cod_equipo) references equipos (cod_equipo),
foreign key (cod_etapa) references etapas (cod_etapa)
)engine=InnoDB;
create table etapas_coches(
cod_etapa int not null,
dorsal smallint not null,
constraint etapas_coches_pk primary key (cod_etapa, dorsal),
constraint coches_fk foreign key (dorsal) references coches (dorsal),
foreign key (cod_etapa) references etapas(cod_etapa)
)engine=InnoDB;
create table piloto(
DNI varchar(9) not null,
nombre varchar(10) not null,
apellidos varchar(25) not null,
dorsal smallint not null,
constraint piloto_pk primary key (DNI),
foreign key (dorsal) references coches (dorsal)
)engine=InnoDB;
create table copiloto(
DNI varchar(9) not null,
nombre varchar(10) not null,
apellidos varchar(25) not null,
dorsal smallint not null,
constraint copiloto_pk primary key (DNI),
foreign key (dorsal) references coches (dorsal)
)engine=InnoDB;