use empresa;

#1. Apellido, salario y localidad donde trabajan los empleados que trabajan en el departamento de CONTABILIDAD.
select * from departamento where dnombre = 'contabilidad';
select apellido, salario, loc from empleado inner join departamento on empleado.dept_no = departamento.dept_no where departamento.dept_no = (select dept_no from departamento where dnombre='contabilidad');
#2. Apellido, salario y nombre del departamento de los empleados que trabajan en departamentos que no están en SEVILLA.
select apellido, salario, loc from empleado inner join departamento on empleado.dept_no = departamento.dept_no where departamento.dept_no not in (select dept_no from departamento where loc='sevilla');
#3. Número de empleado y nombre del departamento en el que trabajan los empleados que ganan más de 1500 ordenados por departamento y luego por salario
select salario,apellido from empleado where salario>1500;
select emp_no, dnombre,salario from empleado inner join departamento on empleado.dept_no = departamento.dept_no where empleado.salario in (select salario from empleado where salario>1500) order by dnombre,salario;
#4. Mostrar nombre, dni, población y nombre de la asignatura de los alumnos que han suspendido alguna asignatura junto con dicha asignatura y la nota obtenida.
use instituto;
select dni,nota from notas where nota<5;
select apenom, alumnos.dni, pobla, nombre from alumnos join notas on alumnos.dni = notas.dni join asignaturas on asignaturas.cod = notas.cod where nota<5;
#5. Mostrar el nombre y código de las asignaturas que han tenido notas de 7 o 8
select distinct nombre,asignaturas.cod from asignaturas inner join notas on asignaturas.cod=notas.cod where nota=8 or nota=7;
#6. Visualizar los nombres de alumnos que tengan una nota entre 6 y 8 en la asignatura de BBDD.
#otra forma: lo del substring es para que solo salga el nombre sin apellidos ni comas
select substring(apenom,locate(',',apenom)+1,length(apenom)) as nombre from alumnos inner join notas on alumnos.dni = notas.dni join asignaturas on asignaturas.cod = notas.cod where nombre like '%bbdd%' and nota between 6 and 8;
select apenom from alumnos join notas on alumnos.dni = notas.dni join asignaturas on asignaturas.cod = notas.cod where notas.nota in (select nota from notas where nota>5 and nota<9)
and notas.cod = (select cod from asignaturas where nombre like '%bbdd%');
#7. Visualizar los nombres (sin repetir) de alumnos de “Madrid” que tienen suspensos.
select distinct apenom from alumnos inner join notas on alumnos.dni = notas.dni  where pobla like 'madrid' and notas.nota<5;
#8. Mostrar ordenados alfabéticamente a los alumnos junto al nombre de las asignaturas que tienen aprobadas. 
select * from alumnos join notas on alumnos.dni = notas.dni join asignaturas on notas.cod = asignaturas.cod where notas.nota>4;
#9. Mostrar el nombre de las atracciones que están actualmente averiadas
use parque;
select * from averias_parque;
select distinct atracciones.nom_atraccion from atracciones inner join averias_parque on atracciones.cod_atraccion = averias_parque.cod_atraccion where averias_parque.cod_atraccion in (select cod_atraccion from averias_parque where fecha_arreglo is null);
#10. Mostrar el nombre del empleado que tiene que arreglar las atracciones que están actualmente averiadas.
select nom_empleado,substring_index(nom_empleado,'',+1) as nombre from emple_parque join atracciones on emple_parque.dni_emple = averias_parque.dni_emple where fecha_arreglo is null;
#11. Mostrar los datos de las zonas junto a los nombres de los empleados que son sus encargados ordenados del más antiguo al más nuevo.
#el z.* es todos los datos de zonas(z)
select z.*,nom_empleado from zonas as z inner join emple_parque as e on z.dni_encargado=e.dni_emple order by alta_empresa;
#12. Para las averías que ocurrieron en el año 2013, mostrar el nombre de los empleados que las arreglaron, el nombre de la atracción a la que corresponden y el presupuesto de la zona a la que pertenecen.
select substring_index(nom_empleado,'',+1) as nombre,nom_atraccion,presupuesto from averias_parque as a inner join emple_parque as e on a.dni_emple=e.dni_emple 
inner join atracciones as atr on atr.cod_atraccion=a.cod_atraccion inner join zonas as z on z.nom_zona=atr.nom_zona
where year(fecha_falla)=2013;
#13. Mostrar el dni del empleado que tiene que arreglar las atracciones actualmente averiadas junto al nombre de la atracción, el nombre de la zona de la atracción y el dni del encargado de la zona.
select e.dni_emple,nom_atraccion,z.nom_zona,dni_encargado from emple_parque as e inner join averias_parque as a on e.dni_emple=a.dni_emple inner join
atracciones on a.cod_atraccion=atracciones.cod_atraccion inner join notas as n on n.nom_zona=a.nom_zona where fechas_arreglo is null;
#14. Añadir a la consulta anterior que se muestre también el nombre del encargado de la zona.
#15. Añadir a la anterior que se muestre también el nombre del empleado que tiene que arreglar la avería.

#16. Mostrar las zonas en las que Luis Pérez ha realizado arreglos.
select zonas.* from zonas join emple_parque on emple_parque.dni_emple=zonas.dni_encargado join averias_parque as a on emple_parque.dni_emple=a.dni_emple
where emple_parque.nom_empleado like 'Luis Pérez' and fecha_arreglo is not null;
#17. Mostrar el nombre de las atracciones que han arreglado Luis o Ignacio
select distinct nom_atraccion from emple_parque as e inner join averias_parque as a on e.dni_emple=a.dni_emple inner join atracciones as atr on a.cod_atraccion=atr.cod_atraccion
where nom_empleado like '%lui%' or nom_empleado like '%Ignacio%' and fecha_arreglo is not null;
#18. Mostrar las atracciones que ha arreglado el encargado de la zona a la que pertenece la atracción 
select atr.* from averias_parque as a inner join atracciones as atr on a.cod_atraccion=atr.cod_atraccion inner join zonas as z on z.nom_zona=atr.nom_zona 
where dni_emple=dni_encargado