﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJPOK
{
    public class Movements
    {
        string attackname;
        int identifier;
        int powerpoints;
        int power;
        int precision;
        bool priority;
        string type; //P para ataques físicos y E para Especial

        public Movements(string attackname, int identifier, int powerpoints, int power, int precision, bool priority, string type)
        {
            this.attackname = attackname;
            this.identifier = identifier;
            this.powerpoints = powerpoints;
            this.power = power;
            this.precision = precision;
            this.priority = priority;
            this.type = type;
        }
        Movements pound = new Movements("Destructor",1 ,35 ,40 ,100 ,false,"P");
        Movements KarateChop = new Movements("Golpe Karate", 2, 25, 50, 100, false, "P");
        Movements DoubleSlap = new Movements("Doble Bofetón", 3, 10, 30, 85, false, "P"); //como es de varios golpes por ahora hace a 2 golpes
        Movements CometPunch = new Movements("Puño Cometa", 4, 15, 32, 85, false, "P");
        Movements MegaPunch = new Movements("Mega Puño", 5, 20, 80, 100, false, "P");
        Movements PayDay = new Movements("Dia De Pago", 6, 20, 40, 100, false, "P");
        Movements FirePunch = new Movements("Puño Fuego", 7, 15, 75, 100, false, "P");
        Movements IcePunch = new Movements("Puño Hielo", 8, 15, 75, 100, false, "P");
        Movements ThunderPunch = new Movements("Puño Trueno", 9, 15, 75, 100, false, "P");
        Movements WingAttack = new Movements("Ataque Ala", 17, 35, 60, 100, false, "P");
        Movements RapidAttack = new Movements("Ataque Rápido", 98, 30, 40, 100, true, "P");
        Movements ExtremeSpeed = new Movements("Velocidad Extrema", 245, 5, 80, 100, true, "P");
        Movements RazorWind = new Movements("Viento Cortante", 13, 10, 80, 100, true, "E");

    }
}
