﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace EJPOK
{
    public class Game
    {
        public void Run()
        {
            Teacher();
            ChooseStarter();
            ShowMenu();
            MainMenu();
        }
        Random randomvalue = new Random();
        int[] numrandom = new int[5];
        SpeciePokemon[] initials = IndividualPokemon.starter(); //copia los iniciales
        SpeciePokemon[] copybag = IndividualPokemon.bag(); //copia el array
        SpeciePokemon[] enemypok = IndividualPokemon.EnemyPok();
        int maxhp;
        int specienum;
        int actualhp;
        int attack;
        int defense;
        int speed;
        IO iO;
        public Game(IO iO)
        {
            this.iO = iO;
        }

        public void Teacher() //Esta es la opción para que el profe te de la bienvenida
        {
            //IO iO = new IO();
            iO.ThreadColorsWhite("Hola, soy el profesor Ciprés. Bienvenido al mundo pokemon donde encontrarás muchos tipos de pokemon.");
            iO.ThreadColorsWhite("Para empezar tienes que elegir entre uno de estos tres pokemon y el que eligas te lo puedes quedar y puedas empezar con él tu aventura\n");
            iO.ThreadColorsRed(" Opción 1: Charmander.\n");
            iO.ThreadColorsGreen(" Opción 2: Bulbasaur.\n");
            iO.ThreadColorsBlue(" Opción 3: Squirtle.\n");
            iO.ThreadColorsWhite(" Elige un número\n");
            Console.ForegroundColor = ConsoleColor.White;

        }
        public void NoTeacher() //Opción en la que directamente empiezas con un pokemon aleatorio
        {
            //Fuctions fuctions = new Fuctions();
            Console.WriteLine("Elige un pokemón: \n");
            iO.ThreadColorsRed(" Opción 1: Charmander.\n");
            iO.ThreadColorsGreen(" Opción 2: Bulbasaur.\n");
            iO.ThreadColorsBlue(" Opción 3: Squirtle.\n");
            iO.ThreadColorsWhite("\n");
        }
        public Game() //Genera valores aleatorios al pokemon
        {
            numrandom[0] = this.maxhp;
            numrandom[0] = randomvalue.Next(35, 45);
            numrandom[1] = this.actualhp;
            numrandom[2] = this.attack;
            numrandom[2] = randomvalue.Next(4, 8);
            numrandom[3] = this.defense;
            numrandom[3] = randomvalue.Next(3, 6);
            numrandom[4] = this.speed;
            numrandom[4] = randomvalue.Next(6, 10);
        }
        public void ChooseStarter() //elige el starter y lo guarda en la bolsa
        {
            int num = iO.AskNumber();
            switch (num)
            {
                case 1:
                    copybag[0] = initials[0];
                    iO.Write("Has elegido a Charmander!");
                    break;
                case 2:
                    copybag[0] = initials[1];
                    iO.Write("Has elegido a Bulbasaur!");
                    break;
                case 3:
                    copybag[0] = initials[2];
                    iO.Write("Has elegido a Squirtle!");
                    break;
            }
        }
        public void ShowMenu() //muestra el menú por pantalla
        {
            IO io = new IO();
            io.Write("Menu:");
            io.Write("	Pulsa 1 para ver los datos de tus pokemon");
            io.Write("	Pulsa 2 para Combatir");
            io.Write("	Pulsa 3 centro pokemon");
            io.Write("	Pulsa 4 para salir");
        }
        public void MainMenu()
        {
            int opcion = iO.AskNumber();
            switch (opcion)
            {
                case 1:
                    iO.Write(iO.ChoosePok());
                    ShowMenu();
                    MainMenu();
                    break;
                case 2:
                    iO.Write("	Pulsa 2 para Combatir");
                    ShowMenu();
                    MainMenu();
                    break;
                case 3:
                    PokCenter();
                    iO.Write("	Pulsa 3 centro pokemon");
                    MainMenu();
                    break;
                case 4:
                    iO.Write("Escriba 1 para cerrar el juego definitivamente o 2 para volver al menú");
                    FinishGame();
                    break;

            }
        }
        public void FinishGame() //opción para cerrar el juego o no
        {
            int num = iO.AskNumber();         
            switch (num)
            {
                case 1:
                    Environment.Exit(0);
                    break;
                case 2:
                    ShowMenu();
                    MainMenu();
                    break;
            }
        }
        
        public void Fight() //Combate
        { 
        for(int i = 0; i < initials.Length; i++)
        {
            do
            {
                    iO.WriteInt(copybag[i].GetActualHp());
                    iO.WriteInt(enemypok[i].GetActualHp());
                    iO.WriteInt(copybag[i].GetSpeed());
                    iO.WriteInt(enemypok[i].GetSpeed());
                    if (copybag[i].GetSpeed() >= enemypok[i].GetSpeed())
                    {
                        iO.Write("Tu pokemon es más rápido");
                    }
                    else
                    {
                        iO.Write("El pokemon enemigo es más rápido");
                    }
                    iO.Write("Pulsa 1 para Atacar");
                    iO.Write("Pulsa 2 para Capturar");
                    iO.Write("Pulsa 3 para Escapar");
                    int num = iO.AskNumber();
                    switch (num)
                    {
                        case 1:

                            break;
                        case 2:

                            break;
                        case 3:

                            break;
                    }
                }
            while(copybag[i].GetActualHp() != 0);
        }
        }
        public void PokCenter() //Centro Pokemon
        {
            IO io = new IO();
            io.Write("Bienvenido al centro pokemon, aquí restauraremos al completo la vida de todos tus pokemon");
            for (int i = 0; i <= copybag.Length; i++)
            {
                if (copybag[i] != null)
                {
                    copybag[i].SetActualHp(copybag[i].GetMaxHp());
                    io.WriteInt(copybag[i].GetMaxHp());
                }
                else
                {
                    iO.Write("Tus pokemon ya estan curados");
                    ShowMenu();
                    MainMenu();
                }
            }
        }
    }
}
