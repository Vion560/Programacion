﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJPOK
{
    public class Movements
    {
        string attackname;
        int identifier;
        int powerpoints;
        int power;
        int precision;
        bool priority;
    }
}
