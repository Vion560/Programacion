﻿using System;

namespace getsettostring
{
    class Program
    {
        static void Main(string[] args)
        {
            person paco = new person("1111111A");
            person Lucia = new person("Lucía",24,'M');
            person miguel = new person("Miguel", 25, "4444444", 'H', 80,1.77f);
            Console.WriteLine(paco.toString());
            Console.WriteLine(Lucia.toString());
            Console.WriteLine(miguel.toString());
        }
    }
}
