﻿using System;
using System.Collections.Generic;
using System.Text;

namespace getsettostring
{
    class person
    {
        string name;
        int age;
        string dni;
        char sex;
        float weight;
        float height;

        public person(string dni)
        {
            this.dni = dni;
            name = "";
            age = 0;
            sex = 'H';
            height = 0;
            weight = 0;
        }
        public person(string name,int age,char sex)
        {
            this.name = name;
            this.age = age;
            this.sex = sex;
            height = 0;
            height = 0;
        }
        public person(string name, int age,string dni, char sex,float weight,float height)
        {
            this.name = name;
            this.age = age;
            this.sex = sex;
            this.height = height;
            this.weight = weight;
        }
        public int IMC()
        {
            float imc = (weight) / (height * height);
            if(imc<20)
            {
                return -1;
            }
            else
            {
                if(imc<=25)
                {
                    return 0;
                }
                else
                {
                    return 1;
                }
            }
        }
        public bool IsAdult()
        {
            return age >= 18;
        }
        public bool IsGender(char gender)
        {
            return gender == sex;
        }
        public string toString()
        {
            return name + ", " + " de " + age + " Años de edad, y con NIF " + dni + " sexo " + sex + " peso " + weight + " altura " + height;
        }
        public string getName() { return name; }
        public void SetName(string name) { this.name = name; }
        public int getAge() { return age; }
        public void setAge(int age) { this.age = age; }
        public string getDni() { return dni; }
        public void setDni(string dni) { this.dni = dni; }
        public char getSex() { return sex; }
        public void setSex(char sex) { this.sex = sex; }
        public float getWeight() { return weight; }
        public void setWeight(float weight) { this.weight = weight; }
        public float GetHeight() { return height; }
        public void SetHeight(float height) { this.height = height; }
    }
}
