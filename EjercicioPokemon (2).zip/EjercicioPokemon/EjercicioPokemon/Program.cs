﻿using System;
using System.Threading;

namespace Pokemon
{
	class Program
	{
		static void Main(string[] args)
		{
            IO io = new IO();
            Game g = new Game();
			g.Run();
		}
	}
}