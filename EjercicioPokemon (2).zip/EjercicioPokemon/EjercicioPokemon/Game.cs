﻿using EjercicioPokemon;
using System;
using System.Collections.Generic;
using System.Text;

namespace Pokemon
{
	class Game
	{
		public void Run()
		{
			Teacher();
			ChooseStarter();
		}
        Random randomvalue = new Random();
        int[] numrandom = new int[5];
		int maxhp;
		int actualhp;
		int attack;
		int defense;
		int speed;

        static void Teacher() //Esta es la opción para que el profe te de la bienvenida
		{
            IO iO = new IO();
            iO.ThreadColorsWhite("Hola, soy el profesor Ciprés. Bienvenido al mundo pokemon donde encontrarás muchos tipos de pokemon.");
			iO.ThreadColorsWhite("Para empezar tienes que elegir entre uno de estos tres pokemon y el que eligas te lo puedes quedar y puedas empezar con él tu aventura\n");
			iO.ThreadColorsRed(" Opción 1: Charmander.\n");
			iO.ThreadColorsGreen(" Opción 2: Bulbasaur.\n");
			iO.ThreadColorsBlue(" Opción 3: Squirtle.\n");
            iO.ThreadColorsWhite(" Elige un número\n");
			//Game pokemon1 = new Game();
			Console.ForegroundColor = ConsoleColor.White;
			
		}
		static void NoTeacher() //Opción en la que directamente empiezas con un pokemon aleatorio
		{
			//Fuctions fuctions = new Fuctions();
            IO iO = new IO();
            Console.WriteLine("Elige un pokemón: \n");
			iO.ThreadColorsRed(" Opción 1: Charmander.\n");
			iO.ThreadColorsGreen(" Opción 2: Bulbasaur.\n");
			iO.ThreadColorsBlue(" Opción 3: Squirtle.\n");
			iO.ThreadColorsWhite("\n");
		}
		public Game() //Genera valores aleatorios al pokemon
		{
			numrandom[0] = this.maxhp;
			numrandom[0] = randomvalue.Next(15, 25);
			numrandom[1] = this.actualhp;
			numrandom[2] = this.attack;
			numrandom[2] = randomvalue.Next(4, 8);
			numrandom[3] = this.defense;
			numrandom[3] = randomvalue.Next(3, 6);
			numrandom[4] = this.speed;
			numrandom[4] = randomvalue.Next(6, 10);
		}
		public void ChooseStarter()
		{
            IO ch = new IO();
            SpeciePokemon[] starter = new SpeciePokemon[3];
			starter[0] = new SpeciePokemon("Charmander",39, 52, 39, 65); //stats basadas en el juego de verdad
            starter[1] = new SpeciePokemon("Bulbasaur", 45, 49, 49, 45);
			starter[2] = new SpeciePokemon("Squirtle", 44, 48, 65, 43);
            ch.Write(ch.ChoosePok());
        }
	}
}