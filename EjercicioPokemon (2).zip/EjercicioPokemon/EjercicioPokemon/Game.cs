﻿using EjercicioPokemon;
using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Pokemon
{
	class Game
	{
		public void Run()
		{
			Teacher();
			ChooseStarter();
			Menu();
		}
        Random randomvalue = new Random();
        int[] numrandom = new int[5];
		int maxhp;
		int specienum;
		int actualhp;
		int attack;
		int defense;
		int speed;

        static void Teacher() //Esta es la opción para que el profe te de la bienvenida
		{
            IO iO = new IO();
            iO.ThreadColorsWhite("Hola, soy el profesor Ciprés. Bienvenido al mundo pokemon donde encontrarás muchos tipos de pokemon.");
			iO.ThreadColorsWhite("Para empezar tienes que elegir entre uno de estos tres pokemon y el que eligas te lo puedes quedar y puedas empezar con él tu aventura\n");
			iO.ThreadColorsRed(" Opción 1: Charmander.\n");
			iO.ThreadColorsGreen(" Opción 2: Bulbasaur.\n");
			iO.ThreadColorsBlue(" Opción 3: Squirtle.\n");
            iO.ThreadColorsWhite(" Elige un número\n");
			Console.ForegroundColor = ConsoleColor.White;
			
		}
		static void NoTeacher() //Opción en la que directamente empiezas con un pokemon aleatorio
		{
			//Fuctions fuctions = new Fuctions();
            IO iO = new IO();
            Console.WriteLine("Elige un pokemón: \n");
			iO.ThreadColorsRed(" Opción 1: Charmander.\n");
			iO.ThreadColorsGreen(" Opción 2: Bulbasaur.\n");
			iO.ThreadColorsBlue(" Opción 3: Squirtle.\n");
			iO.ThreadColorsWhite("\n");
		}
		public Game() //Genera valores aleatorios al pokemon
		{
			numrandom[0] = this.maxhp;
			numrandom[0] = randomvalue.Next(35, 45);
			numrandom[1] = this.actualhp;
			numrandom[2] = this.attack;
			numrandom[2] = randomvalue.Next(4, 8);
			numrandom[3] = this.defense;
			numrandom[3] = randomvalue.Next(3, 6);
			numrandom[4] = this.speed;
			numrandom[4] = randomvalue.Next(6, 10);
		}
		public void ChooseStarter()
		{
            IO ch = new IO();
            ch.Write(ch.ChoosePok());
        }
        public void Menu()
        {
            IO io = new IO();
			io.Write("Menu:");
            io.Write("	Pulsa 1 para ver los datos de tus pokemon");
            io.Write("	Pulsa 2 para Combatir");
            io.Write("	Pulsa 3 centro pokemon");
            io.Write("	Pulsa 4 para salir");
        }
        public void MainMenu()
        {
            IO io = new IO();
            int opcion = io.AskNumber();
            switch (opcion)
            {
                case 1:
                    io.Write("	Pulsa 1 para ver los datos de tus pokemon");
                    io.ChoosePok();
                    break;
                case 2:
                    io.Write("	Pulsa 2 para Combatir");
                    break;
                case 3:
                    io.Write("	Pulsa 3 centro pokemon");
                    break;
                case 4:
                    io.Write("	Pulsa 4 para salir");
                    break;
            }
        }
    }
}