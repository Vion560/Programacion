﻿using EjercicioPokemon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon
{
	public class IO
	{
        //int[] numrandom = new int[5];
        //int maxhp;
        //int actualhp;
        //int attack;
        //int defense;
        //int speed;


        //Función para que el texto de presentación esté en color verde
        public void ThreadColorsRed(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                }
            }
        }
        public void ThreadColorsGreen(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                }
            }
        }
        public void RunSlow()
        {
            Thread.Sleep(1000);
        }
        public void RunFast()
        {
            Thread.Sleep(10);
        }
        
        public void ThreadColorsWhite(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(15);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
        }
        public void ThreadColorsBlue(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                }
            }
        }
        public string ChoosePok()
        {
            int pok;
            SpeciePokemon[] starter = IndividualPokemon.starter();
            pok = int.Parse(Console.ReadLine());
            if(pok == 1)
            {
                //return "Has elegido a Charmander con 39 de vida, 52 de ataque, 39 de defensa y 65 de velocidad";
                return "Has elegido a " + starter[0].GetName() + " con " + starter[0].GetMaxHp() + " de vida, " + starter[0].GetAttack() + " de ataque, " + starter[0].GetDefense() + " de defensa, " + starter[0].GetSpeed() + " de velocidad."; ;
            }
            if (pok == 2)
            {
                return "Has elegido a Bulbasaur con 45 de vida, 49 de ataque, 49 de defensa y 45 de velocidad";
            }
            if (pok == 3)
            {
                return ("Has elegido a Squirtle con 44 de vida, 48 de ataque, 65 de defensa y 43 de velocidad");
            }
            else 
            {
                return "Has elegido el: " + pok;
            }
            
        }
        public void Write(string a)
        {
            Console.WriteLine(a);
        }       
        public string Read()
        {
            return Console.ReadLine();
        }
        public int AskNumber()
        {
            return int.Parse(Console.ReadLine());
        }
        public char AskLetter(char lett)
        {
            Console.WriteLine("Dame una letra");
            return lett;
        }
        public int RandomValues(int a, int b)
        {
            Random random = new Random();
            int number = random.Next(a, b);
            return number;
        }
        public int IntToString()
        {
            int number = int.Parse(Console.ReadLine());
            return number;
        }       
    }
}
