﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pokemon
{
    class Game
    {
        public void Run()
        {
            NoTeacher();
        }

        Random randomvalue = new Random();
        int[] numrandom = new int[5];
        int maxhp;
        int actualhp;
        int attack;
        int defense;
        int speed;

        static void Teacher() //Esta es la opción para que el profe te de la bienvenida
        {
            Fuctions fuctions = new Fuctions();
            fuctions.ThreadColors("Hola, soy el profesor Ciprés. Bienvenido al mundo pokemon donde encontrarás muchos tipos de pokemon.");
            fuctions.ThreadColors("Para empezar tienes que elegir entre uno de estos tres pokemon y el que eligas te lo puedes quedar y puedas empezar con él tu aventura\n");
            fuctions.ThreadColorsRed(" Opción 1: Charmander\n");
            fuctions.ThreadColors(" Opción 2: Bulbasaur\n");
            fuctions.ThreadColorsBlue(" Opción 3: Squirtle\n");
            Game pokemon1 = new Game();
            //pokemon1.SetActualHp(10);
            //Console.WriteLine(pokemon1.GetActualHp());
            Console.ForegroundColor = ConsoleColor.White;
        }
        static void NoTeacher() //Opción en la que directamente empiezas con un pokemon aleatorio
        {
            Fuctions fuctions = new Fuctions();
            Console.WriteLine("Elige un pokemón: \n");
            fuctions.ThreadColorsRed(" Opción 1: Charmander.\n");
            fuctions.ThreadColors(" Opción 2: Bulbasaur.\n");
            fuctions.ThreadColorsBlue(" Opción 3: Squirtle.\n");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public Game() //Genera valores aleatorios al pokemon
        {
            numrandom[0] = this.maxhp;
            numrandom[0] = randomvalue.Next(15, 25);
            numrandom[1] = this.actualhp;
            numrandom[2] = this.attack;
            numrandom[2] = randomvalue.Next(4,8);
            numrandom[3] = this.defense;
            numrandom[3] = randomvalue.Next(3,6);
            numrandom[4] = this.speed;
            numrandom[4] = randomvalue.Next(6,10);
        }
        public Game(int maxhp, int actualhp, int att, int def, int speed) //Le das tu los valores al pokemon
        {
            this.maxhp = maxhp;
            this.actualhp = actualhp;
            this.attack = att;
            this.defense = def;
            this.speed = speed;
        }
        public int GetActualHp()
        {
            return actualhp;
        } //Da valor a la vida actual
        public void SetActualHp(int actualhp)
        {
            this.actualhp = actualhp;
        } //Da la vida actual
        public int GetMaxHp()
        {
            return maxhp;
        } //Muestra la vida máxima
        public void SetMaxHp(int maxhp)
        {
            this.maxhp = maxhp;
        } //Da valor a la vida máxima
        public int GetAttack(int att)
        {
            return att;
        } //Muestra el ataque
        public void SetAttack(int att)
        {
            this.attack = att;
        } //Da valor al ataque
        public int GetDefense(int def)
        {
            return def;
        } //Muestra la defensa
        public void SetDefense(int def)
        {
            this.defense = def;
        }//Da valor a la defensa
        public int GetSpeed(int speed)
        {
            return speed;
        } //Muestra la velocidad
        public void SetSpeed(int speed)
        {
            this.speed = speed;
        } //Da valor a la velocidad
    }
}
