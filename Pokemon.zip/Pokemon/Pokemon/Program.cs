﻿using System;
using System.Threading;

namespace Pokemon
{
    class Program
    {
        static void Main(string[] args)
        {

            Fuctions fuctions = new Fuctions();
            fuctions.ThreadColors("Hola, soy el profesor Ciprés. Bienvenido al mundo pokemon donde encontrarás muchos tipos de pokemon.");
            Console.WriteLine("Para empezar tienes que elegir entre uno de estos tres pokemon y el que eligas te lo puedes quedar y puedas empezar con él tu aventura");
            Console.WriteLine("Opción 1: Charmander");
            Console.WriteLine("Opción 2: Bulbasaur");
            Console.WriteLine("Opción 3: Squirtle");
            Pokemon pokemon1 = new Pokemon();
            pokemon1.SetActualHp(10);
            Console.WriteLine(pokemon1.GetActualHp());
            fuctions.ThreadColors("lkasghdíalshdoiashdoñiuasyhodñhasodhoañsyhdoñiasyhdoñasyhdoñuyahsoñdyasoydhoñasyhdoausydoiaysdoñ \n");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
