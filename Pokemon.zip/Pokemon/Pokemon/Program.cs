﻿using System;
using System.Threading;

namespace Pokemon
{
    class Program
    {
        static void Main(string[] args)
        {
            Game g = new Game();
            g.Run();
        }
    }
}
