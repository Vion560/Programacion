﻿using System;
using System.Collections.Generic;
using System.Text;



namespace Pokemon
{
    class Pokemon
    {
        int maxhp;
        int actualhp;
        int attack;
        int defense;
        int speed;
        public Pokemon()
        {
            this.maxhp = 20;
            this.actualhp = 0;
            this.attack = 6;
            this.defense = 3;
            this.speed = 7;
        }
        public Pokemon(int maxhp,int actualhp,int att,int def,int speed)
        {
            this.maxhp = maxhp;
            this.actualhp = actualhp;
            this.attack = att;
            this.defense = def;
            this.speed = speed;
        }
        public int GetActualHp()
        {
            return actualhp;
        }
        public void SetActualHp(int actualhp)
        {
            this.actualhp = actualhp;
        }
        public int GetMaxHp()
        {
            return maxhp;
        }
        public void SetMaxHp(int maxhp)
        {
            this.maxhp = maxhp;
        }
        public int GetAttack(int att)
        {
            return att;
        }
        public void SetAttack(int att)
        {
            this.attack = att;
        }
        public int GetDefense(int def)
        {
            return def;
        }
        public void SetDefense(int def)
        {
            this.defense = def;
        }
        public int GetSpeed(int speed)
        {
            return speed;
        }
        public void SetSpeed(int speed)
        {
            this.speed = speed;
        }


        
    }
}
