﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Pokemon
{
    class Fuctions
    {
        public void ThreadColors(string text)
        {
            for (int i = 0; i < text.Length; i += 1) { Thread.Sleep(100); Console.Write(text[i]); if (i % 2 == 0) { Console.ForegroundColor = ConsoleColor.Green; } else { Console.ForegroundColor = ConsoleColor.Blue; } }
        }
    }
}
