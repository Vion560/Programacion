﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Pokemon
{
    class Fuctions
    {
        //Función para que el texto de presentación esté en color verde
        public void ThreadColors(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1) 
            { 
                Thread.Sleep(100); 
                Console.Write(text[i]); 
                if (i % 2 == 0) 
                { 
                    Console.ForegroundColor = ConsoleColor.Green;
                }
            }
        }
        public void ThreadColorsRed(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                Console.ForegroundColor = ConsoleColor.Red;

            }
        }
        public void ThreadColorsBlue(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                }
            }
        }

    }
}
