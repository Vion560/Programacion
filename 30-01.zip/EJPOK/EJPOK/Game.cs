﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace EJPOK
{
    public class Game
    {
        public void Run()
        {
            Teacher();
            ChooseStarter();
            ShowMenu();
            MainMenu();
        }
        Random randomvalue = new Random();
        int[] numrandom = new int[5];
        SpeciePokemon[] initials = IndividualPokemon.starter(); //copia los iniciales
        SpeciePokemon[] copybag = IndividualPokemon.bag(); //copia el array
        SpeciePokemon[] enemypok = IndividualPokemon.EnemyPok();
        IO iO;
        int maxhp;
        int specienum;
        int actualhp;
        int attack;
        int defense;
        int speed;
        int damage;
        int crit;
        float rcm;
        string chico;
        string chica;
        string chique;
        int ratiocapture;
        int death = 0;
        Trainer trainer = new Trainer();
        //double ag;
        
        public Game(IO iO)
        {
            this.iO = iO;
        }

        public void Teacher() //Esta es la opción para que el profe te de la bienvenida
        {
            iO.ThreadColorsWhite("Hola, soy el profesor Ciprés. Bienvenido al mundo pokemon donde encontrarás muchos tipos de pokemon. \n");
            iO.Write("Primero dime tu nombre porfavor \n");
            string playername = iO.AskString();
            trainer.SetName(playername);
            iO.Write("Dime tu género entre chico,chica o chique\n");
            string gender = iO.AskString();
            //trainer.SetGender(gender);
            if (gender != chico || gender != chica || gender != chique)
            {
                iO.Write("Por favor elige una de las tres opciones");
                gender = iO.AskString();
                trainer.SetGender(gender);
            }
            else
            {
                trainer.SetGender(gender);
            }
            iO.Write("Ahora elige: 0 si tu continente es Europa, 1 para Norte América, 2 Asia-Australia, 3 África o 4 Sur América");
            int Continent = iO.AskNumber();
            int a = GetId(Continent);
            trainer.SetId(a);
            RandomNum();
            iO.ThreadColorsWhite("Para empezar tienes que elegir entre uno de estos tres pokemon y el que eligas te lo puedes quedar y puedas empezar con él tu aventura\n");
            iO.ThreadColorsRed(" Opción 1: Charmander.\n");
            iO.ThreadColorsGreen(" Opción 2: Bulbasaur.\n");
            iO.ThreadColorsBlue(" Opción 3: Squirtle.\n");
            iO.ThreadColorsWhite(" Elige un número\n");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public int GetId(int cont)
        {
            if (cont == 0)
            {
                int myid = randomvalue.Next(0000000000, 0999999999);
                return myid;
            }
            if (cont == 1)
            {
                int myid = randomvalue.Next(1000000000, 1999999999);
                return myid;
            }
            if (cont == 2)
            {
                int myid = randomvalue.Next(2000000000, 299999999);
                return myid;
            }
            if (cont == 3)
            {
                int myid = randomvalue.Next(300000000, 399999999);
                return myid;
            }
            //if (cont == 4)
            //{
            //    int myid = randomvalue.Next(4000000000, 4999999999);
            //    return myid;
            //}
            else
            {
                return 1000000000;
            }
        }
        public int RandomNum()
        {
            int num = randomvalue.Next(000000000,999999999);
            return num;
        }
        public void NoTeacher() //Opción en la que directamente empiezas con un pokemon aleatorio
        {
            Console.WriteLine("Elige un pokemón: \n");
            iO.ThreadColorsRed(" Opción 1: Charmander.\n");
            iO.ThreadColorsGreen(" Opción 2: Bulbasaur.\n");
            iO.ThreadColorsBlue(" Opción 3: Squirtle.\n");
            iO.ThreadColorsWhite("\n");
        }
        public void ChooseStarter() //elige el starter y lo guarda en la bolsa
        {
            int num = iO.AskNumber();
            switch (num)
            {
                case 1:
                    copybag[0] = initials[0];
                    iO.Write("Quieres darle un mote a Charmander? Pulsa 1 para si y 2 para no");
                    int n = iO.AskNumber();
                    switch(n)
                    {
                        case 1:
                            string name = iO.AskString();
                            copybag[0].SetName(name);
                            break;
                        case 2:
                            break;
                    }
                    break;
                case 2:
                    copybag[0] = initials[1];
                    iO.Write("Quieres darle un mote a Bulbasaur? Pulsa 1 para si y 2 para no");
                    int n1 = iO.AskNumber();
                    switch (n1)
                    {
                        case 1:
                            string name = iO.AskString();
                            copybag[0].SetName(name);
                            break;
                        case 2:
                            break;
                    }
                    break;
                case 3:
                    copybag[0] = initials[2];
                    iO.Write("Quieres darle un mote a Squirtle? Pulsa 1 para si y 2 para no");
                    int n2 = iO.AskNumber();
                    switch (n2)
                    {
                        case 1:
                            string name = iO.AskString();
                            copybag[0].SetName(name);
                            break;
                        case 2:
                            break;
                    }
                    break;
                default:
                    iO.Write("Por favor eliga una opción correcta");
                    ChooseStarter();
                    break;
            }
        }
        public void ShowMenu() //muestra el menú por pantalla
        {
            iO.Write("Menu:");
            iO.Write("	Pulsa 1 para ver tus datos como entrenador");
            iO.Write("	Pulsa 2 para ver los datos de tus pokemon");
            iO.Write("	Pulsa 3 para Combatir");
            iO.Write("	Pulsa 4 centro pokemon");
            iO.Write("	Pulsa 5 para salir");
        }
        public void MainMenu()
        {
            int opcion = iO.AskNumber();
            switch (opcion)
            {
                case 1:
                    GetTrainerInfo();
                    ExitToMenu();
                    break;
                case 2:
                    BasicStats();
                    ExitToMenu();
                    break;
                case 3:
                    Fight();
                    break;
                case 4:
                    PokCenter();
                    ExitToMenu();
                    break;
                case 5:
                    iO.Write("Escriba 1 para cerrar el juego definitivamente o 2 para volver al menú");
                    FinishGame();
                    break;

            }
        }
        public void GetTrainerInfo()
        {
            iO.Write("Tu nombre es "+trainer.GetName()+" , tu género es "+trainer.GetGender()+" , tu ID es "+trainer.GetId());
        }
        public void FinishGame() //opción para cerrar el juego o no
        {
            int num = iO.AskNumber();         
            switch (num)
            {
                case 1: //para cerrar el juego
                    Environment.Exit(0);
                    break;
                case 2: //volver al menu
                    ExitToMenu();
                    break;
            }
        }
        public void BasicStats()
        {
            for (int i = 0; i < copybag.Length; i++)
            {
                if (copybag[i] != null)
                {
                    iO.Write("Tu pokemon de mote " + copybag[i].GetName()+" con una vida actual de " + copybag[i].GetActualHp()+" una vida máxima de " + copybag[i].GetMaxHp()); //falta lo de especie porque tiene mote pero no nombre de especie bulbasaur
                }
            }
            iO.Write("Elige un pokemon de los que tienes para ver más estadísticas , el primero es el 0");
            int num = iO.AskNumber();
            ShowPokemons(num);
        }
        public void ShowPokemons(int num) //muestra los datos de tus pokemons de la bolsa
        {
            if (num == 0)
            { 
                iO.Write("Tus pokemon son: " + copybag[0].GetName() + ",con " + copybag[0].GetMaxHp() + " de vida máxima, " + copybag[0].GetActualHp()+" de vida actual, " +copybag[0].GetAttack() + " de ataque, " + copybag[0].GetDefense() + " de defensa, " + copybag[0].GetSpeed() + " de velocidad. ");               
            }
            if (num == 1)
            {
                iO.Write("Tus pokemon son: " + copybag[1].GetName() + ",con " + copybag[1].GetMaxHp() + " de vida máxima, " + copybag[1].GetActualHp() + " de vida actual, " + copybag[1].GetAttack() + " de ataque, " + copybag[1].GetDefense() + " de defensa, " + copybag[1].GetSpeed() + " de velocidad. ");
            }
            if (num == 2)
            {
                iO.Write("Tus pokemon son: " + copybag[2].GetName() + ",con " + copybag[2].GetMaxHp() + " de vida máxima, " + copybag[2].GetActualHp() + " de vida actual, " + copybag[2].GetAttack() + " de ataque, " + copybag[2].GetDefense() + " de defensa, " + copybag[2].GetSpeed() + " de velocidad. ");
            }
            if (num == 3)
            {
                iO.Write("Tus pokemon son: " + copybag[3].GetName() + ",con " + copybag[3].GetMaxHp() + " de vida máxima, " + copybag[3].GetActualHp() + " de vida actual, " + copybag[3].GetAttack() + " de ataque, " + copybag[3].GetDefense() + " de defensa, " + copybag[3].GetSpeed() + " de velocidad. ");
            }
            if (num == 4)
            {
                iO.Write("Tus pokemon son: " + copybag[4].GetName() + ",con " + copybag[4].GetMaxHp() + " de vida máxima, " + copybag[4].GetActualHp() + " de vida actual, " + copybag[4].GetAttack() + " de ataque, " + copybag[4].GetDefense() + " de defensa, " + copybag[4].GetSpeed() + " de velocidad. ");
            }
            if (num == 5)
            {
                iO.Write("Tus pokemon son: " + copybag[5].GetName() + ",con " + copybag[5].GetMaxHp() + " de vida máxima, " + copybag[5].GetActualHp() + " de vida actual, " + copybag[5].GetAttack() + " de ataque, " + copybag[5].GetDefense() + " de defensa, " + copybag[5].GetSpeed() + " de velocidad. ");
            }
        }
        public void ShowTrainer()
        {
            iO.Write("Estos son tus datos como entrenador pokemon: ");
        }

        public void Fight() //Combate
        { 
            if(copybag[0].GetActualHp() > death)
            { 
            do
            {
                    iO.Write("Pulsa 1 para Comenzar la pelea");             
                    iO.Write("Pulsa 2 para cambiar pokemon");           
                    iO.Write("Pulsa 3 para Capturar");
                    iO.Write("Pulsa 4 para Volver al menú");
                    int num = iO.AskNumber();
                    switch (num)
                    {
                        case 1: //atacar
                            if (copybag[0].GetSpeed() >= enemypok[0].GetSpeed())
                            {
                                int enemy = enemypok[0].GetActualHp();
                                int ally = copybag[0].GetActualHp();
                                iO.Write("Tu pokemon ha empezado el combate con " + ally + " de vida ");
                                iO.Write("El pokemon enemigo ha empezado el combate con " + enemy + " de vida ");
                                do 
                                {
                                if (enemy <= 0)
                                {
                                    Console.WriteLine("El pokemon enemigo ha sido derrotado");
                                    copybag[0].SetActualHp(ally);
                                    ExitToMenu();
                                    break;
                                }
                                if (ally <= 0)
                                {
                                    Console.WriteLine("Tu pokemon ha sido derrotado :(");
                                    copybag[0].SetActualHp(0);
                                    ExitToMenu();
                                    break;
                                }
                                iO.Write("Pulsa el número 1 si quieres volver a atacar, 2 para cambiar pokemon, 3 para capturar");
                                int number = iO.AskNumber();
                                switch(number)
                                {
                                    case 1:
                                        enemy = enemy - GetDamage();
                                        iO.Write("El pokemon enemigo ha sido atacado y tiene " + enemy + " puntos de vida");
                                        break;
                                    case 2:
                                        //ShowPokemons(); //muestra pokemons k tienes para poder cambiar
                                        break;
                                    case 3: //Mochila                 
                                        break;
                                    case 4: //capturar
                                        Capture();
                                        break;
                                }
                                ally = ally - GetDamage();
                                iO.Write("Tu pokemon ha sido atacado y tiene " + ally + " puntos de vida");                               
                                }
                                while (copybag[0].GetActualHp() > 0 || enemypok[0].GetActualHp() > 0);                               
                            }
                            else
                            {
                                int ally;
                                ally = copybag[0].GetActualHp();
                                int enemy;
                                enemy = enemypok[0].GetActualHp();
                                iO.WriteInt(enemy);
                                iO.WriteInt(ally);
                                iO.Write("Tu pokemon ha empezado el combate con " + ally + " de vida ");
                                iO.Write("El pokemon enemigo ha empezado el combate con " + enemy + " de vida ");
                                do
                                {
                                    if (enemy <= 0)
                                    {
                                        Console.WriteLine("El pokemon enemigo ha sido derrotado");
                                        copybag[0].SetActualHp(ally);
                                        ExitToMenu();
                                    break;
                                    }
                                    if (ally <= 0)
                                    {
                                        Console.WriteLine("Tu pokemon ha sido derrotado :(");
                                        copybag[0].SetActualHp(0);
                                        ExitToMenu();
                                    break;
                                    }
                                    ally = ally - GetDamage();
                                    iO.Write("Tu pokemon ha sido atacado y tiene " + ally + " puntos de vida");
                                    iO.Write("Pulsa el número 1 si quieres volver a atacar, 2 para cambiar pokemon, 3 para capturar");
                                    int number = iO.AskNumber();
                                    switch (number)
                                    {
                                    case 1:
                                        enemy = enemy - GetDamage();
                                        iO.Write("El pokemon enemigo ha sido atacado y tiene " + enemy + " puntos de vida");
                                        break;
                                    case 2:
                                        //ShowPokemons();
                                        break;
                                    case 3: //Mochila                 
                                        break;
                                    case 4: //capturar
                                        Capture();
                                        break;
                                    }                                                                      
                                }
                                while (copybag[0].GetActualHp() > 0 || enemypok[0].GetActualHp() > 0);
                            }
                        break;
                        case 2: //Cambiar pokemon
                            //ShowPokemons();
                            break;
                        case 3: //Mochila                 
                            break;
                        case 4: //capturar
                            Capture();
                            break;
                        case 5: //escapar
                            ExitToMenu();
                            break;
                    }
            }
            while (copybag[0].GetActualHp() > 0 || enemypok[0].GetActualHp() > 0);
            }
        }
        public void PokCenter() //Centro Pokemon
        {
            iO.WritePink(" Bienvenido al centro pokemon, aquí restauraremos al completo la vida de todos tus pokemon\n");
            for (int i = 0; i <= copybag.Length; i++)
            {
                if (copybag[i] != null)
                {
                    iO.Write("Tu pokemon tiene: "+ copybag[i].GetActualHp()+" de vida actual");
                    copybag[i].SetActualHp(copybag[i].GetMaxHp());
                    iO.Write("Tu pokemon se ha curado y vuelve a tener "+copybag[i].GetMaxHp()+" de vida máxima");
                    iO.ThreadColorsWhite("\n");
                    ExitToMenu();
                }
                else
                {
                    iO.Write("Tus pokemon ya estan curados");
                    ExitToMenu();
                }
            }
        }        
        public int GetDamage()
        {
            double damage = 0;
            double rand = 0;
            do
            {
                rand = randomvalue.NextDouble();
            } while (rand > 1 || rand < 0.85);
            damage = (((2 * 50 * (copybag[0].GetAttack() / enemypok[0].GetDefense())) / (50)) + 2) * rand * Critic();
            return (int)damage;
        }
        public double Critic()
        {
            int crit = randomvalue.Next(0, 25);
            if (crit == 0)
            {
                return 1.5;
            }
            else
            {
                return 1;
            }
        }
        public void Capture()
        {
            ratiocapture = randomvalue.Next(0, 256);
            rcm = ((3 * enemypok[0].GetMaxHp() - 2 * enemypok[0].GetActualHp()) * 4096 * ratiocapture / (3 * enemypok[0].GetMaxHp()));
            double ag = (65536 / (Math.Pow((255 / rcm), 0.1875)));
            int comparednumber = randomvalue.Next(0, 65536);
            for (int i = 0; i < 4; i++)
            {
                if (comparednumber >= ag)
                {
                    iO.Write("Oh! El pokemon ha escapado!");
                }
                else
                {
                    iO.Write("Este es el intento número: "+ i);
                }
            }
        }
        public void ExitToMenu()
        {
            ShowMenu();
            MainMenu();
        }
    }
}
