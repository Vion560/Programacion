﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista
{
    class program
    {
        static void Main(string[] args)
        {
            ListaDoble lista_doble = new ListaDoble();
            lista_doble.InsertarAtras(5);
            lista_doble.InsertarAtras(15);
            lista_doble.InsertarAtras(25);
            lista_doble.ToString();
            Console.ReadLine();
            Console.ReadLine();
        }   
        
    }
    class CrearNodo
    {
        int valor;
        CrearNodo nodo_siguiente;
        CrearNodo nodo_anterior;

        public CrearNodo(int valor)
        {
            this.nodo_siguiente = null;
            this.nodo_anterior = null;
            this.valor = valor;
        }
        public int getValor()
        {
            return valor;
        }
        public CrearNodo GetSiguiente()
        {
            return nodo_siguiente;
        }
        public void SetSiguiente(CrearNodo node)
        {
            nodo_siguiente = node;
        }
        public CrearNodo GetAnterior()
        {
            return nodo_anterior;
        }
        public void SetAnterior(CrearNodo node)
        {
            nodo_anterior = node;
        }
        public int GetValor()
        {
            return valor;
        }
    }
    public class ListaDoble
    {
        CrearNodo cabeza;
        CrearNodo cola;

        public ListaDoble()
        {
            this.cabeza = null;
            this.cola = null;
        }
        public void InsertarAtras(int valor)
        {
            CrearNodo nuevo_nod = new CrearNodo(valor);
            if (cola == null)
            {
                cola = nuevo_nod;
                cabeza = nuevo_nod;
            }
            else
            {
                CrearNodo Guardar_cola = cola;
                Guardar_cola.SetSiguiente(nuevo_nod);
                nuevo_nod.SetAnterior(Guardar_cola);
                cola = nuevo_nod;
            }
        }
        public void ToString()
        {
            CrearNodo nodo = cabeza;
            while (nodo != null)
            {
                int valor = nodo.GetValor();
                Console.WriteLine(valor);
                nodo = nodo.GetSiguiente();
            }
        }
    }
}  
