﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace EJPOK
{
    public class Game
    {
        public void Run()
        {
            IndividualPokemon pokemon = new IndividualPokemon();
            IndividualPokemon[] introPokemon = StarterPokemon(pokemon);
            IndividualPokemon[] team = MyTeam(pokemon);
            Teacher(introPokemon,team);
            ShowMenu();
            MainMenu(team);
        }
        Random randomvalue = new Random();
        int[] numrandom = new int[5];
        SpeciePokemon[] initials = IndividualPokemon.starter(); //copia los iniciales
        SpeciePokemon[] copybag = IndividualPokemon.team(); //copia el array
        SpeciePokemon[] enemypok = IndividualPokemon.EnemyPok();
        IO iO;
        int maxhp;
        int specienum;
        int actualhp;
        int attack;
        int defense;
        int speed;
        int damage;
        int crit;
        float rcm;
        float ratiocapture;
        int death = 0;
        Trainer trainer = new Trainer();
        //double ag;

        public Game(IO iO)
        {
            this.iO = iO;
        }
        public IndividualPokemon[] StarterPokemon(IndividualPokemon pokemon) //lista de los pokemon iniciales para elegir uno
        {

            IndividualPokemon[] starterpok = new IndividualPokemon[3];
            starterpok[0] = pokemon.Charmander();
            starterpok[1] = pokemon.Bulbasaur();
            starterpok[2] = pokemon.Squirtle();
            return starterpok;
        }
        public IndividualPokemon[] MyTeam(IndividualPokemon pokemon) //lista de los pokemon iniciales para elegir uno
        {

            IndividualPokemon[] teammates = new IndividualPokemon[6];
            return teammates;
        }

        public IndividualPokemon[] EnemyPokemon(IndividualPokemon pokemon) //lista de los rivales pokemon rivales posibles
        {

            IndividualPokemon[] enemypokemon = new IndividualPokemon[200];
            enemypokemon[0] = pokemon.Bulbasaur();
            enemypokemon[1] = pokemon.Ivysaur();
            enemypokemon[2] = pokemon.Venusaur();
            enemypokemon[3] = pokemon.Charmander();
            enemypokemon[4] = pokemon.Charmeleon();
            enemypokemon[5] = pokemon.Charizard();
            enemypokemon[6] = pokemon.Squirtle();
            enemypokemon[7] = pokemon.Wartortle();
            enemypokemon[8] = pokemon.Blastoise();
            enemypokemon[9] = pokemon.Caterpie();
            enemypokemon[10] = pokemon.Metapod();
            enemypokemon[11] = pokemon.Butterfree();
            enemypokemon[12] = pokemon.Weedle();
            enemypokemon[13] = pokemon.Kakuna();
            enemypokemon[14] = pokemon.Beedrill();
            enemypokemon[15] = pokemon.Pidgey();
            enemypokemon[16] = pokemon.Pidgeotto();
            enemypokemon[17] = pokemon.Pidgeot();
            enemypokemon[18] = pokemon.Rattata();
            enemypokemon[19] = pokemon.Raticate();
            enemypokemon[20] = pokemon.Spearow();
            enemypokemon[21] = pokemon.Fearow();
            return enemypokemon;
        }

        public void Teacher(IndividualPokemon[] starter,IndividualPokemon[] team) //Esta es la opción para que el profe te de la bienvenida
        {
            iO.ThreadColorsWhite("Hola, soy el profesor Ciprés. Bienvenido al mundo pokemon donde encontrarás muchos tipos de pokemon. \n");
            iO.Write("Primero dime tu nombre porfavor \n");
            string playername = iO.AskString();
            trainer.SetName(playername);
            iO.Write("Dime tu género entre chico,chica o chique\n");
            string gender = iO.AskString();
            trainer.SetGender(gender);
            if (gender != "chico" && gender != "chica" && gender != "chique")
            {
                do
                {
                    iO.Write("Por favor elige una de las tres opciones");
                    gender = iO.AskString();
                    trainer.SetGender(gender);
                }
                while (gender != "chico" && gender != "chica" && gender != "chique");
            }
            else
            {
                trainer.SetGender(gender);
            }
            iO.Write("Ahora elige: 0 si tu continente es Europa, 1 para Norte América, 2 Asia-Australia, 3 África o 4 Sur América");
            int Continent = iO.AskNumber();
            int a = GetId(Continent);
            trainer.SetId(a);
            RandomNum();
            iO.ThreadColorsWhite("Para empezar tienes que elegir entre uno de estos tres pokemon y el que eligas te lo puedes quedar y puedas empezar con él tu aventura\n");
            iO.ThreadColorsRed(" Opción 1: Charmander.\n");
            iO.ThreadColorsGreen(" Opción 2: Bulbasaur.\n");
            iO.ThreadColorsBlue(" Opción 3: Squirtle.\n");
            iO.ThreadColorsWhite(" Elige un número\n");
            Console.ForegroundColor = ConsoleColor.White;
            ChooseOne(starter, team);
        }
        public void NoTeacher() //Opción en la que directamente empiezas con un pokemon aleatorio
        {
            Console.WriteLine("Elige un pokemón: \n");
            iO.ThreadColorsRed(" Opción 1: Charmander.\n");
            iO.ThreadColorsGreen(" Opción 2: Bulbasaur.\n");
            iO.ThreadColorsBlue(" Opción 3: Squirtle.\n");
            iO.ThreadColorsWhite("\n");
        }
        public int GetId(int cont)
        {
            if (cont == 0)
            {
                int myid = randomvalue.Next(0000000000, 0999999999);
                return myid;
            }
            if (cont == 1)
            {
                int myid = randomvalue.Next(1000000000, 1999999999);
                return myid;
            }
            if (cont == 2)
            {
                int myid = randomvalue.Next(2000000000, 299999999);
                return myid;
            }
            if (cont == 3)
            {
                int myid = randomvalue.Next(300000000, 399999999);
                return myid;
            }
            //if (cont == 4)
            //{
            //    int myid = randomvalue.Next(4000000000, 4999999999);
            //    return myid;
            //}
            else
            {
                return 1000000000;
            }
        }
        public void ChooseOne(IndividualPokemon[] starter, IndividualPokemon[] team) //elige el starter y lo guarda en la bolsa
        {
            iO.Write("Escriba el número 1, 2 o 3");
            int num = iO.AskNumber();
            ChooseStarter(starter, team,num);
        }
        //public void ChooseStarter(IndividualPokemon[] starterpok, IndividualPokemon[] team, int option)
        //{
        //    if (option == 1)
        //    {
        //        team[0] = starterpok[0];
        //    }
        //    if (option == 2)
        //    {
        //        team[0] = starterpok[1];
        //    }
        //    if (option == 3)
        //    {
        //        team[0] = starterpok[2];
        //    }
        //    switch (option)
        //    {
        //        case 1:
        //            team[0] = starterpok[0];
        //            break;
        //        case 2:
        //            team[0] = starterpok[1];
        //            break;
        //        case 3:
        //            team[0] = starterpok[2];
        //            break;
        //        default:
        //            iO.Write("Solo puede elegir entre 1, 2 o 3.");
        //            ChooseOne(starterpok, team);
        //            break;
        //    }
        //}
        public int RandomNum()
        {
            int num = randomvalue.Next(000000000, 999999999);
            return num;
        }
        public void ShowMenu() //muestra el menú por pantalla
        {
            iO.Write("Menu:");
            iO.Write("	Pulsa 1 para ver tus datos como entrenador");
            iO.Write("	Pulsa 2 para ver los datos de tus pokemon");
            iO.Write("	Pulsa 3 para Combatir");
            iO.Write("	Pulsa 4 centro pokemon");
            iO.Write("	Pulsa 5 para salir");
        }
        public void MainMenu(IndividualPokemon[] team)
        {
            int opcion = iO.AskNumber();
            switch (opcion)
            {
                case 1:
                    GetTrainerInfo();
                    ExitToMenu(team);
                    break;
                case 2:
                    BasicStats(team);
                    ExitToMenu(team);
                    break;
                case 3:
                    iO.Write("	Pulsa 3 para Combatir");
                    Fight(team);
                    break;
                case 4:
                    PokCenter(team);
                    iO.Write("	Pulsa 4 centro pokemon");
                    ExitToMenu(team);
                    break;
                case 5:
                    iO.Write("Escriba 1 para cerrar el juego definitivamente o 2 para volver al menú");
                    FinishGame(team);
                    break;

            }
        }
        public void FinishGame(IndividualPokemon[] team) //opción para cerrar el juego o no
        {
            int num = iO.AskNumber();         
            switch (num)
            {
                case 1: //para cerrar el juego
                    Environment.Exit(0);
                    break;
                case 2: //volver al menu
                    ExitToMenu(team);
                    break;
            }
        }
        public void ChooseStarter(IndividualPokemon[] starterpok, IndividualPokemon[] team,int num) //elige el starter y lo guarda en la bolsa
        {
            //num = iO.AskNumber();
            switch (num)
            {
                case 1:
                    team[0] = starterpok[0];
                    team[0].SetActualHp(starterpok[0].GetActualHp());
                    iO.Write("Quieres darle un mote a Charmander? Pulsa 1 para si y 2 para no");
                    int n = iO.AskNumber();
                    switch (n)
                    {
                        case 1:
                            string name = iO.AskString();
                            team[0].SetPokName(name);
                            break;
                        case 2:
                            break;
                    }
                    break;
                case 2:
                    team[0] = starterpok[1];
                    team[0].SetActualHp(starterpok[1].GetActualHp());
                    iO.Write("Quieres darle un mote a Bulbasaur? Pulsa 1 para si y 2 para no");
                    int n1 = iO.AskNumber();
                    switch (n1)
                    {
                        case 1:
                            string name = iO.AskString();
                            team[0].SetPokName(name);
                            break;
                        case 2:
                            break;
                    }
                    break;
                case 3:
                    team[0] = starterpok[2];
                    team[0].SetActualHp(starterpok[2].GetActualHp());
                    iO.Write("Quieres darle un mote a Squirtle? Pulsa 1 para si y 2 para no");
                    int n2 = iO.AskNumber();
                    switch (n2)
                    {
                        case 1:
                            string name = iO.AskString();
                            team[0].SetPokName(name);
                            break;
                        case 2:
                            break;
                    }
                    break;
                default:
                    iO.Write("Por favor eliga una opción correcta");
                    //ChooseStarter(StarterPokemon, MyTeam);
                    break;
            }
        }

        public void Fight(IndividualPokemon[] team) //Combate
        {
            if (team[0].GetActualHp() > 0)
            {
                do
                {
                    iO.Write("Pulsa 1 para Comenzar la pelea");
                    iO.Write("Pulsa 2 para cambiar pokemon");
                    iO.Write("Pulsa 3 para Capturar");
                    iO.Write("Pulsa 4 para Volver al menú");
                    int num = iO.AskNumber();
                    switch (num)
                    {
                        case 1: //atacar
                            if (team[0].GetSpeed() >= enemypok[0].GetSpeed())
                            {
                                int enemy = enemypok[0].GetActualHp();
                                int ally = team[0].GetActualHp();
                                iO.Write("Tu pokemon ha empezado el combate con " + ally + " de vida ");
                                iO.Write("El pokemon enemigo ha empezado el combate con " + enemy + " de vida ");
                                do
                                {
                                    if (enemy <= 0)
                                    {
                                        Console.WriteLine("El pokemon enemigo ha sido derrotado");
                                        team[0].SetActualHp(ally);
                                        ExitToMenu(team);
                                        break;
                                    }
                                    if (ally <= 0)
                                    {
                                        Console.WriteLine("Tu pokemon ha sido derrotado :(");
                                        team[0].SetActualHp(0);
                                        ExitToMenu(team);
                                        break;
                                    }
                                    iO.Write("Pulsa el número 1 si quieres volver a atacar, 2 para cambiar pokemon, 3 para capturar");
                                    int number = iO.AskNumber();
                                    switch (number)
                                    {
                                        case 1:
                                            enemy = enemy - GetDamage(team);
                                            iO.Write("El pokemon enemigo ha sido atacado y tiene " + enemy + " puntos de vida");
                                            break;
                                        case 2:
                                            //ShowPokemons(); //muestra pokemons k tienes para poder cambiar
                                            break;
                                        case 3: //Mochila                 
                                            break;
                                        case 4: //capturar
                                            Capture();
                                            break;
                                    }
                                    ally = ally - GetDamage(team);
                                    iO.Write("Tu pokemon ha sido atacado y tiene " + ally + " puntos de vida");
                                }
                                while (team[0].GetActualHp() > 0 || enemypok[0].GetActualHp() > 0);
                            }
                            else
                            {
                                int ally;
                                ally = team[0].GetActualHp();
                                int enemy;
                                enemy = enemypok[0].GetActualHp();
                                iO.WriteInt(enemy);
                                iO.WriteInt(ally);
                                iO.Write("Tu pokemon ha empezado el combate con " + ally + " de vida ");
                                iO.Write("El pokemon enemigo ha empezado el combate con " + enemy + " de vida ");
                                do
                                {
                                    if (enemy <= 0)
                                    {
                                        Console.WriteLine("El pokemon enemigo ha sido derrotado");
                                        team[0].SetActualHp(ally);
                                        ExitToMenu(team);
                                        break;
                                    }
                                    if (ally <= 0)
                                    {
                                        Console.WriteLine("Tu pokemon ha sido derrotado :(");
                                        team[0].SetActualHp(0);
                                        ExitToMenu(team);
                                        break;
                                    }
                                    ally = ally - GetDamage(team);
                                    iO.Write("Tu pokemon ha sido atacado y tiene " + ally + " puntos de vida");
                                    iO.Write("Pulsa el número 1 si quieres volver a atacar, 2 para cambiar pokemon, 3 para capturar");
                                    int number = iO.AskNumber();
                                    switch (number)
                                    {
                                        case 1:
                                            enemy = enemy - GetDamage(team);
                                            iO.Write("El pokemon enemigo ha sido atacado y tiene " + enemy + " puntos de vida");
                                            break;
                                        case 2:
                                            //ShowPokemons();
                                            break;
                                        case 3: //Mochila                 
                                            break;
                                        case 4: //capturar
                                            Capture();
                                            break;
                                    }
                                }
                                while (team[0].GetActualHp() > 0 || enemypok[0].GetActualHp() > 0);
                            }
                            break;
                        case 2: //Cambiar pokemon
                            //ShowPokemons();
                            break;
                        case 3: //Mochila                 
                            break;
                        case 4: //capturar
                            Capture();
                            break;
                        case 5: //escapar
                            ExitToMenu(team);
                            break;
                    }
                }
                while (copybag[0].GetActualHp() > 0 || enemypok[0].GetActualHp() > 0);
            }
        }
        public void ShowPokemons(IndividualPokemon[] team) //muestra los datos de tus pokemons de la bolsa
        {
            for (int i = 0; i < team.Length; i++)
            {
                if (team[i] != null)
                {
                    iO.Write("Tus pokemon son: " + team[i].GetName() + ",con " + team[i].GetMaxHp() + " de vidamáxima, " + team[i].GetActualHp() + " de vida actual, " + team[i].GetAttack() + " de ataque, " + team[i].GetDefense() + " de defensa, " + team[i].GetSpeed() + " de velocidad. ");
                }
            }
        }
        public void PokCenter(IndividualPokemon[] team) //Centro Pokemon
        {
            iO.WritePink(" Bienvenido al centro pokemon, aquí restauraremos al completo la vida de todos tus pokemon\n");
            for (int i = 0; i <= team.Length; i++)
            {
                if (team[i] != null)
                {
                    iO.Write("Tu pokemon tiene: "+ team[i].GetActualHp()+" de vida actual");
                    team[i].SetActualHp(team[i].GetMaxHp());
                    iO.Write("Tu pokemon se ha curado y vuelve a tener "+ team[i].GetMaxHp()+" de vida máxima");
                    iO.ThreadColorsWhite("\n");
                }
                else
                {
                    iO.Write("Tus pokemon ya estan curados");
                    ExitToMenu(team);
                }
            }
        }
        public void GetTrainerInfo()
        {
            iO.Write("Tu nombre es " + trainer.GetName() + " , tu género es " + trainer.GetGender() + " , tu ID es " + trainer.GetId());
        }
        public void BasicStats(IndividualPokemon[] team)
        {
            for (int i = 0; i < team.Length; i++)
            {
                if (team[i] != null)
                {
                    iO.Write("Tu pokemon de mote " + team[i].GetPokName() + " con una vida actual de " + team[i].GetActualHp() + " una vida máxima de " + team[i].GetMaxHp()); //falta lo de especie porque tiene mote pero no nombre de especie bulbasaur
                }
            }
            //iO.Write("Si quieres ver todas las estadísticas de uno de tus pokemon pulsa 1 y si no 2");
            //int n = iO.AskNumber();
            //switch(n)
            //{
            //    case 1:
            //        iO.Write("Elige un pokemon de los que tienes para ver más estadísticas , el primero es el 0");
            //        int num = iO.AskNumber();
            //        ShowPokemons(num);
            //        break;
            //    case 2:
            //        ShowMenu();
            //        MainMenu();
            //        break;
            //}          
        }
        public void ShowPokemons(IndividualPokemon[] team,int num) //muestra los datos de tus pokemons de la bolsa
        {
            for(int i = 0; i < team.Length; i++)
            {
                if(team[i] != null)
                {
                iO.Write("Tus pokemon son: " + team[i].GetName() + ",con " + team[i].GetMaxHp() + " de vida máxima, " + team[i].GetActualHp() + " de vida actual, " + team[i].GetAttack() + " de ataque, " + team[i].GetDefense() + " de defensa, " + team[i].GetSpeed() + " de velocidad. ");
                }
            }
        }
        public int GetDamage(IndividualPokemon[] team)
        {
            double damage = 0;
            double rand = 0;
            do
            {
                rand = randomvalue.NextDouble();
            } while (rand > 1 || rand < 0.85);
            damage = (((2 * 50 * (team[0].GetAttack() / enemypok[0].GetDefense())) / (50)) + 2) * rand * Critic();
            return (int)damage;
        }
        public double Critic()
        {
            int crit = randomvalue.Next(0, 25);
            if (crit == 0)
            {
                return 1.5;
            }
            else
            {
                return 1;
            }
        }
        public void Capture()
        {
            ratiocapture = randomvalue.Next(0, 256);
            rcm = ((3 * enemypok[0].GetMaxHp() - 2 * enemypok[0].GetActualHp()) * 4096 * ratiocapture / (3 * enemypok[0].GetMaxHp()));
            double ag = (65536 / (Math.Pow((255 / rcm), 0.1875)));
            int comparednumber = randomvalue.Next(0, 65536);
            for (int i = 0; i < 4; i++)
            {
                if (comparednumber >= ag)
                {
                    iO.Write("Oh! El pokemon ha escapado!");
                }
                else
                {
                    iO.WriteInt(i);
                }
            }
        }
        public void ExitToMenu(IndividualPokemon[] team)
        {
            ShowMenu();
            MainMenu(team);
        }
    }
}
