﻿using EJPOK;
using System;
using System.Threading;

namespace Pokemon
{
    class Program
    {
        static void Main(string[] args)
        {
            IO io = new IO();
            Game g = new Game(io);       
            g.Run();
        }
    }
}