﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJPOK
{
    public class SpeciePokemon
    {
        int[] numrandom = new int[5];
        int maxhp;
        int actualhp;
        int attack;
        int defense;
        int speed;
        string name;
        float ratiocapture;
        bool male;

        public SpeciePokemon(string name, int maxhp, int actualhp, int att, int def, int speed) //Le das tu los valores al pokemon
        {
            this.name = name;
            this.maxhp = maxhp;
            this.actualhp = actualhp;
            this.attack = att;
            this.defense = def;
            this.speed = speed;
        }
        public SpeciePokemon(string name, int maxhp, int att, int def, int speed) //Le das tu los valores al pokemon
        {
            this.name = name;
            this.maxhp = maxhp;
            this.attack = att;
            this.defense = def;
            this.speed = speed;
        }
        public string GetName()
        {
            return name;
        }
        public void SetName(string name)
        {
            this.name = name;
        }
        public int GetActualHp()
        {
            return actualhp;
        } //Da valor a la vida actual
        public void SetActualHp(int actualhp)
        {
            this.actualhp = actualhp;
        } //Da la vida actual
        public int GetMaxHp()
        {
            return maxhp;
        } //Muestra la vida máxima
        public void SetMaxHp(int maxhp)
        {
            this.maxhp = maxhp;
        } //Da valor a la vida máxima
        public int GetAttack()
        {
            return attack;
        } //Muestra el ataque
        public void SetAttack(int att)
        {
            this.attack = att;
        } //Da valor al ataque
        public int GetDefense()
        {
            return defense;
        } //Muestra la defensa
        public void SetDefense(int def)
        {
            this.defense = def;
        }//Da valor a la defensa
        public int GetSpeed()
        {
            return speed;
        } //Muestra la velocidad
        public void SetSpeed(int speed)
        {
            this.speed = speed;
        } //Da valor a la velocidad
    }
}
