﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJPOK
{
    public class IO
    {
        public void ThreadColorsRed(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                }
            }
        }
        public void ThreadColorsGreen(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                }
            }
        }

        public void ThreadColorsWhite(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(15);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
        }
        public void ThreadColorsBlue(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                }
            }
        }
        public string ChoosePok()
        {
            int pok;
            IO io = new IO();
            SpeciePokemon[] starter = IndividualPokemon.starter();
            pok = int.Parse(Console.ReadLine());
            if (pok == 1)
            {
                return "Has elegido a " + starter[0].GetName() + " con " + starter[0].GetMaxHp() + " de vida, " + starter[0].GetAttack() + " de ataque, " + starter[0].GetDefense() + " de defensa, " + starter[0].GetSpeed() + " de velocidad.";
                
            }
            if (pok == 2)
            {
                return "Has elegido a " + starter[1].GetName() + " con " + starter[1].GetMaxHp() + " de vida, " + starter[1].GetAttack() + " de ataque, " + starter[1].GetDefense() + " de defensa, " + starter[1].GetSpeed() + " de velocidad.";
            }
            if (pok == 3)
            {
                return "Has elegido a " + starter[2].GetName() + " con " + starter[2].GetMaxHp() + " de vida, " + starter[2].GetAttack() + " de ataque, " + starter[2].GetDefense() + " de defensa, " + starter[2].GetSpeed() + " de velocidad.";
            }
            else
            {
                return "Como no has elegido a ninguno elegimos a " + starter[0].GetName() + " con " + starter[0].GetMaxHp() + " de vida, " + starter[0].GetAttack() + " de ataque, " + starter[0].GetDefense() + " de defensa, " + starter[0].GetSpeed() + " de velocidad.";
            }
        }
        //public string ShowPokemon()
        //{
        //    IO iO = new IO();
        //    return iO.Write(IndividualPokemon.bag);
        //}       
        
        public void Write(string a)
        {
            Console.WriteLine(a);
        }
        public Array[] WriteArray(Array[] a)
        {
            return a;
        }
        public string Read()
        {
            return Console.ReadLine();
        }
        public int AskNumber()
        {
            return int.Parse(Console.ReadLine());
        }
        public char AskLetter(char lett)
        {
            Console.WriteLine("Dame una letra");
            return lett;
        }
        public int RandomValues(int a, int b)
        {
            Random random = new Random();
            int number = random.Next(a, b);
            return number;
        }
        public int IntToString()
        {
            int number = int.Parse(Console.ReadLine());
            return number;
        }
    }
}
