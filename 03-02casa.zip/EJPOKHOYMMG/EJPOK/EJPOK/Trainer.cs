﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace EJPOK
{
    class Trainer
    {
        string username;
        string gender;
        int id;
        int SecretNumber;
        int pokedolars;
        int pokemillas;
        int battlepoints;
        double gametime;
        SpeciePokemon[] MyTeam = new SpeciePokemon[6];
        public void SetName(string name)
        {
            this.username = name;
        }
        public string GetName()
        {
            return username;
        }
        public void SetGender(string gender)
        {
            this.gender = gender;
        }
        public string GetGender()
        {
            return gender;
        }
        public void SetId(int id)
        {
            this.id = id;
        }
        public int GetId()
        {
            return id;
        }
        public void SetPokedolLars(int dollars)
        {
            this.pokedolars = dollars;
        }
        public int GetPokedollars()
        {
            return pokedolars;
        }
        public void SetPokemillas(int pokemillas)
        {
            this.pokemillas = pokemillas;
        }
        public int GetPokemillas()
        {
            return pokemillas;
        }
        public void SetBattlePoints(int battlepoints)
        {
            this.battlepoints = battlepoints;
        }
        public int GetBattlePoints()
        {
            return battlepoints;
        }
    }
}
