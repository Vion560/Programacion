﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJPOK
{
    public class IndividualPokemon
    {
        int actualhp;
        public static SpeciePokemon[] starter()
        {
            SpeciePokemon[] starter = new SpeciePokemon[3];
            starter[0] = new SpeciePokemon("Charmander", 39, 52, 39, 65);
            starter[1] = new SpeciePokemon("Bulbasaur", 45, 49, 49, 45);
            starter[2] = new SpeciePokemon("Squirtle", 44, 48, 65, 43);
            return starter;
        }
        public static SpeciePokemon[] EnemyPok()
        {
            SpeciePokemon[] enemypok = new SpeciePokemon[6];
            enemypok[0] = new SpeciePokemon("Pidgey", 40, 45, 40, 56);
            enemypok[1] = new SpeciePokemon("Caterpie", 45, 30, 35, 45);
            enemypok[2] = new SpeciePokemon("Pikachu", 35, 55, 40, 90);
            enemypok[3] = new SpeciePokemon("Nidoran♀", 55, 47, 52, 41);
            enemypok[4] = new SpeciePokemon("Nidoran♂", 46, 57, 40, 50);
            enemypok[5] = new SpeciePokemon("Weedle", 40, 35, 30, 50);
            return enemypok;
        }
        public static SpeciePokemon[] bag()
        {
            int date;
            SpeciePokemon[] mypoks = new SpeciePokemon[6];
            return mypoks;
        }
    }
}
