﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace triangulos
{
    class triangulo
    {
        //3 puntos como atributos
        //1 constructor que reciba los 3 puntos
        //metodo dibujar
        //clase hijo de triang k sea isosceles
        //1 constrc con 2 puntos
        //clase hija equilatero
        //1 constrc con centro y distancia del centro al vertice
        int p1;
        int p2;
        int p3;
        public triangulo(int p1, int p2, int p3)
        {
            this.p1 = p1;
            this.p2 = p2;
            this.p3 = p3;
        }
        public void paint()
        {
            for (p1 = 0; p1 <= p3; p1++)
            {
                for (p2 = p3; p2 > 0; p2--)
                {
                    Console.WriteLine(" ");
                }
                for (p2 = 1; p2 < p1; p2++)
                {
                    Console.WriteLine("**");
                }
                Console.WriteLine("*");
            }
        }
    }
}
