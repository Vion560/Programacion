﻿// See https://aka.ms/new-console-template for more information
using System;
using triangulos;

namespace Triangulos
{
    class Program
    {
        static void Main(string[] args)
        {
            triangulo t = new triangulo(3, 5, 9);
            t.paint();
        }
    }
}