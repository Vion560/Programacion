﻿using System;

namespace ConsoleApp8
{
    class Program
    {
        static void Main(string[] args)
        {
            //clase persona con nombre y apellidos, un atributo cromosoma que es un array de 20 con valores a,c,g,t de forma aleatoria.
            //obtener una muestra de adn aleatoria y hay que buscar en la lista de sospechosos cual es el que mas se parece(cuando coincide)
            //al final dices quien es y el porcentaje de parecido.
            Persona persona1 = new Persona();
        }
    }
}
