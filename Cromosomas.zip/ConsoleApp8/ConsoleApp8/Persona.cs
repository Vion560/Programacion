﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp8
{
    class Persona
    {
        string name;
        string surname;
        string cromosoma;
        public Persona(string name, string surname)
        {
            this.name = name;
            this.surname = surname;
        }
        public Persona()
        {
            name = "";
            surname = "";
        }
        public string GetName(string name)
        {
            return name;
        }
        public void SetName(string name)
        {
            this.name = name;
        }
        public string GetSurname(string surname)
        {
            return surname;
        }
        public void SetSurname(string surname)
        {
            this.surname = surname;
        }
        public void Person()
        {
            Random r = new Random();
            int[] cromosoma = new int[20];
            for (int i = 0; i < cromosoma.Length; ++i)
            {
                cromosoma[i] = r.Next(0,3);
                if(cromosoma[i] == 1)
                {

                }
                Console.WriteLine(cromosoma[i]);
            }
        }
    }
}
