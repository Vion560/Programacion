﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.IO;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace pokemon
{
    internal class IO
    {

        //Esta clase sirve para crear funciones de escritura, enseñar los pokémon de una lista y demás.
        int timeThreadSleep = 0; //10;

        //Está método te enseña los distintos pokémon de una lista
        public void ShowPokemon(SinglePokemon[] pokemonList)
        {
            for (int i = 0; i<pokemonList.Length; i += 1)
            {
                if (pokemonList[i] != null)
                {
                    ThreadTextLine(PokemonToString(pokemonList[i], i));
                }
            }
        }

        public void ShowNamePokemon(SinglePokemon[] pokemonList)
        {
            for (int i = 0; i < pokemonList.Length; i += 1)
            {
                if (pokemonList[i] != null)
                {
                    ThreadTextLine("\tPokemon " + (i + 1) + ": " + pokemonList[i].GetNickname());
                }
            }
        }

        public int ShowCases(SinglePokemon[][] _cases)
        {
            int counter = 0;
            int counter2 = 0;
            int[] casesNotNull = new int[_cases.Length];
            int k = 0;
            for (int i = 0; i < casesNotNull.Length; i += 1)
            {
                casesNotNull[i] = 404; //Esto me sirve para que el null de los int sea 404 en vez de 0.
            }
            for (int i = 0; i < _cases.Length; i += 1)
            {
                counter2 = 0;
                for (int j = 0; j < _cases[i].Length; j += 1)
                {
                    if (_cases[i][j] == null)
                    {
                        counter += 1; // Guardamos el número de espacios que hay en las distintas cajas, para saber si está cada una vacía.
                        counter2 += 1;
                    }
                }

                if (counter2 != 30)
                {
                    casesNotNull[k] = i; //Guardamos el número de la caja que no está vacía.
                    k += 1;
                }
            }

            if (counter == (_cases.Length * _cases[0].Length))
            {
                Console.WriteLine("\n Todas las cajas están vacías.");
                return 0;
            }
            else
            {
                ThreadText("\n Las cajas que no están vacías son ");
                for (int i = 0; i < casesNotNull.Length; i += 1)
                {
                    if (casesNotNull[i] != 404)
                    {
                        if(i > 0) //Mostramos el número de caja no vacía, para ello utilizamos el código 404 que nos dice si esta vacía.
                        {
                            if (!(casesNotNull[i] == casesNotNull[i - 1]))
                            {
                                ThreadText((casesNotNull[i] + 1) + " ");
                            }
                        }
                        else
                        {
                            ThreadText((casesNotNull[i] + 1) + " ");
                        }
                    }
                }
                Console.WriteLine();
                bool check = false;
                int chooseCase;
                do
                {
                    chooseCase = ReadInt("\n ¿Qué caja quieres ver?: ");
                    for (int i = 0; i < casesNotNull.Length; i += 1)
                    {
                        if (chooseCase - 1 == casesNotNull[i]) //Comprobamos si el número que nos pide coincide con alguna caja que no este vacía.
                        {
                            check = true;
                            break;
                        }
                    }
                    if(check == false)
                    {
                        ThreadTextLine("\n Por favor elige una caja que no este vacía.");
                    }
                } while (check == false);
                ThreadTextLine("\n Estos son tus pokémon de la caja " + chooseCase);
                ShowNamePokemon(_cases[chooseCase - 1]);
                int option;
                do
                {
                    option = ReadInt("\n ¿Quieres ver la información de algún pokémon?(1-Sí, 2-No): ");
                    if (!((option == 1) || (option == 2)))
                    {
                        ThreadTextLine("\n Por favor elige 1 o 2");
                    }
                } while (!((option == 1) || (option == 2)));

                if(option == 1)
                {
                    PokemonToShow(_cases, chooseCase);
                }

                return chooseCase;
            }
        }

        public void PokemonToShow(SinglePokemon[][] _cases, int _case)
        {
            int choosePokemon;
            do
            {
                choosePokemon = ReadInt("\n ¿Qué pokémon quieres ver?: ");
                if (_cases[_case - 1][choosePokemon - 1] == null)
                {
                    Console.WriteLine("\n Por favor elige un pokémon de la lista");
                }
            } while (_cases[_case - 1][choosePokemon - 1] == null);

            PokemonToString(_cases[_case - 1][choosePokemon - 1], choosePokemon - 1);

            int option;
            do
            {
                option = ReadInt("\n\n ¿Alguno más?(1-Sí, 2-No): ");
                if (!((option == 1) || (option == 2)))
                {
                    ThreadTextLine("\n Por favor escoga 1 o 2.");
                }
            } while (!((option == 1) || (option == 2)));
            if (option == 1)
            {
                PokemonToShow(_cases, _case);
            }
            else
            {
                return;
            }
        }
        //Esta método te escribe el texto de forma secuencial además de hacer un salto de línea.
        public void ThreadTextLine(string _text)
        {
            Random random = new Random();
            for (int i = 0; i<_text.Length; i += 1)
            {
                Console.Write(_text[i]);
                Thread.Sleep(timeThreadSleep);
            }
            Console.WriteLine();
        }

        //Esta método te escribe el texto de forma secuencial pero no hace salto de línea.
        public void ThreadText(string _text)
        {
            Random random = new Random();
            for (int i = 0; i<_text.Length; i += 1)
            {
                Console.Write(_text[i]);
                Thread.Sleep(timeThreadSleep);
            }
        }

        //Esta método te sirve para leer texto
        public string ReadString(string _text)
        {
            ThreadText(_text);
            return Console.ReadLine();
        }

        //Está método te lee un string y te lo transforma a entero, es decir, sirve para leer enteros.
        public int ReadInt(string _text)
        {
            ThreadText(_text);
            return int.Parse(Console.ReadLine());
        }

        //Esta método sirve para enseñar los datos de cada pokémon
        public string PokemonToString(SinglePokemon pokemon, int i)
        {

            switch (pokemon.GetCached())
            {
                //Muestra datos si el pokemon no ha sido capturado
                case false:
                    if (pokemon.GetNickname() == pokemon.GetSpecieName())
                    {
                        ThreadText("\n Pokemon " + (i + 1));
                        ThreadText("\n\tNombre: ");
                        ChangeColor(pokemon.GetSpecieName(), "darkBlue");
                        ThreadText("\n\tID: ");
                        ChangeColor(Convert.ToString(pokemon.GetId()), "red");
                        ThreadText("\n\tGénero: ");
                        ChangeColor(pokemon.GetGender(), "blue");
                        ThreadText("\n\tMáximo Hp: ");
                        ChangeColor(Convert.ToString(pokemon.GetMaxHp()), "green");
                        ThreadText("\n\tActual Hp: ");
                        ChangeColor(Convert.ToString(pokemon.GetActualHp()), "green");
                        ThreadText("\n\tNivel de Ataque: ");
                        ChangeColor(Convert.ToString(pokemon.GetLevelAttack()), "yellow");
                        ThreadText("\n\tNivel de defensa: ");
                        ChangeColor(Convert.ToString(pokemon.GetLevelDefend()), "yellow");
                        ThreadText("\n\tVelocidad: ");
                        ChangeColor(Convert.ToString(pokemon.GetSpeed()), "magenta");
                        ThreadText("\n\tHa sido capturado: ");
                        ChangeColor("No", "darkRed");
                        return "";
                    }
                    else
                    {
                        ThreadText("\n Pokemon " + (i + 1));
                        ThreadText("\n\tEspecie: ");
                        ChangeColor(pokemon.GetSpecieName(), "darkBlue");
                        ThreadText("\n\tNombre: ");
                        ChangeColor(pokemon.GetNickname(), "darkBlue");
                        ThreadText("\n\tID: ");
                        ChangeColor(Convert.ToString(pokemon.GetId()), "red");
                        ThreadText("\n\tGénero: ");
                        ChangeColor(pokemon.GetGender(), "blue");
                        ThreadText("\n\tMáximo Hp: ");
                        ChangeColor(Convert.ToString(pokemon.GetMaxHp()), "green");
                        ThreadText("\n\tActual Hp: ");
                        ChangeColor(Convert.ToString(pokemon.GetActualHp()), "green");
                        ThreadText("\n\tNivel de Ataque: ");
                        ChangeColor(Convert.ToString(pokemon.GetLevelAttack()), "yellow");
                        ThreadText("\n\tNivel de defensa: ");
                        ChangeColor(Convert.ToString(pokemon.GetLevelDefend()), "yellow");
                        ThreadText("\n\tVelocidad: ");
                        ChangeColor(Convert.ToString(pokemon.GetSpeed()), "magenta");
                        ThreadText("\n\tHa sido capturado: ");
                        ChangeColor(" No", "darkRed");
                        return "";
                    }

                //Muestra datos si el pokémon si ha sido caturado, es decir, además de los anteriores, le añado la fecha y hora de captura
                case true:
                    if (pokemon.GetNickname() == pokemon.GetSpecieName())
                    {
                        ThreadText("\n Pokemon " + (i + 1));
                        ThreadText("\n\tNombre: ");
                        ChangeColor(pokemon.GetSpecieName(), "darkBlue");
                        ThreadText("\n\tID: ");
                        ChangeColor(Convert.ToString(pokemon.GetId()), "red");
                        ThreadText("\n\tGénero: ");
                        ChangeColor(pokemon.GetGender(), "blue");
                        ThreadText("\n\tMáximo Hp: ");
                        ChangeColor(Convert.ToString(pokemon.GetMaxHp()), "green");
                        ThreadText("\n\tActual Hp: ");
                        ChangeColor(Convert.ToString(pokemon.GetActualHp()), "green");
                        ThreadText("\n\tNivel de Ataque: ");
                        ChangeColor(Convert.ToString(pokemon.GetLevelAttack()), "yellow");
                        ThreadText("\n\tNivel de defensa: ");
                        ChangeColor(Convert.ToString(pokemon.GetLevelDefend()), "yellow");
                        ThreadText("\n\tVelocidad: ");
                        ChangeColor(Convert.ToString(pokemon.GetSpeed()), "magenta");
                        ThreadText("\n\tHa sido capturado: ");
                        ChangeColor("Si", "darkRed");
                        ThreadText("\n\tFecha de captura: ");
                        ChangeColor(pokemon.GetCatchDate().ToString("d"), "darkCyan");
                        ThreadText("\n\tHora de captura: ");
                        ChangeColor(pokemon.GetCatchHour().ToString("H:mm:ss"), "darkCyan");
                        ThreadText("\n\tEo: ");
                        ChangeColor(pokemon.GetEo(), "darkYellow");
                        return "";
                    }
                    else
                    {
                        ThreadText("\n Pokemon " + (i + 1));
                        ThreadText("\n\tEspecie: ");
                        ChangeColor(pokemon.GetSpecieName(), "darkBlue");
                        ThreadText("\n\tNombre: ");
                        ChangeColor(pokemon.GetNickname(), "darkBlue");
                        ThreadText("\n\tID: ");
                        ChangeColor(Convert.ToString(pokemon.GetId()), "red");
                        ThreadText("\n\tGénero: ");
                        ChangeColor(pokemon.GetGender(), "blue");
                        ThreadText("\n\tMáximo Hp: ");
                        ChangeColor(Convert.ToString(pokemon.GetMaxHp()), "green");
                        ThreadText("\n\tActual Hp: ");
                        ChangeColor(Convert.ToString(pokemon.GetActualHp()), "green");
                        ThreadText("\n\tNivel de Ataque: ");
                        ChangeColor(Convert.ToString(pokemon.GetLevelAttack()), "yellow");
                        ThreadText("\n\tNivel de defensa: ");
                        ChangeColor(Convert.ToString(pokemon.GetLevelDefend()), "yellow");
                        ThreadText("\n\tVelocidad: ");
                        ChangeColor(Convert.ToString(pokemon.GetSpeed()), "magenta");
                        ThreadText("\n\tHa sido capturado: ");
                        ChangeColor("Si", "darkRed");
                        ThreadText("\n\tFecha de captura: ");
                        ChangeColor(pokemon.GetCatchDate().ToString("d"), "darkCyan");
                        ThreadText("\n\tHora de captura: ");
                        ChangeColor(pokemon.GetCatchHour().ToString("H:mm:ss"), "darkCyan");
                        ThreadText("\n\tEo: ");
                        ChangeColor(pokemon.GetEo(), "darkYellow");
                        return "";
                    }

                default:
                    ThreadText("\n Pokemon " + (i + 1));
                    ThreadText("\n\tNombre: ");
                    ChangeColor(pokemon.GetSpecieName(), "darkBlue");
                    ThreadText("\n\tID: ");
                    ChangeColor(Convert.ToString(pokemon.GetId()), "red");
                    return "";
            }
        }

        public void ProfileToString(Trainer trainer)
        {
            ThreadText("\n\tNombre: ");
            ChangeColor(trainer.GetName(), "blue");
            ThreadText("\n\tGénero: ");
            ChangeColor(trainer.GetGender(), "magenta");
            ThreadText("\n\tID: ");
            ChangeColor(trainer.GetId(), "red");
            ThreadText("\n\tDinero: ");
            ThreadText("\n\t\tPokeDollars: ");
            ChangeColor(Convert.ToString(trainer.GetPokeDollars()), "green");
            ThreadText("\n\t\tPokeSeeds: ");
            ChangeColor(Convert.ToString(trainer.GetPokeSeeds()), "green");
            ThreadText("\n\t\tPuntos de batalla: ");
            ChangeColor(Convert.ToString(trainer.GetBattlePoints()), "green");
            Console.WriteLine();
            ThreadText("\n\tTiempo de juego: ");
            ChangeColor(CountTime(trainer.GetDateStart(), trainer.GetDateEnd()), "yellow");
            //nombre, género, número de ID, tiempo que lleva jugado (calculado a partir de la fecha de inicio de la aventura) y dinero.
        }

        public void ChangeColor(string text, string color)
        {
            switch (color)
            {
                case "darkBlue":
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                    ThreadText(text);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;
                case "darkRed":
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    ThreadText(text);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;

                case "darkCyan":
                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                    ThreadText(text);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;

                case "darkGreen":
                    Console.ForegroundColor = ConsoleColor.DarkGreen;
                    ThreadText(text);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;

                case "darkYellow":
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    ThreadText(text);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;

                case "red":
                    Console.ForegroundColor = ConsoleColor.Red;
                    ThreadText(text);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;
                case "blue":
                    Console.ForegroundColor = ConsoleColor.Blue;
                    ThreadText(text);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;
                case "green":
                    Console.ForegroundColor = ConsoleColor.Green;
                    ThreadText(text);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;
                case "yellow":
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    ThreadText(text);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;
                case "magenta":
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    ThreadText(text);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;            
                default:
                    Console.ForegroundColor = ConsoleColor.Gray;
                    ThreadText(text);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;
            }
        }        

        //Esta método sirve para introducir o cambiar de pokémon en la lista y posición que se quiera.
        public void ChangePokemon(SinglePokemon pokemonToChange, SinglePokemon[] listPokemonToAdd, int position)
        {
            listPokemonToAdd[position] = pokemonToChange;
        }

        public void ChangePokemonDoubleArray(SinglePokemon pokemonToChange, SinglePokemon[][] listPokemonToAdd, int position1, int position2)
        {
            listPokemonToAdd[position1][position2] = pokemonToChange;
        }

        //Esta método da un poco de estilo al juego.
        public void LineSeparator()
        {
            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------------------------");
            Console.WriteLine();

        }

        public void Space()
        {
            Console.WriteLine();
        }

        static string CountTime(DateTime date, DateTime date2)
        {
            //Calculamos el tiempo del primer date.
            int startHour = int.Parse(date.ToString("HH"));
            int startMin = int.Parse(date.ToString("mm"));
            int startSec = int.Parse(date.ToString("ss"));
            int timeStartSec = (startHour * 60 * 60) + (startMin * 60) + startSec; //Pasamos todos a segundos y los sumamos.

            //Calculamos el tiempo del segundo date.
            int endHour = int.Parse(date2.ToString("HH"));
            int endMin = int.Parse(date2.ToString("mm"));
            int endSec = int.Parse(date2.ToString("ss"));
            int timeEndSec = (endHour * 60 * 60) + (endMin * 60) + endSec;

            int tiempoTotal = timeEndSec - timeStartSec;

            //Convertir de segundos a horas segundos y minutos
            int totalTimeHour = tiempoTotal / 360;
            int totalTimeMin = tiempoTotal / 60;
            int totalTimeSec = tiempoTotal % 60;

            return totalTimeHour + " h, " + totalTimeMin + " m y " + totalTimeSec + " s.";
        }
    }
}
