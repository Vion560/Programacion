﻿using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace pokemon
{
    class SpeciePokemon
    {
        //Creo variables para las clases.
        Random random = new Random();

        //Creo los diferentes atributos de los pokémon
        string specieName; //Esta variable se asocia con el nombre
        int id; //Esta variable te dice la especie del pokémon
        int maxHp; //Esta variable se asocia con el máximo de vida del pokémon
        int actualHp; //Está variable se asocia con la vida actual del pokémon
        int levelAttack; //Esta variable se asocia con el nivel de ataque del pokémon
        int levelDefend; //Esta variable se asocia con el nivel de defensa del pokémon
        int speed; //Esto es la velocidad de los pokemon, para la hora de atacar.
        int catchRate; //Esta variable se asocia con la porbabilidad de capturar el pokémon

        //Constructor por defecto.
        public SpeciePokemon()
        {
            specieName = "pokemon";
            maxHp= 10;
            actualHp= 10;
            levelAttack= 10;
            levelDefend= 10;
            speed= 10;
            id = 0;
            catchRate= 10;
        }

        //Constructor con valores.
        public SpeciePokemon(string newSpecieName, int newId, int newMaxHp, int newLevelAttack, int newLevelDefend, int newSpeed, int newCatchRate)
        {
            specieName = newSpecieName;
            maxHp = newMaxHp;
            actualHp = newMaxHp;
            levelAttack= newLevelAttack;
            levelDefend= newLevelDefend;
            speed = newSpeed;
            id = newId;
            catchRate = newCatchRate;
        }

        //Setter

        public void SetName(string newSpecieName)
        {
            specieName = newSpecieName;
        }

        public void SetId(int newId)
        {
            id = newId;
        }

        public void SetMaxHp(int newMaxHp)
        {
            maxHp = newMaxHp;
        }

        public void SetActualHp(int newActualHp)
        {
            actualHp = newActualHp;
        }

        public void SetLevelAttack(int newLevelAttack)
        {
            levelAttack = newLevelAttack;
        }

        public void SetDefendAtack(int newDefendAtack)
        {
            levelDefend= newDefendAtack;
        }

        public void SetCatchRate(int newCatchRate)
        {
            catchRate = newCatchRate;
        }

       
        public void SetSpeed(int newSpeed)
        {
            speed = newSpeed;
        }

        //Getter

        public string GetSpecieName()
        {
            return specieName;
        }

        public int GetMaxHp()
        {
            return maxHp;
        }

        public int GetActualHp()
        {
            return actualHp;
        }

        public int GetLevelAttack()
        {
            return levelAttack;
        }

        public int GetLevelDefend()
        {
            return levelDefend;
        }
        
        public int GetId()
        {
            return id;
        }

        public int GetCatchRate()
        {
            return catchRate;
        }

        public int GetSpeed()
        {
            return speed;
        }
    }
}
