﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Diagnostics.Eventing.Reader;

namespace pokemon
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IO functions = new IO();
            Game game = new Game(functions);

            game.Run(); //Llamamos al método que contiene el código del juego
        }
    }
}
