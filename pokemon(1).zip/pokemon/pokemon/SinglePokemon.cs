﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pokemon
{
    internal class SinglePokemon
    {
        Random random = new Random();

        SpeciePokemon specie; //Variable que identifica la especie del individuo.
        string nickname; //Esta variable se asocia con el mote del pokemon 
        string gender; //Esta variable se asocia con el género
        bool catched; //Esta variable se asocia con si ha sido o no capturado el pokémon
        string eo; //Esta variable corresponde al código del entrenador el cual lo capturo.
        DateTime catchDate = new DateTime(); // Esta variable se asocia con la fecha de captura de un pokémon si ha sido capturado
        DateTime catchHour = new DateTime(); //Esta variable se asocia con la hora de captura de un pokémon si ha sido capturado

        public SinglePokemon() { }

        public SinglePokemon(SpeciePokemon specie)
        {
            this.specie = specie;
            this.nickname = specie.GetSpecieName();
            this.gender = SelectGender();
            this.catched = false;   
        }
        //He creado este método para que seleccione de forma aleatoria el género del pokémon.
        public string SelectGender()
        {
            int num = random.Next(1, 3);
            switch (num)
            {
                case 1:
                    return "Macho";
                case 2:
                    return "Hembra";
                default:
                    return "";
            }

        }

        //Setter
        public void SetCatched()
        {
            catched = true;
        }

        public void SetCatchDate(DateTime newDate)
        {
            catchDate = newDate;
        }

        public void SetCatchHour(DateTime newHour)
        {
            catchHour = newHour;
        }

        public void SetNickname(string newNickname)
        {
            nickname = newNickname;
        }

        public void SetEo(Trainer trainer)
        {
            this.eo = trainer.GetId();
        }

        public void SetName(string newSpecieName)
        {
            specie.SetName(newSpecieName);
        }

        public void SetId(int newId)
        {
            specie.SetId(newId);
        }

        public void SetMaxHp(int newMaxHp)
        {
            specie.SetMaxHp(newMaxHp);
        }

        public void SetActualHp(int newActualHp)
        {
            specie.SetActualHp(newActualHp);
        }

        public void SetLevelAttack(int newLevelAttack)
        {
            specie.SetLevelAttack(newLevelAttack);  
        }

        public void SetDefendAtack(int newDefendAtack)
        {
            specie.SetDefendAtack(newDefendAtack);
        }

        public void SetCatchRate(int newCatchRate)
        {
            specie.SetCatchRate(newCatchRate);
        }


        public void SetSpeed(int newSpeed)
        {
            specie.SetSpeed(newSpeed);
        }

        //Getter
        public bool GetCached()
        {
            return catched;
        }

        public DateTime GetCatchDate()
        {
            return catchDate;
        }

        public DateTime GetCatchHour()
        {
            return catchHour;
        }

        public string GetGender()
        {
            return gender;
        }

        public string GetNickname()
        {
            return nickname;
        }

        public string GetSpecieName()
        {
            return specie.GetSpecieName();
        }

        public int GetMaxHp()
        {
            return specie.GetMaxHp();
        }

        public int GetActualHp()
        {
            return specie.GetActualHp();
        }

        public int GetLevelAttack()
        {
            return specie.GetLevelAttack();
        }

        public int GetLevelDefend()
        {
            return specie.GetLevelDefend();
        }

        public int GetId()
        {
            return specie.GetId();
        }

        public int GetCatchRate()
        {
            return specie.GetCatchRate();
        }

        public int GetSpeed()
        {
            return specie.GetSpeed();
        }        

        public string GetEo()
        {
            return eo;
        }

        //Ahora creo los diferentes pokémon con sus correspondientes características, para que a la hora de crear un pokémon solo tienes que decir su especie y así no tener que poner cada vez las estadísticas de nuevo.
        public SinglePokemon Bulbasaur()
        {
            SpeciePokemon specie = new SpeciePokemon("Bulbasaur", 1, 45, 49, 49, 45, 45);          
            SinglePokemon single = new SinglePokemon(specie);
            return single; 
        }

        public SinglePokemon Ivysaur()
        {
            SpeciePokemon specie = new SpeciePokemon("Ivysaur", 2, 60, 62, 63, 60, 45);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Venusaur()
        {
            SpeciePokemon specie = new SpeciePokemon("Venusaur", 3, 80, 82, 83, 80, 45);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Charmander()
        {
            SpeciePokemon specie =  new SpeciePokemon("Charmander", 4, 39, 52, 43, 65, 45);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Charmeleon()
        {

            SpeciePokemon specie = new SpeciePokemon("Charmeleon", 5, 58, 64, 58, 80, 45);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Charizard()
        {
            SpeciePokemon specie = new SpeciePokemon("Charizard", 6, 78, 84, 78, 100, 45);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Squirtle()
        {
            SpeciePokemon specie = new SpeciePokemon("Squirtle", 7, 44, 48, 65, 43, 45);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Wartortle()
        {
            SpeciePokemon specie = new SpeciePokemon("Wartortle ", 8, 59, 63, 80, 58, 45);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Blastoise()
        {
            SpeciePokemon specie = new SpeciePokemon("Blastoise ", 9, 79, 83, 100, 78, 45);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Caterpie()
        {
            SpeciePokemon specie = new SpeciePokemon("Caterpie", 10, 45, 30, 35, 45, 255);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Metapod()
        {
            SpeciePokemon specie = new SpeciePokemon("Metapod", 11, 50, 20, 55, 30, 120);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Butterfree()
        {
            SpeciePokemon specie = new SpeciePokemon("Butterfree", 12, 60, 45, 50, 70, 45);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Weedle()
        {
            SpeciePokemon specie = new SpeciePokemon("Weedle", 13, 40, 35, 30, 50, 255);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Kakuna()
        {
            SpeciePokemon specie = new SpeciePokemon("Kakuna", 14, 45, 25, 50, 35, 120);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Beedrill()
        {
            SpeciePokemon specie = new SpeciePokemon("Beedrill", 15, 65, 90, 40, 75, 45);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Pidgey()
        {
            SpeciePokemon specie = new SpeciePokemon("Pidgey", 16, 40, 45, 40, 56, 255);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Pidgeotto()
        {
            SpeciePokemon specie = new SpeciePokemon("Pidgeotto", 17, 63, 60, 55, 71, 120);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Pidgeot()
        {
            SpeciePokemon specie = new SpeciePokemon("Pidgeot", 18, 83, 80, 75, 101, 45);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Rattata()
        {
            SpeciePokemon specie = new SpeciePokemon("Rattata", 19, 30, 56, 35, 72, 255);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Raticate()
        {
            SpeciePokemon specie = new SpeciePokemon("Raticate", 20, 55, 81, 60, 97, 127);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Spearow()
        {
            SpeciePokemon specie = new SpeciePokemon("Spearow", 21, 40, 60, 30, 70, 255);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Fearow()
        {
            SpeciePokemon specie = new SpeciePokemon("Fearow", 22, 65, 90, 65, 100, 90);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Ekans()
        {
            SpeciePokemon specie = new SpeciePokemon("Ekans", 23, 35, 60, 44, 55, 255);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Arbok()
        {
            SpeciePokemon specie = new SpeciePokemon("Arbok", 24, 60, 95, 69, 80, 90);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }

        public SinglePokemon Pikachu()
        {
            SpeciePokemon specie = new SpeciePokemon("Pikachu", 25, 35, 55, 40, 90, 190);
            SinglePokemon single = new SinglePokemon(specie);
            return single;
        }
    }
}
