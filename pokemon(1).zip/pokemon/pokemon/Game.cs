﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

//Anotación:
//1- Algunos if llevan algo como lista[i] = null esto sirve para que compruebe si esa posición de la lista no esta vacía y así que el programa no de fallo.
namespace pokemon
{
    class Game
    {
        IO functions;
        Random random = new Random();

        public SinglePokemon[] IntroPokemon(SinglePokemon pokemon) //Creamos una lista con los pokémon de la introdución, para elegir uno
        {

            SinglePokemon[] introPokemon = new SinglePokemon[3];
            introPokemon[0] = pokemon.Bulbasaur();
            introPokemon[1] = pokemon.Charmander();
            introPokemon[2] = pokemon.Squirtle();
            return introPokemon;
        }

        public SinglePokemon[] FightPokemon(SinglePokemon pokemon) //Creamos una lista con los posibles rivales en el combate
        {

            SinglePokemon[] fightPokemon = new SinglePokemon[200];
            fightPokemon[0] = pokemon.Bulbasaur();
            fightPokemon[1] = pokemon.Ivysaur();
            fightPokemon[2] = pokemon.Venusaur();
            fightPokemon[3] = pokemon.Charmander();
            fightPokemon[4] = pokemon.Charmeleon();
            fightPokemon[5] = pokemon.Charizard();
            fightPokemon[6] = pokemon.Squirtle();
            fightPokemon[7] = pokemon.Wartortle();
            fightPokemon[8] = pokemon.Blastoise();
            fightPokemon[9] = pokemon.Caterpie();
            fightPokemon[10] = pokemon.Metapod();
            fightPokemon[11] = pokemon.Butterfree();
            fightPokemon[12] = pokemon.Weedle();
            fightPokemon[13] = pokemon.Kakuna();
            fightPokemon[14] = pokemon.Beedrill();
            fightPokemon[15] = pokemon.Pidgey();
            fightPokemon[16] = pokemon.Pidgeotto();
            fightPokemon[17] = pokemon.Pidgeot();
            fightPokemon[18] = pokemon.Rattata();
            fightPokemon[19] = pokemon.Raticate();
            fightPokemon[20] = pokemon.Spearow();
            fightPokemon[21] = pokemon.Fearow();
            fightPokemon[22] = pokemon.Ekans();
            fightPokemon[23] = pokemon.Arbok();
            fightPokemon[24] = pokemon.Pikachu();
            return fightPokemon;
        }
        public Game(IO functions)
        {
            this.functions = functions;
        }

        //Este método incializa el programa de forma normal antes de acceder a lo que es el juego.
        public void NormalIntroduce(SinglePokemon[] _introPokemon, SinglePokemon[] _team, string _name)
        {
            functions.ThreadTextLine("\nProf.Oak: Bienvenido " + _name + " al mundo de los Pokémon, soy el Profesor Oak, y te voy a dirigir en este bonito mundo.");
            functions.ThreadTextLine("\nProf.Oak: En primer lugar te voy a dar a elegir entre tres pokémon y así después empezar tu aventura Pokémon, en la cual podrás combatir con otros pokémon, además de poder descubrir y capturar otros más, bueno te dejo en paz y ¡COMENCEMOS!");
            functions.ThreadTextLine("\nProf.Oak: Tienes estos tres pokémon a elegir uno, así que piénsatelo bien.");
            functions.ShowPokemon(_introPokemon);
            ChooseFirstPokemon(_introPokemon, _team);
            functions.ThreadTextLine("\nProf.Oak: Has elegido a " + _team[0].GetSpecieName());
        }

        //Este método se salta todo el texto de la introducción para pasar a lo que es el juego en sí.
        public void FastIntroduce(SinglePokemon[] _introPokemon, SinglePokemon[] _team)
        {
            firstPokemon(_introPokemon, _team, random.Next(1, 4));
            functions.ShowPokemon(_team);
        }

        //Este método sirve para elegir el pokémon incial
        public void ChooseFirstPokemon(SinglePokemon[] _introPokemon, SinglePokemon[] _team)
        {
            int choose = functions.ReadInt("\nProf.Oak: ¿Qué pokémon de estos tres quieres elegir? (1 o 2 o 3): ");
            firstPokemon(_introPokemon, _team, choose);
        }

        //Este método sirve para introducirlo en el equipo
        public void firstPokemon(SinglePokemon[] _introPokemon, SinglePokemon[] _team, int _option)
        {
            if (_option == 1)
            {
                _team[0] = _introPokemon[0];
            }

            if (_option == 2)
            {
                _team[0] = _introPokemon[1];
            }

            if (_option == 3)
            {
                _team[0] = _introPokemon[2];
            }

            switch (_option)
            {
                case 1:
                    _team[0] = _introPokemon[0];
                    break;
                case 2:
                    _team[0] = _introPokemon[1];
                    break;
                case 3:
                    _team[0] = _introPokemon[2];
                    break;
                default:
                    functions.ThreadTextLine("Por favor eliga 1, 2 o 3.");
                    ChooseFirstPokemon(_introPokemon, _team);
                    break;
            }
        }

        //Esta función imprime el menú principal.
        public void Menu()
        {
            functions.Space();
            functions.ThreadTextLine("Menu: ");
            functions.ThreadTextLine("\t1. Ver tu perfil");
            functions.ThreadTextLine("\t2. Ver mis pokémon");
            functions.ThreadTextLine("\t3. Combatir");
            functions.ThreadTextLine("\t4. Centro Pokémon");
            functions.ThreadTextLine("\t5. Salir del juego");
        }

        public void Run() //Esta es la función de la que parte el juego.
        {
            //Pedimos los datos del jugador
            string name = functions.ReadString("¿Cómo te llamas?: ");
            string gender = functions.ReadString("\n¿Género(Chico, chica, chique)?: ");
            functions.ThreadTextLine("\nConsidere los siguientes continentes: ");
            ShowContinent();
            int numContinent;
            do
            {
                numContinent = functions.ReadInt("\nSeleciona el número del continente en el que resides: ");
                if (numContinent < 1 || numContinent > 5)
                {
                    functions.ThreadTextLine("Por favor escriba una opción valida");
                }
            } while (numContinent < 1 || numContinent > 5);
            string continent = SelectContinent(numContinent);
            functions.LineSeparator();
            //Lista de pokémon
            Trainer trainer = new Trainer(name, gender, continent, DateTime.Now);
            SinglePokemon pokemon = new SinglePokemon();
            SinglePokemon[] introPokemon = IntroPokemon(pokemon);
            SinglePokemon[] team = trainer.Team();
            SinglePokemon[][] cases = trainer.Cases();

            for (int i = 0; i < team.Length; i += 1)
            {
                team[i] = IntroPokemon(pokemon)[random.Next(0, IntroPokemon(pokemon).Length)];
            }

            for (int i = 0; i < 10; i += 1)
            {
                for (int j = 0; j < 10; j += 1)
                {
                    cases[i][j] = FightPokemon(pokemon)[random.Next(0, IntroPokemon(pokemon).Length)]; 
                }
            }

            int mode;
            do
            {
                mode = functions.ReadInt("\nQue opción quieres la rápida(1) o la lenta(2): ");

                switch (mode) //Esto sirve para como comenzar el juego.
                {
                    case 1:
                        functions.LineSeparator();
                        FastIntroduce(introPokemon, team);
                        functions.LineSeparator();
                        ChooseOptionMenu(trainer, pokemon, team, cases);
                        Environment.Exit(0);
                        break;
                    case 2:
                        functions.LineSeparator();
                        NormalIntroduce(introPokemon, team, name);
                        ChooseOptionMenu(trainer, pokemon, team, cases);
                        functions.LineSeparator();
                        break;
                    default:
                        functions.ThreadTextLine("Por favor eliga normal o rápida.");
                        break;

                }
            } while (mode != 1 || mode != 2);
        }
        public void ShowContinent()
        {
            functions.ThreadTextLine("\t 1 - Europa");
            functions.ThreadTextLine("\t 2 - Norte América");
            functions.ThreadTextLine("\t 3 - Asia-Australia");
            functions.ThreadTextLine("\t 4 - África");
            functions.ThreadTextLine("\t 5 - Sur América");
        }
        public string SelectContinent(int _numContinent)
        {
            switch (_numContinent)
            {
                case 1:
                    return "Europa";
                case 2:
                    return "Norte América";
                case 3:
                    return "Asia - Australia";
                case 4:
                    return "África";
                case 5:
                    return "Sur América";
                default:
                    return "Europa";
            }
        }
        public void ChooseOptionMenu(Trainer _trainer, SinglePokemon _pokemon, SinglePokemon[] _team, SinglePokemon[][] _cases)
        {
            bool exit = false;
            do
            {
                Menu();
                functions.Space();
                int option = functions.ReadInt("Prof.Oak: Que opción quieres elegir del menu: ");
                switch (option)
                {
                    case 1:
                        functions.ThreadTextLine("\n Prof.Oak: Este es tu perfil: ");
                        functions.ProfileToString(_trainer);
                        break;
                    case 2: //Opción de ver los pokémon del equipo principal
                        ShowTeamCases(_team, _cases);
                        break;
                    case 3: //Opción de combatir
                        Combat(_trainer, _pokemon, _team, _cases);
                        break;
                    case 4: //Opción para curar los pokémon
                        functions.ThreadTextLine("\n Bienvenido al centro pokémon, aquí se curarán todos tus pokémon del equipo al máximo de vida");
                        TreatPokemon(_team);
                        break;
                    case 5: //Opción de salir del juego.
                        //Esto asegura que el usuario quiere salir perdiendo los datos.
                        int num = 0;
                        do
                        {
                            num = functions.ReadInt("\n Si cierra el programa se borrarán todos los datos, ¿Está seguro de querer cerrar?(1-Si, 2-No): ");
                            switch (num)
                            {
                                case 1:
                                    exit = true;
                                    break;
                                case 2:
                                    exit = false;
                                    functions.Space();
                                    break;
                                default:
                                    functions.ThreadTextLine("\n Por favor eliga Si(1) o No(2)");
                                    break;
                            }
                        } while (num != 1 && num != 2);
                        break;
                    default:
                        functions.ThreadTextLine("\n Por favor eliga una opción del menú.");
                        break;
                }
            } while (exit == false);
        }

        public void ShowTeamCases(SinglePokemon[] _team, SinglePokemon[][] _cases)
        {
            functions.ThreadTextLine("\n Tres opciones: ");
            functions.ThreadTextLine("\n\t1- Ver tu equipo.");
            functions.ThreadTextLine("\n\t2- Ver las cajas.");
            functions.ThreadTextLine("\n\t3- Salir");
            int option;
            do
            {
                option = functions.ReadInt("\n ¿Qué opción eliges?: ");
                if (!((option == 1) || (option == 2) || (option == 3))) {
                    functions.ThreadTextLine("\n Por favor escoga 1 o 2 o 3.");
                }
            } while (!((option == 1) || (option == 2) || (option == 3)));

            if (option == 1)
            {
                functions.ShowPokemon(_team);

                int wantToChange;
                do
                {
                    wantToChange = functions.ReadInt("\n ¿Quiéres cambiar de posición algún pokémon dentro del equipo?(1-Si, 2-No): ");
                    if (wantToChange != 1 && wantToChange != 2)
                    {
                        functions.ThreadTextLine("\n Por favor elige 1 o 2.");
                    }
                } while (wantToChange != 1 && wantToChange != 2);

                if (wantToChange == 1)
                {
                    ChangeTeamPosition(_team);
                }

                ShowTeamCases(_team, _cases);
                functions.Space();
            }

            if (option == 2)
            {
                int caseSelected = functions.ShowCases(_cases);
                int wantToChange2;
                do
                {
                    wantToChange2 = functions.ReadInt("\n ¿Quiéres cambiar de posición algún pokémon dentro del equipo?(1-Si, 2-No): ");
                    if (wantToChange2 != 1 && wantToChange2 != 2)
                    {
                        functions.ThreadTextLine("\n Por favor elige 1 o 2.");
                    }
                } while (wantToChange2 != 1 && wantToChange2 != 2);

                if (wantToChange2 == 1)
                {
                    ChangeCasesPosition(_cases, caseSelected);
                }

                ShowTeamCases(_team, _cases);
                functions.Space();
            }

            if (option == 3)
            {
                return;
            }
        }

        public void ChangeTeamPosition(SinglePokemon[] _team)
        {
            int positionToChange;
            do
            {
                do
                {
                    positionToChange = functions.ReadInt("\n ¿En qué posición esta tu pokemón?: ");
                    if (positionToChange < 1 || positionToChange > _team.Length)
                    {
                        functions.ThreadTextLine("\n Por favor eliga un pokémon de la lista.\n");
                    }
                } while (positionToChange < 1 || positionToChange > _team.Length);

                if(_team[positionToChange - 1] == null)
                {
                    functions.ThreadTextLine("\n Por favor eliga un pokémon de la lista.\n");
                }
            } while (_team[positionToChange - 1] == null);

            int positionDestiny;
            do
            {
                positionDestiny = functions.ReadInt("\n ¿A qué posición quieres cambiarlo?: ");
                if (positionDestiny < 1 || positionDestiny > _team.Length)
                {
                    functions.ThreadTextLine("\n Por favor eliga una posición entre 1 y " + _team.Length + " incluidos.\n");
                }
            } while (positionDestiny < 1 || positionDestiny > _team.Length);

            if (_team[positionDestiny - 1] != null)
            {
                Console.WriteLine("Hola");
                SinglePokemon pokemonSaved = _team[positionDestiny - 1];
                functions.ChangePokemon(_team[positionToChange - 1], _team, positionDestiny - 1);
                _team[positionToChange - 1] = pokemonSaved;
            }
            else
            {
                Console.WriteLine("Hola x2");
                functions.ChangePokemon(_team[positionToChange - 1], _team, positionDestiny - 1);
            }
        }

        public void ChangeCasesPosition(SinglePokemon[][] _cases, int caseSelected)
        {
            int positionToChange;
            do
            {
                do
                {
                    positionToChange = functions.ReadInt("\n ¿En qué posición esta tu pokemón?: ");
                    if (positionToChange < 1 || positionToChange > _cases[caseSelected].Length)
                    {
                        functions.ThreadTextLine("\n Por favor eliga un pokémon de la lista.\n");
                    }
                } while (positionToChange < 1 || positionToChange > _cases[caseSelected].Length);

                if(_cases[caseSelected - 1][positionToChange - 1] == null)
                {
                    functions.ThreadTextLine("\n Por favor eliga un pokémon de la lista.\n");
                }
            } while (_cases[caseSelected - 1][positionToChange - 1] == null);

            

            int caseDestiny;
            do
            {
                functions.ThreadTextLine("\n Existe un total de " + _cases.Length + " y tu estas en la caja " + caseSelected);
                Console.WriteLine("\n Has elgido a " + _cases[caseSelected - 1][positionToChange - 1].GetNickname());
                caseDestiny = functions.ReadInt("\n ¿A qué caja quieres cambiarlo?: ");
                if (caseDestiny < 1 || caseDestiny > _cases.Length)
                {
                    functions.ThreadTextLine("\n Por favor eliga una caja entre 1 y " + _cases.Length + " incluidos.\n");
                }
            } while (caseDestiny < 1 || caseDestiny > _cases.Length);

            int positionDestiny;
            do
            {
                positionDestiny = functions.ReadInt("\n ¿A qué posición quieres cambiarlo?: ");
                if (positionDestiny < 1 || positionDestiny > _cases[caseDestiny].Length)
                {
                    functions.ThreadTextLine("\n Por favor eliga una posición entre 1 y " + _cases[caseDestiny].Length + " incluidos.\n");
                }
            } while (positionDestiny < 1 || positionDestiny > _cases[caseDestiny].Length);

            if (_cases[caseDestiny - 1][positionDestiny - 1] != null)
            {
                SinglePokemon pokemonSaved = _cases[caseDestiny - 1][positionDestiny - 1];
                functions.ChangePokemonDoubleArray(_cases[caseSelected - 1][positionToChange - 1], _cases, caseDestiny - 1, positionDestiny - 1);
                _cases[caseSelected - 1][positionToChange - 1] = pokemonSaved;
            }
            else
            {
                functions.ChangePokemonDoubleArray(_cases[caseSelected - 1][positionToChange - 1], _cases, caseDestiny - 1, positionDestiny - 1);
                _cases[caseSelected - 1][positionToChange - 1] = null;
            }
        }
        public void ChangeNickPokemon(SinglePokemon[] _team)
        {
            int option = 0;
            do
            {
                option = functions.ReadInt("\n Quieres cambiar el nombre de algun pokémon(1-Sí, 2-No): ");
                if (!(option == 1 || option == 2))
                {
                    functions.ThreadTextLine("\n Por favor decida si Sí(1) o No(2)");
                }
            } while (!(option == 1 || option == 2));

            if (option == 1)
            {
                int option2 = 0;
                do
                {
                    option2 = functions.ReadInt("\n Que pokémon quieres elegir:  ");
                    if (!(option2 > 0 && option2 < 7) || _team[option2 - 1] == null)
                    {
                        functions.ThreadTextLine("\n Por favor eliga un pokémon de la lista");
                    }
                } while (!(option2 > 0 && option2 < 7) || _team[option2 - 1] == null);

                string newNick = "";
                do
                {
                    newNick = functions.ReadString("\n Elige un mote para tu " + _team[option2 - 1].GetNickname() + ": ");
                    if (newNick == string.Empty)
                    {
                        functions.ThreadTextLine("\n Por favor eliga un nombre correcto.");
                    }
                } while (newNick == string.Empty);
                _team[option2 - 1].SetNickname(newNick);
            }
        }

        public void TreatPokemon(SinglePokemon[] _team) //Método que cura a los pokemon con vida menos que su tope, para curarla así a su máximo.
        {
            int treatCounter = 0;
            for (int i = 0; i < _team.Length; i += 1)
            {
                if (_team[i] != null && _team[i].GetActualHp() != _team[i].GetMaxHp())
                {
                    functions.ThreadText("\n ");
                    for (int j = 0; j < 5; j += 1)
                    {
                        functions.ThreadText("Curando...");
                        Thread.Sleep(200);
                    }
                    functions.ThreadTextLine(_team[i].GetNickname() + " ha sido curado.");
                    _team[i].SetActualHp(_team[i].GetMaxHp());
                    treatCounter += 1;
                }
            }
            functions.ThreadTextLine("\n Se ha curado un total de " + Convert.ToString(treatCounter) + " pokémon");
        }

        public void CombatMenu()
        {
            functions.ThreadTextLine("\n Opciones de combate: ");
            functions.ThreadTextLine("\t1. Atacar");
            functions.ThreadTextLine("\t2. Cambiar de pokémon");
            functions.ThreadTextLine("\t3. Capturar");
            functions.ThreadTextLine("\t4. Escapar");
        }

        //Método de combate.
        public void Combat(Trainer _trainer, SinglePokemon _pokemon, SinglePokemon[] _team, SinglePokemon[][] _cases)
        {
            functions.ThreadTextLine("\n Combate en desarrollo\n");
            SinglePokemon[] fightPokemon = FightPokemon(_pokemon);
            SinglePokemon npcFighter = null;
            do
            {
                npcFighter = fightPokemon[random.Next(0, fightPokemon.Length)];
            } while (npcFighter == null);
            SinglePokemon userFighter = ChooseFighter(_team);

            if (userFighter == null) //Este if comprueba si el usuario tiene pokémon como para poder combatir.
            {
                functions.ThreadTextLine("\n Si tiene algun pokémon llevalo al Centro pokémon y vuelve a combatir.\n");
            }
            else
            {
                functions.ThreadTextLine("\n Entras a luchar con " + userFighter.GetNickname() + " para combatir. Te enfrentas a un " + npcFighter.GetSpecieName() + " salvaje.");
                int option = 0;
                int exit = 0;
                bool escape = false;
                int attemps = 0;
                SinglePokemon actualPokemon;
                do
                {
                    //Muestra el menú de combate y la vida de los dos pokémon.
                    functions.ThreadTextLine("\n Vida actual de tu pokémon: " + userFighter.GetActualHp());
                    functions.ThreadTextLine("\n Vida actual del pokémon rival: " + npcFighter.GetActualHp());
                    CombatMenu();

                    option = functions.ReadInt("\n Que opción quieres elegir: ");
                    switch (option)
                    {
                        case 1: //Opción de atacar
                            functions.ThreadTextLine("\n Has elegido la opción de atacar");
                            int weakness = 0;
                            int AnotherAttack = 0;
                            do
                            {
                                weakness = Attack(userFighter, npcFighter);
                                if (weakness != 1)
                                { 
                                    AnotherAttack = functions.ReadInt("\n ¿Quieres atacar otra vez?(1-Si,2-No): ");
                                }

                                if (weakness == 1)
                                {
                                    if (userFighter.GetActualHp() == 0)
                                    {
                                        int exitOrChange = functions.ReadInt("\n ¿Quieres cambiar de pokémon o salir del programa?(1-Si,2-No): ");
                                        if (exitOrChange == 1)
                                        {
                                            actualPokemon = userFighter;
                                            userFighter = ChangeFighterIfWeakened(_team, userFighter);
                                            if(userFighter == null)
                                            {
                                                exit = 2;
                                            }
                                            else
                                            {
                                                if (actualPokemon == userFighter)
                                                {
                                                    functions.ThreadTextLine("\n Saliendo del combate");
                                                    exit = 2;
                                                }
                                            }
                                            
                                        }
                                        else
                                        {
                                            exit = 2;
                                        }
                                    }
                                    else
                                    {
                                        exit = 2;
                                    }
                                }

                            } while (weakness != 1 && AnotherAttack == 1); //Esto significa que alguno de los dos pokémon no ha sido debilitado o sí el usuario quiere no volver a atacar, si es así con una de las ocpciones se sale de atacar.
                            break;
                        case 2: //Opción para cambiar de pokémon
                            functions.ThreadTextLine("\n Has elegido la opción de cambiar de pokémon");
                            actualPokemon = userFighter;
                            userFighter = ChangeFighter(_team, userFighter);
                            if (actualPokemon != userFighter)
                            {
                                functions.ThreadTextLine("\n Al cambiar pierdes un turno y " + npcFighter.GetNickname() + " ataca a " + userFighter.GetNickname());
                                userFighter.SetActualHp(userFighter.GetActualHp() - CalculateDamage(npcFighter, userFighter));
                            }
                            functions.ThreadTextLine("\n Tu pokémon de lucha ahora es " + userFighter.GetNickname());
                            break;
                        case 3: //Opción para intentar capturar el pokémon rival.
                            functions.ThreadTextLine("\n Has elegido intentar capturar");
                            int checkCatch = Catch(npcFighter);
                            if (checkCatch == 0)
                            {
                                functions.ThreadTextLine("\n Que pena no has capturado el pokémon.");
                                exit = functions.ReadInt("\n ¿Quieres seguir el combate?(1-Si, 2-No): ");
                                if (exit != 1 && exit != 2)
                                {
                                    functions.ThreadTextLine("ERROR, volviendo al menu del juego por seguridad.");
                                }
                            }
                            else
                            {
                                //Como se captura el pokémon este fragmento de código dentro del else sirve para guardar el pokémon capturado en la bolsa o cambiarlo por otro.
                                Catched(_trainer, _team, _cases,  npcFighter);
                                exit = 2;
                            }
                            break;
                        case 4://Opción para intentar escapar.
                            functions.ThreadTextLine("\n Has decidido escapar");
                            attemps += 1;
                            escape = Escape(userFighter, npcFighter, attemps);
                            if (escape == true)
                            {
                                functions.ThreadTextLine("\n Enhorabuena has conseguido escapar al intento " + attemps);
                            }
                            else
                            {
                                functions.ThreadTextLine("\n No has conseguido escapar ahora sufres el ataque del " + npcFighter.GetNickname() + " salvaje.");
                                functions.ThreadTextLine("\n " + npcFighter.GetNickname() + " ataca a " + userFighter.GetNickname());
                                userFighter.SetActualHp(userFighter.GetActualHp() - CalculateDamage(npcFighter, userFighter));

                            }
                            break;
                        default:
                            functions.ThreadTextLine("\n Por favor eliga una opción correcta.");
                            break;
                    }
                } while (!(escape == true || exit == 2));
            }

        }

        //Método para elegir el pokémon de tu bolsa que se quiere para combatir con el rival del combate.
        public SinglePokemon ChooseFighter(SinglePokemon[] _team)
        {
            int counter = 0; //Esto cuenta los posibles pokémon para luchar
            for (int i = 0; i<_team.Length; i+=1)
            {
                if (_team[i] != null && _team[i].GetActualHp() > 0)
                {
                    counter += 1;
                }
            }

            switch (counter)
            {
                case 0:
                    functions.ThreadText("\n Ninguno de tus pokémon puede combatir. ");
                    return null;
                default:
                    int position = 0;
                    for (int i = 0; i < _team.Length; i += 1)
                    {
                        if (_team[i].GetActualHp() != 0)
                        {
                            position = i;
                            break;
                        }
                    }
                    return _team[position];
            }
        }

        //Método para cambiar de pokémon si tu pokémon ha quedado debilitado en combate
        public SinglePokemon ChangeFighterIfWeakened(SinglePokemon[] _team, SinglePokemon _userFigther)
        {
            int counter = 0; //Esto cuenta los posibles pokémon para luchar
            for (int i = 0; i < _team.Length; i += 1)
            {
                if (_team[i] != null && _team[i].GetActualHp() > 0)
                {
                    counter += 1;
                }
            }

            switch (counter)
            {
                case 0:
                    functions.ThreadText("\n No tienes pokémon para luchar\n");
                    return null;
                default:
                    functions.ThreadTextLine("\n Estos son tus posibles pokémon para cambiar: ");
                    for (int i = 0; i < _team.Length; i += 1)
                    {
                        if (_team[i] != null && _team[i].GetActualHp() != 0 && _team[i] != _userFigther)
                        {
                            functions.ThreadTextLine(functions.PokemonToString(_team[i], i));
                        }
                    }
                    int option = 0;
                    do
                    {
                        do
                        {
                            option = functions.ReadInt("\n ¿Qué pokémon quieres elegir para cambiar por " + _userFigther.GetNickname() + "?: ");
                            if (option < 1 || option > 6)
                            {
                                functions.ThreadTextLine("\n Por favor eliga un pokémon de la lista.\n");
                            }
                        } while (option < 1 || option > 6);

                        if (_team[option - 1] == null || _team[option - 1].GetActualHp() == 0 || _team[option - 1] == _userFigther)
                        {
                            functions.ThreadTextLine("\n Por favor eliga un pokémon de la lista.\n");
                        }
                    } while (_team[option - 1] == null || _team[option - 1].GetActualHp() == 0 || _team[option - 1] == _userFigther);
                    return _team[option - 1];
            }
        }
        //Método para cambiar de pokémon
        public SinglePokemon ChangeFighter(SinglePokemon[] _team, SinglePokemon _userFigther)
        {
            int counter = 0; //Esto cuenta los posibles pokémon para luchar
            for (int i = 0; i < _team.Length; i += 1)
            {
                if (_team[i] != null && _team[i].GetActualHp() > 0)
                {
                    counter += 1;
                }
            }

            switch (counter)
            {
                case 0:
                    functions.ThreadText("\n No tienes pokémon para luchar\n");
                    return null;
                case 1:
                    functions.ThreadText("\n Solo tienes un pokémon posible para luchar, captura otros pokémon para luchar o cura a los pokemon debilitados.\n");
                    return _userFigther;
                default:
                    functions.ThreadTextLine("\n Estos son tus posibles pokémon para cambiar: ");
                    for (int i = 0; i < _team.Length; i += 1)
                    {
                        if (_team[i] != null && _team[i].GetActualHp() != 0 && _team[i] != _userFigther)
                        {
                            functions.ThreadTextLine(functions.PokemonToString(_team[i], i));
                        }
                    }
                    int option = 0;
                    do
                    {
                        do
                        {
                            option = functions.ReadInt("\n ¿Qué pokémon quieres elegir para cambiar por " + _userFigther.GetNickname() + "? o ¿Quieres cancelar - 0?: ");
                            if (option < 0 || option > 6)
                            {
                                functions.ThreadTextLine("\n Por favor eliga un pokémon de la lista.\n");
                            }
                        } while (option < 0 || option > 6);

                        if (option == 0)
                        {
                            functions.ThreadTextLine("\n Cambio cancelado");
                            break;
                        }
                        else
                        {
                            if (_team[option - 1] == null || _team[option - 1].GetActualHp() == 0 || _team[option - 1] == _userFigther)
                            {
                                functions.ThreadTextLine("\n Por favor eliga un pokémon de la lista.\n");
                            }
                        }
                    } while (_team[option - 1] == null || _team[option - 1].GetActualHp() == 0 || _team[option - 1] == _userFigther);
                    if (option == 0)
                    {
                        return _userFigther;
                    }
                    else
                    {
                        return _team[option - 1];
                    }
            }
        }

        //Método para intentar capturar el pokémon
        public int Catch(SinglePokemon _npcFighter)
        {
            double RCm = (((3 * _npcFighter.GetMaxHp()) - (2 * _npcFighter.GetActualHp())) * 4096 * _npcFighter.GetCatchRate()) / (3 * _npcFighter.GetMaxHp());
            double Ag = 65536 / Math.Pow(255 / RCm, 0.1875);
            int counter = 0;
            for (int i = 0; i < 4; i += 1)
            {
                double numRan = random.Next(0, 65536);
                if (numRan < Ag)
                {
                    counter += 1;
                    break;
                }
                else
                {
                    functions.ThreadTextLine("\n Intento " + i + ": Se escapo");
                }
            }
            if (counter == 0)
            {
                return 0;
            }
            else
            {
                functions.ThreadTextLine("\n Conseguido en el intento " + counter);
                return 1;
            }
        }

        public void Catched(Trainer _trainer, SinglePokemon[] _team, SinglePokemon[][] _cases, SinglePokemon npcFighter)
        {
            functions.ThreadTextLine("\n Felicidades has capturado al pokémon");        
            int counter = 0;
            for (int i = 0; i <_team.Length; i+=1)
            {
                if (_team[i] == null)
                {
                    counter += 1;
                }
            }

            switch (counter)
            {
                case 0:
                    bool checkSaved = false;
                    functions.ThreadTextLine("\n Como no tienes más espacio en el equipo se te añade a los espacios vacíos de las cajas");
                    for (int i = 0; i < _cases.Length; i += 1)
                    {
                        for (int j = 0; j < _cases[i].Length; j += 1)
                        {
                            if (_cases[i][j] == null)
                            {
                                functions.ChangePokemonDoubleArray(npcFighter, _cases, i, j);
                                DateTime _date = DateTime.Now;
                                _cases[i][j] = npcFighter;
                                _cases[i][j].SetCatched();
                                _cases[i][j].SetCatchDate(_date);
                                _cases[i][j].SetCatchHour(_date);
                                _cases[i][j].SetEo(_trainer);
                                functions.ThreadTextLine("\n Pokemon guardado en la caja " + (i + 1) + " en la posición " + (j + 1) + ", saliendo del combate y volviendo al menu.\n");
                                checkSaved = true;
                                break;
                            }
                        }
                        if (checkSaved == true)
                        {
                            break;
                        }
                    }

                    if(checkSaved == false)
                    {
                        functions.ThreadTextLine("\n Se te han acabado todos los espacios del equipo y de las cajas.");
                        functions.ThreadTextLine("\n Tienes que intercambiarlo con algún pokémon de todos los que tienes");
                        int showPokemon;
                        do
                        {
                            showPokemon = functions.ReadInt("\n ¿Quiéres ver todos tus pokémon?(1-Si, 2-No): ");
                            if (showPokemon != 1 && showPokemon != 2)
                            {
                                functions.ThreadTextLine("\n Por favor elige 1 o 2.");
                            }
                        } while (showPokemon != 1 && showPokemon != 2);

                        if (showPokemon == 1)
                        {
                            ShowTeamCases(_team, _cases);
                        }

                        int teamOrCases;
                        do
                        {
                            teamOrCases = functions.ReadInt("\n ¿Quiéres cambiarlo con los pokémon del equipo o de las cajas?(1- Equipo, 2- Cajas): ");
                            if (teamOrCases != 1 && teamOrCases != 2)
                            {
                                functions.ThreadTextLine("\n Por favor elige 1 o 2.");
                            }
                        } while (teamOrCases != 1 && teamOrCases != 2);

                        int positionToChange;
                        DateTime date = DateTime.Now;
                        switch (teamOrCases)
                        {
                            case 1:                                
                                
                                do
                                {
                                    positionToChange = functions.ReadInt("\n Eliga la posición donde almacenar tu pokémon: ");
                                    if (positionToChange < 1 || positionToChange > _team.Length)
                                    {
                                        functions.ThreadTextLine("\n Por favor eliga una posición del 1 al 6.");
                                    }
                                } while (positionToChange < 1 || positionToChange > _team.Length);
                                functions.ChangePokemon(npcFighter, _team, positionToChange - 1);
                                _team[positionToChange - 1].SetCatched();
                                _team[positionToChange - 1].SetCatchDate(date);
                                _team[positionToChange - 1].SetCatchHour(date);
                                _team[positionToChange - 1].SetEo(_trainer);
                                functions.ThreadTextLine("\n Todo correcto, saliendo del combate y volviendo al menu.\n");
                                break;
                            case 2:
                                int numCaseToChange;

                                do
                                {
                                    numCaseToChange = functions.ReadInt("\n Eliga la caja donde almacenar tu pokémon: ");
                                    if (numCaseToChange < 1 || numCaseToChange > _cases.Length)
                                    {
                                        functions.ThreadTextLine("\n Por favor eliga una caja de la 1 a la " + _cases.Length + ".");
                                    }
                                } while (numCaseToChange < 1 || numCaseToChange > _cases.Length);

                                do
                                {
                                    positionToChange = functions.ReadInt("\n Eliga la posición donde almacenar tu pokémon: ");
                                    if (positionToChange < 1 || positionToChange > _cases[numCaseToChange - 1].Length)
                                    {
                                        functions.ThreadTextLine("\n Por favor eliga una posición del 1 al 6.");
                                    }
                                } while (positionToChange < 1 || positionToChange > _cases[numCaseToChange - 1].Length);
                                functions.ChangePokemonDoubleArray(npcFighter, _cases, numCaseToChange - 1, positionToChange - 1);

                                _cases[numCaseToChange - 1][positionToChange - 1].SetCatched();
                                _cases[numCaseToChange - 1][positionToChange - 1].SetCatchDate(date);
                                _cases[numCaseToChange - 1][positionToChange - 1].SetCatchHour(date);
                                _cases[numCaseToChange - 1][positionToChange - 1].SetEo(_trainer);
                                functions.ThreadTextLine("\n Todo correcto, saliendo del combate y volviendo al menu.\n");
                                break;

                        }
                    }
                    break;
                default:
                    for (int i = 0; i < _team.Length; i += 1)
                    {
                        if (_team[i] == null)
                        {
                            functions.ChangePokemon(npcFighter, _team, i);
                            DateTime _date = DateTime.Now;
                            _team[i].SetCatched();
                            _team[i].SetCatchDate(_date);
                            _team[i].SetCatchHour(_date);
                            _team[i].SetEo(_trainer);
                            functions.ThreadTextLine("\n Pokemon guardado en la posición " + (i + 1) + ", saliendo del combate y volviendo al menu.\n");
                            break;
                        }
                    }
                    break;

            }
        }

        //Método para realizar el ataque.
        public int Attack(SinglePokemon _userFighter, SinglePokemon _npcFighter)
        {
            bool weakened = false;
            if (_userFighter.GetSpeed() >= _npcFighter.GetSpeed())
            {
                //Ataca el pokémon del jugador
                functions.ThreadTextLine("\n " + _userFighter.GetNickname() + " ataca a " + _npcFighter.GetNickname());
                _npcFighter.SetActualHp(_npcFighter.GetActualHp() - CalculateDamage(_userFighter, _npcFighter));
                if (CheckWeakened(_npcFighter) == true)
                {
                    functions.ThreadTextLine("\n " + _npcFighter.GetNickname() + " ha sido debilitado, has ganado el combate.");
                    functions.ThreadTextLine("\n Saliendo del combate");
                    weakened = true;
                }
                else
                {
                    functions.ThreadTextLine("\n " + _npcFighter.GetNickname() + " ha quedado a " + _npcFighter.GetActualHp() + " de vida.");
                    functions.ThreadTextLine("\n Ahora " + _npcFighter.GetNickname() + " ataca a " + _userFighter.GetNickname());
                    _userFighter.SetActualHp(_userFighter.GetActualHp() - CalculateDamage(_npcFighter, _userFighter));
                    if (CheckWeakened(_userFighter) == true)
                    {
                        functions.ThreadTextLine("\n " + _userFighter.GetNickname() + " ha sido debilitado, has perdido el combate.");
                        weakened = true;
                    }
                    else
                    {
                        functions.ThreadTextLine("\n " + _userFighter.GetNickname() + " ha quedado a " + _userFighter.GetActualHp() + " de vida.");
                    }
                }
            }
            else
            {
                //Ataca la maquina
                functions.ThreadTextLine("\n " + _npcFighter.GetNickname() + " ataca a " + _userFighter.GetNickname());
                _userFighter.SetActualHp(_userFighter.GetActualHp() - CalculateDamage(_npcFighter, _userFighter));
                if (CheckWeakened(_userFighter) == true)
                {
                    functions.ThreadTextLine("\n " + _userFighter.GetNickname() + " ha sido debilitado");
                    functions.ThreadTextLine("\n Saliendo del combate");
                    weakened = true;
                }
                else
                {
                    functions.ThreadTextLine("\n " + _userFighter.GetNickname() + " ha quedado a " + _userFighter.GetActualHp() + " de vida.");
                    functions.ThreadTextLine("\n Ahora " + _userFighter.GetNickname() + " ataca a " + _npcFighter.GetNickname());
                    _npcFighter.SetActualHp(_npcFighter.GetActualHp() - CalculateDamage(_userFighter, _npcFighter));
                    if (CheckWeakened(_npcFighter) == true)
                    {
                        functions.ThreadTextLine("\n " + _npcFighter.GetNickname() + " ha sido debilitado");
                        functions.ThreadTextLine("\n Saliendo del combate");
                        weakened = true;
                    }
                    else
                    {
                        functions.ThreadTextLine("\n " + _npcFighter.GetNickname() + " ha quedado a " + _npcFighter.GetActualHp() + " de vida.");
                    }
                }
            }

            if (weakened == true)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        //la variable attacker pertenece al pokémon que ataca primero segun la velocidad, y la otra al segundo que ataca.
        //Método que calcula el daño relaizado del atacante al defensor.
        public int CalculateDamage(SinglePokemon attacker, SinglePokemon defender)
        {
            double damage = 0;
            double randDouble = 0;
            do
            {
                randDouble = random.NextDouble();
            } while (randDouble > 1 || randDouble < 0.85);
            damage = (((2 * 50 * (attacker.GetLevelAttack() / defender.GetLevelDefend())) / (50)) + 2) * randDouble * IsCrit();
            return (int)damage;
        }

        public double IsCrit()
        {
            int crit = random.Next(1, 25);
            if (crit == 1)
            {
                return 1.5;
            }
            else
            {
                return 1;
            }
        }

        //Este método verifica si el pokémon ha quedado debilitado.
        public bool CheckWeakened(SinglePokemon fighter)
        {
            if (fighter.GetActualHp() <= 0)
            {
                fighter.SetActualHp(0);
                return true;
            }
            else
            {
                return false;
            }
        }

        //Método para intentar huir.
        public bool Escape(SinglePokemon _userFighter, SinglePokemon _npcFighter, int _attemps)
        {
            int rand = random.Next(1, 255);
            double escape = ((_userFighter.GetSpeed() * 128) / (_npcFighter.GetSpeed()) + (30 * _attemps)) % 256;
            if (rand < escape || _userFighter.GetSpeed() > _npcFighter.GetSpeed())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
