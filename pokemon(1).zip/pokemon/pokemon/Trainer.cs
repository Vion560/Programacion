﻿using pokemon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace pokemon
{
    internal class Trainer
    {
        SinglePokemon pokemon = new SinglePokemon();
        string name;
        string gender;
        string continent;
        string idNum;        
        string secretNum;
        int pokedollars;
        int battlePoint;
        int pokeSeed;
        DateTime dateStart;
        DateTime dateEnd;
        Random rnd = new Random();  

        public Trainer(string name, string gender, string continent, DateTime dateStart)
        {
            this.name = name;
            this.gender = gender;
            this.continent = continent;
            this.idNum = GenerateId(continent);
            this.secretNum = GenerateCodeNum();
            pokedollars = 100;
            battlePoint= 0;
            pokeSeed= 0;
            this.dateStart = dateStart;    
        }

        //Setter
        public void SetName(string name)
        {
            this.name= name;
        }

        public void SetGender(string gender) 
        {
            this.gender= gender;    
        }

        public void SetContinent(string continent)
        {
            this.continent= continent;
        }

        public void SetPokeDollars(int pokeDollars)
        {
            this.pokedollars = pokeDollars;
        }

        public void SetBattlePoints(int battlePoints)
        {
            this.battlePoint = battlePoints;
        }

        public void SetPokeSeeds(int pokeSeeds)
        {
            this.pokeSeed = pokeSeeds;
        }

        //Getter
        public string GetName()
        {
            return name;
        }
        
        public string GetGender()
        {
            return gender;
        }
        
        public string GetContinent() 
        {
            return continent;
        }

        public int GetPokeDollars()
        {
            return pokedollars;
        }

        public int GetBattlePoints()
        {
            return battlePoint;
        }

        public int GetPokeSeeds()
        {
            return pokeSeed;
        }

        public string GetId()
        {
            return idNum;
        }
        public DateTime GetDateStart()
        {
            return dateStart;
        }
        public DateTime GetDateEnd()
        {
            dateEnd = DateTime.Now;
            return dateEnd;
        }

        //Generate

        public string GenerateId(string continent)
        {
            int ContinentDigit = 0;
            switch (continent)
            {
                case "Europa":
                    ContinentDigit= 0;
                    break;
                case "Norte América":
                    ContinentDigit = 1;
                    break;
                case "Asia - Australia":
                    ContinentDigit = 2;
                    break;
                case "África":
                    ContinentDigit = 3;
                    break;
                case "Sur América":
                    ContinentDigit = 4;
                    break;
            }

            string randomNumToId = "";

            for (int i = 0; i < 9; i+= 1)
            {
                 randomNumToId += rnd.Next(0, 10);
            }

            return ContinentDigit + "-" + randomNumToId;
        }

        public string GenerateCodeNum()
        {
            string randomNumToId = "";

            for (int i = 0; i < 9; i += 1)
            {
                randomNumToId += rnd.Next(0, 10);
            }

            return randomNumToId;
        }


        //Listas de pokémon
        public SinglePokemon[] Team() //Creamos una lista con los posibles rivales en el combate
        {
            SinglePokemon[] bag = new SinglePokemon[6];
            return bag;
        }        
        
        public SinglePokemon[][] Cases()
        {
            SinglePokemon[][] array = new SinglePokemon[32][];
            for (int i = 0; i < array.Length; i += 1)
            {
                array[i] = new SinglePokemon[30];
            }
            return array;
        }
    }
}
