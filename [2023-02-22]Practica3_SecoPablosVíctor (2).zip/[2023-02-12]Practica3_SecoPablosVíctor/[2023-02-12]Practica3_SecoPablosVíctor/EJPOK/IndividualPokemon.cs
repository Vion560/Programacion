﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJPOK
{
    public class IndividualPokemon
    {
        SpeciePokemon typespecie;
        Random randomvalue = new Random();
        string gender; //Esta variable se asocia con el género
        string nickname; //Esta variable se asocia con el mote del pokemon 
        bool catchedpok; //Esta variable se asocia con si ha sido o no capturado el pokémon
        string eo; //Esta variable corresponde al código del entrenador el cual lo capturo.
        public IndividualPokemon() { }
        public IndividualPokemon(SpeciePokemon specie)
        {
            this.typespecie = specie;
            this.gender = WhichGender();
            this.catchedpok = false;
        }
        public string WhichGender() //para k sea macho hembra o hembre 
        {
            int num = randomvalue.Next(1, 3);
            switch (num)
            {
                case 1:
                    return "Hembra";
                case 2:
                    return "Macho";
                default:
                    return "";
            }
        }
        public static SpeciePokemon[] starter()
        {
            SpeciePokemon[] starter = new SpeciePokemon[3];
            starter[0] = new SpeciePokemon("Charmander", 1,1, 39, 39, 52, 39, 65);
            starter[1] = new SpeciePokemon("Bulbasaur", 2,2, 45, 45, 49, 49, 45);
            starter[2] = new SpeciePokemon("Squirtle", 3,3, 44, 44, 48, 65, 43);
            return starter;
        }
        public static SpeciePokemon[] EnemyPok()
        {
            SpeciePokemon[] enemypok = new SpeciePokemon[7];
            enemypok[0] = new SpeciePokemon("Pidgey", 16,16, 40, 40, 45, 40, 56);
            enemypok[1] = new SpeciePokemon("Caterpie", 10,10, 45, 45, 30, 35, 45);
            enemypok[2] = new SpeciePokemon("Pikachu", 25,25, 35, 35, 55, 40, 90);
            enemypok[3] = new SpeciePokemon("Nidoran♀", 29,29, 55, 55, 47, 52, 41);
            enemypok[4] = new SpeciePokemon("Nidoran♂", 32,32, 46, 46, 57, 40, 50);
            enemypok[5] = new SpeciePokemon("Weedle", 13,13, 40, 40, 35, 30, 50);
            enemypok[6] = new SpeciePokemon("Ivysaur", 2,2, 60, 60, 62, 63, 60);
            return enemypok;
        }
        public static SpeciePokemon[] team()
        {
            int date;
            SpeciePokemon[] mypoks = new SpeciePokemon[6];
            return mypoks;
        }
        public void SetCathedPok()
        {
            catchedpok = true;
        }
        public void SetPokName(string name)
        {
            nickname = name;
        }
        public string GetName()
        {
            return typespecie.GetName();
        }
        public int GetActualHp()
        {
            return typespecie.GetActualHp();
        }
        public void SetActualHp(int act)
        {
            typespecie.SetActualHp(act);
        }
        public int GetSpeed()
        {
            return typespecie.GetSpeed();
        }
        public void SetSpeed(int speed)
        {
            typespecie.SetSpeed(speed);
        }
        public int GetRatioCapture()
        {
            return typespecie.GetRatioCapture();
        }
        public void SetRatioCapture(int rat)
        {
            typespecie.SetRatioCapture(rat);
        }
        public int GetAttack()
        {
            return typespecie.GetAttack();
        }
        public void SetAttack(int att)
        {
            typespecie.SetAttack(att);
        }
        public int GetDefense()
        {
            return typespecie.GetDefense();
        }
        public void SetDefense(int def)
        {
            typespecie.SetDefense(def);
        }
        public int GetMaxHp()
        {
            return typespecie.GetMaxHp();
        }
        public bool GetPokCatched()
        {
            return catchedpok;
        }
        public string GetPokGender()
        {
            return gender;
        }
        public string GetPokName()
        {
            return nickname;
        }
        public IndividualPokemon Bulbasaur()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Bulbasaur", 1, 45, 45, 49, 49, 45, 45);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Ivysaur()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Ivysaur", 2, 60, 60, 62, 63, 60, 45);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Venusaur()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Venusaur", 3, 80, 80, 82, 83, 80, 45);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Charmander()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Charmander", 4, 39, 39, 52, 43, 65, 45);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Charmeleon()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Charmeleon", 5, 58, 58, 64, 58, 80, 45);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Charizard()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Charizard", 6, 78, 78, 84, 78, 100, 45);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Squirtle()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Squirtle", 7, 44, 44, 48, 65, 43, 45);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Wartortle()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Wartortle ", 8, 59, 59, 63, 80, 58, 45);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Blastoise()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Blastoise ", 9, 79, 79, 83, 100, 78, 45);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Caterpie()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Caterpie", 10, 45, 45, 30, 35, 45, 255);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Metapod()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Metapod", 11, 50, 50, 20, 55, 30, 120);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Butterfree()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Butterfree", 12, 60, 60, 45, 50, 70, 45);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Weedle()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Weedle", 13, 40, 40, 35, 30, 50, 255);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Kakuna()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Kakuna", 14, 45, 45, 25, 50, 35, 120);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Beedrill()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Beedrill", 15, 65, 65, 90, 40, 75, 45);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Pidgey()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Pidgey", 16, 40, 40, 45, 40, 56, 255);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Pidgeotto()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Pidgeotto", 17, 63, 63, 60, 55, 71, 120);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Pidgeot()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Pidgeot", 18, 83, 83, 80, 75, 101, 45);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Rattata()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Rattata", 19, 30, 30, 56, 35, 72, 255);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Raticate()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Raticate", 20, 55, 55, 81, 60, 97, 127);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Spearow()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Spearow", 21, 40, 40, 60, 30, 70, 255);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
        public IndividualPokemon Fearow()
        {
            SpeciePokemon typespecie = new SpeciePokemon("Fearow", 22, 65, 65, 90, 65, 100, 90);
            IndividualPokemon single = new IndividualPokemon(typespecie);
            return single;
        }
    }
}
