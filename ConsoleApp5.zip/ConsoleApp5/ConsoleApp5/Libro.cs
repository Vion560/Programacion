﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Libro
    {
        int isbn;
        string author;
        int numberpage;
        int lenddate;
        int returndate;

        public int lend(int day)
        {
            this.lenddate = day;
            return lenddate;
        }
        public int returnd(int day)
        {
            this.returndate = day;
            return returndate;
        }
        public string tostring()
        {
            return "con el ISBN: " + isbn + " ,del autor " + author + ", " + numberpage + " páginas " + "dejado el día " + lenddate + " devuelto el día" + returndate;
        }
        public Libro(int isbn, string author, int numberpage, int lenddate, int returndate)
        {
            this.isbn = isbn;
            this.author = author;
            this.numberpage = numberpage;
            this.lenddate = lenddate;
            this.returndate = returndate;
        }
        public Libro()
        {
            lenddate = 0;
            returndate = 0;
            author = "Nadie";
            isbn = 0;
            numberpage = 0;
        }
        public int GetIsbn()
        { 
            return isbn; 
        }
        public void SetIsbn(int isbn)
        {
            this.isbn = isbn;
        }
        public string GetAuthor()
        {
            return author;
        }
        public void SetAuthor(string author)
        {
            this.author = author;
        }
        public int GetPage()
        {
            return numberpage;
        }
        public void SetPage(int page)
        {
            this.numberpage = page;
        }
        public int GetLendDate()
        {
            return lenddate;
        }
        public void SetLendDate(int date)
        {
            this.lenddate = date;
        }
        public int GetReturnDate()
        {
            return returndate;
        }
        public void SetReturnDate(int date)
        {
            this.returndate = date;
        }
    }
}
