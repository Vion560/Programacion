﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Date
    {
        int year;
        int month;
        int day;

        public Date(int year, int month, int day)
        {
            this.year = year;
            this.month = month;
            this.day = day;
        }
        public Date()
        {
            year = 0;
            month = 0; 
            day = 0;
        }
        public int GetYear()
        {
            return year;
        }
        public void SetYear(int year)
        {
            this.year = year;
        }
        public int GetMonth()
        {
            return month;
        }
        public void SetMonth(int month)
        {
            this.month = month;
        }
        public int GetDay()
        {
            return day;
        }
        public void SetDay(int day)
        {
            this.day = day;
        }
        public string toString()
        {
            return "estamos en el año: " + year + " en el mes" + month + " y día" + day;
        }
        public int ChangeDay(int day)
        {
            int day2;
            day2 = day + 1;
            return day2;
        }
        public bool CheckDate()
        {
            if(year <=2022 && month <=12)
            {    
                return true;
            }
            else
            {
                if (year <=2022 && day <=31)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }
    }
}
