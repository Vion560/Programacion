﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Counter
    {
        int increase;
        int decrease;

        public Counter(int increase, int decrease)
        {
            this.increase = increase;
            this.decrease = decrease;
        }
        public Counter()
        {
            increase = 0;
            decrease = 0;
        }
        public int GetIncrease()
        { 
            return increase; 
        }
        public void SetIncrease(int increase)
        {
            this.increase = increase;
        }
        public int GetDecrease()
        {
            return decrease;
        }
        public void SetDecrease(int decrease)
        {
            this.decrease = decrease;
        }

    }
}
