﻿using System;

namespace ejarrays
{
    class Program
    {
        static void Main(string[] args)
        {
            array();
        }
        //crear un array aleatorio de ints, imprime un menu con 8 opciones;1:invoca funcion k recibe array y devuulve numero de 0 que hay;2:devuelve resultado sumar numero pares.
        //3:recibe array y un entero y devuelve numero de veces que aparece ese valor en el array;4: recibe 1 array y 2 valores y sustituye el 1valor por el 2;
        //5:recibe array y 2 valores y representan posiciones en el array;6: recibe array y lo va a invertir;7: rota el array hacia la izquierda;8:fin del program.
        public static void array()
        {
            Random r = new Random();
            int[] numRandom = new int[10];
            int maxnum = 10;
            int minnum = 0;
            int option;
            for (int i = 0; i < numRandom.Length; i++)
            {
                numRandom[i] = r.Next(minnum,maxnum);
                Console.Write(numRandom[i] + "  ");
            }
            Console.WriteLine("Elige una opción:");
            Console.WriteLine("Opción 1: ");
            Console.WriteLine("Opción 2: ");
            Console.WriteLine("Opción 3: ");
            Console.WriteLine("Opción 4: ");
            Console.WriteLine("Opción 5: ");
            Console.WriteLine("Opción 6: ");
            Console.WriteLine("Opción 7: ");
            Console.WriteLine("Opción 8: ");
            option = Convert.ToInt32(Console.ReadLine());
            switch(option)
            {
                case 1:
                    int countZeros = muchnum(numRandom); //SIEMPRE CREAR VARIABLE PARA UNA FUNCION QUE NO DEVUELVA VOID.
                    Console.WriteLine(countZeros);
                    break;
                case 2:
                    int sumPairs = pluspair(numRandom);
                    Console.WriteLine(sumPairs);
                    break;
                case 3:
                    int numrep = repeatnum(numRandom, 3);
                    Console.WriteLine(numrep);
                    break;
                case 4:
                    break;
                case 5:
                    break;
                case 6:
                    break;
                case 7:
                    break;
                case 8:
                    break;
            }
        }
        static int muchnum(int[] v)
        {
            int acum = 0;
            for (int i = 0; i < v.Length; ++i)
            {
                
                if (v[i] == 0)
                {
                    acum = ++acum;
                }
            }
            return acum;
        }
        static int pluspair(int[] v)
        {
            int acum = 0;
            for (int i = 0; i < v.Length; ++i)
            {
                if (v[i] % 2 == 0)
                {
                    acum = acum + v[i];
                }
            }
            return acum;
        }
        static int repeatnum(int[] v, int num)
        {
            int acum = 0;
            for (int i = 0; i < v.Length; ++i)
            {
                if(num == v[i])
                {
                    acum = ++acum;
                }
            }
            return acum;
        }
    }
}
