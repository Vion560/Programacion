﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon
{
	class IO
	{
        //Función para que el texto de presentación esté en color verde
        public void ThreadColorsRed(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                }
            }
        }
        public void ThreadColorsGreen(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                }
            }
        }
        public void ThreadColorsWhite(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
        }
        public void ThreadColorsBlue(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                }
            }
        }
    }
}
