﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon
{
	public class IO
	{
        //int[] numrandom = new int[5];
        //int maxhp;
        //int actualhp;
        //int attack;
        //int defense;
        //int speed;


        //Función para que el texto de presentación esté en color verde
        public void ThreadColorsRed(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                }
            }
        }
        public void ThreadColorsGreen(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                }
            }
        }
        public void ThreadColorsWhite(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(15);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
        }
        public void ThreadColorsBlue(string text)
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(100);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                }
            }
        }
        public string ChoosePok()
        {
            string isstring;
            isstring = Console.ReadLine();
            return "Has elegido " + isstring;
        }
        public void Read()
        {
            Console.ReadLine();
        }
        public void AskNumber(double num)
        {
            
        }
        public void AskLetter(char lett)
        {

        }
        public int RandomValues(int a, int b)
        {
            Random random = new Random();
            int number = random.Next(a, b);
            return number;
        }
        public int IntToString()
        {
            int number = int.Parse(Console.ReadLine());
            return number;
        }
    }
}
