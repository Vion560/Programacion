﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon
{
	class Pokemon
	{
		string speciename;
		int specienumber;
		float ratiocapture;
		bool male;
        int maxhp;
        int actualhp;
        int attack;
        int defense;
        int speed;
        int[] pokemon = new int[6];
	}
}
