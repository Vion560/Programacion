﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace EJPOK
{
    public class Game
    {
        public void Run()
        {
            Teacher();
            ChooseStarter();
            ShowMenu();
            MainMenu();
        }
        Random randomvalue = new Random();
        int[] numrandom = new int[5];
        SpeciePokemon[] initials = IndividualPokemon.starter(); //copia los iniciales
        SpeciePokemon[] copybag = IndividualPokemon.bag(); //copia el array
        SpeciePokemon[] enemypok = IndividualPokemon.EnemyPok();
        IO iO;
        int maxhp;
        int specienum;
        int actualhp;
        int attack;
        int defense;
        int speed;
        int damage;
        int crit;
        float rcm;
        float ratiocapture;
        //double ag;
        
        public Game(IO iO)
        {
            this.iO = iO;
        }

        public void Teacher() //Esta es la opción para que el profe te de la bienvenida
        {
            iO.ThreadColorsWhite("Hola, soy el profesor Ciprés. Bienvenido al mundo pokemon donde encontrarás muchos tipos de pokemon.");
            iO.ThreadColorsWhite("Para empezar tienes que elegir entre uno de estos tres pokemon y el que eligas te lo puedes quedar y puedas empezar con él tu aventura\n");
            iO.ThreadColorsRed(" Opción 1: Charmander.\n");
            iO.ThreadColorsGreen(" Opción 2: Bulbasaur.\n");
            iO.ThreadColorsBlue(" Opción 3: Squirtle.\n");
            iO.ThreadColorsWhite(" Elige un número\n");
            Console.ForegroundColor = ConsoleColor.White;

        }
        public void NoTeacher() //Opción en la que directamente empiezas con un pokemon aleatorio
        {
            Console.WriteLine("Elige un pokemón: \n");
            iO.ThreadColorsRed(" Opción 1: Charmander.\n");
            iO.ThreadColorsGreen(" Opción 2: Bulbasaur.\n");
            iO.ThreadColorsBlue(" Opción 3: Squirtle.\n");
            iO.ThreadColorsWhite("\n");
        }
        public Game() //Genera valores aleatorios al pokemon
        {
            numrandom[0] = this.maxhp;
            numrandom[0] = randomvalue.Next(35, 45);
            numrandom[1] = this.actualhp;
            numrandom[2] = this.attack;
            numrandom[2] = randomvalue.Next(4, 8);
            numrandom[3] = this.defense;
            numrandom[3] = randomvalue.Next(3, 6);
            numrandom[4] = this.speed;
            numrandom[4] = randomvalue.Next(6, 10);
        }
        public void ChooseStarter() //elige el starter y lo guarda en la bolsa
        {
            int num = iO.AskNumber();
            switch (num)
            {
                case 1:
                    copybag[0] = initials[0];
                    iO.Write("Has elegido a Charmander!");
                    break;
                case 2:
                    copybag[0] = initials[1];
                    iO.Write("Has elegido a Bulbasaur!");
                    break;
                case 3:
                    copybag[0] = initials[2];
                    iO.Write("Has elegido a Squirtle!");
                    break;
                default:
                    iO.Write("Por favor eliga una opción correcta");
                    ChooseStarter();
                    break;
            }
        }
        public void ShowMenu() //muestra el menú por pantalla
        {
            iO.Write("Menu:");
            iO.Write("	Pulsa 1 para ver los datos de tus pokemon");
            iO.Write("	Pulsa 2 para Combatir");
            iO.Write("	Pulsa 3 centro pokemon");
            iO.Write("	Pulsa 4 para salir");
        }
        public void MainMenu()
        {
            int opcion = iO.AskNumber();
            switch (opcion)
            {
                case 1:
                    ShowPokemons();
                    ExitToMenu();
                    break;
                case 2:
                    iO.Write("	Pulsa 2 para Combatir");
                    Fight();
                    break;
                case 3:
                    PokCenter();
                    iO.Write("	Pulsa 3 centro pokemon");
                    ExitToMenu();
                    break;
                case 4:
                    iO.Write("Escriba 1 para cerrar el juego definitivamente o 2 para volver al menú");
                    FinishGame();
                    break;

            }
        }
        public void FinishGame() //opción para cerrar el juego o no
        {
            int num = iO.AskNumber();         
            switch (num)
            {
                case 1: //para cerrar el juego
                    Environment.Exit(0);
                    break;
                case 2: //volver al menu
                    ExitToMenu();
                    break;
            }
        }
        public void ShowPokemons() //muestra los datos de tus pokemons de la bolsa
        {
            for (int i = 0; i < copybag.Length; i++)
            {
                if (copybag[i] != null)
                { 
                iO.Write("Tus pokemon son: " + copybag[i].GetName() + ",con " + copybag[i].GetMaxHp() + " de vidamáxima, " + copybag[i].GetActualHp()+" de vida actual, " +copybag[i].GetAttack() + " de ataque, " + copybag[i].GetDefense() + " de defensa, " + copybag[i].GetSpeed() + " de velocidad. ");               
                }
            }
        }

        public void Fight() //Combate
        { 
            do
            {
                    //iO.WriteInt(copybag[i].GetMaxHp());
                    //iO.WriteInt(enemypok[i].GetMaxHp());
                    //iO.WriteInt(copybag[i].GetSpeed());
                    //iO.WriteInt(enemypok[i].GetSpeed());
                    iO.Write("Pulsa 1 para Atacar");             
                    iO.Write("Pulsa 2 para cambiar pokemon");           
                    iO.Write("Pulsa 3 para Capturar");
                    iO.Write("Pulsa 4 para Volver al menú");
                    int num = iO.AskNumber();
                    switch (num)
                    {
                        case 1: //atacar
                            if (copybag[0].GetSpeed() >= enemypok[0].GetSpeed())
                            {
                                int enemy = enemypok[0].GetActualHp();
                                int ally = copybag[0].GetActualHp();
                                do 
                                {
                                if (enemy <= 0)
                                {
                                    Console.WriteLine("El pokemon enemigo ha sido derrotado");
                                    copybag[0].SetActualHp(ally);
                                    ExitToMenu();
                                    break;
                                }
                                if (ally <= 0)
                                {
                                    Console.WriteLine("Tu pokemon ha sido derrotado :(");
                                    copybag[0].SetActualHp(0);
                                    ExitToMenu();
                                    break;
                                }
                                iO.Write("Pulsa el número 1 si quieres volver a atacar, 2 para cambiar pokemon, 3 para capturar");
                                int number = iO.AskNumber();
                                switch(number)
                                {
                                    case 1:
                                        enemy = enemy - GetDamage();
                                        iO.Write("El pokemon enemigo tiene " + enemy + " puntos de vida");
                                        break;
                                    case 2:
                                        ShowPokemons();
                                        break;
                                }
                                ally = ally - GetDamage();
                                iO.Write("Tu pokemon tiene " + ally + " puntos de vida");                               
            }
            while (copybag[0].GetActualHp() > 0 || enemypok[0].GetActualHp() > 0);                               
                            }
                            else
                            {
                                int ally;
                                ally = copybag[0].GetActualHp();
                                int enemy;
                                enemy = enemypok[0].GetActualHp();
                                iO.WriteInt(enemy);
                                iO.WriteInt(ally);
                                iO.Write("Tu pokemon tiene " + ally + " puntos de vida");
                                iO.Write("El pokemon enemigo tiene " + enemy + " puntos de vida");
                                do
                                {
                                    if (enemy <= 0)
                                    {
                                        Console.WriteLine("El pokemon enemigo ha sido derrotado");
                                        copybag[0].SetActualHp(ally);
                                        ExitToMenu();
                                    break;
                                    }
                                    if (ally <= 0)
                                    {
                                        Console.WriteLine("Tu pokemon ha sido derrotado :(");
                                        copybag[0].SetActualHp(0);
                                        ExitToMenu();
                                    break;
                                    }
                                    ally = ally - GetDamage();
                                    iO.Write("Tu pokemon tiene " + ally + " puntos de vida");
                                    iO.Write("Pulsa el número 1 si quieres volver a atacar, 2 para cambiar pokemon, 3 para capturar");
                                    int number = iO.AskNumber();
                                    switch (number)
                                    {
                                    case 1:
                                        enemy = enemy - GetDamage();
                                        iO.Write("El pokemon enemigo tiene " + enemy + " puntos de vida");
                                        break;
                                    }                                                                      
                                }
                            while (copybag[0].GetActualHp() > 0 || enemypok[0].GetActualHp() > 0);
                        }
                        break;
                        case 2: //Cambiar pokemon
                            iO.Write("Estos son los pokemon que tienes para cambiar");
                            ShowPokemons();                           
                            break;
                        case 3: //capturar
                            Capture();
                            break;
                        case 4: //escapar
                            ExitToMenu();
                            break;
                    }
            }
            while (copybag[0].GetActualHp() > 0 || enemypok[0].GetActualHp() > 0);
        }
        public void PokCenter() //Centro Pokemon
        {
            iO.WritePink(" Bienvenido al centro pokemon, aquí restauraremos al completo la vida de todos tus pokemon\n");
            for (int i = 0; i <= copybag.Length; i++)
            {
                if (copybag[i] != null)
                {
                    iO.Write("Tu pokemon tiene: "+ copybag[i].GetActualHp()+" de vida actual");
                    copybag[i].SetActualHp(copybag[i].GetMaxHp());
                    iO.Write("Tu pokemon se ha curado y vuelve a tener "+copybag[i].GetMaxHp()+" de vida máxima");
                    iO.ThreadColorsWhite("\n");
                }
                else
                {
                    iO.Write("Tus pokemon ya estan curados");
                    ExitToMenu();
                }
            }
        }        
        public int GetDamage()
        {
            double damage = 0;
            double rand = 0;
            do
            {
                rand = randomvalue.NextDouble();
            } while (rand > 1 || rand < 0.85);
            damage = (((2 * 50 * (copybag[0].GetAttack() / enemypok[0].GetDefense())) / (50)) + 2) * rand * Critic();
            return (int)damage;
        }
        public double Critic()
        {
            int crit = randomvalue.Next(0, 25);
            if (crit == 0)
            {
                return 1.5;
            }
            else
            {
                return 1;
            }
        }
        public void Capture()
        {
            ratiocapture = randomvalue.Next(0, 256);
            rcm = ((3 * enemypok[0].GetMaxHp() - 2 * enemypok[0].GetActualHp()) * 4096 * ratiocapture / (3 * enemypok[0].GetMaxHp()));
            double ag = (65536 / (Math.Pow((255 / rcm), 0.1875)));
            int comparednumber = randomvalue.Next(0, 65536);
            for (int i = 0; i < 4; i++)
            {
                if (comparednumber >= ag)
                {
                    iO.Write("Oh! El pokemon ha escapado!");
                }
                else
                {
                    iO.WriteInt(i);
                }
            }
        }
        public void ExitToMenu()
        {
            ShowMenu();
            MainMenu();
        }
    }
}
