﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJPOK
{
    public class IO
    {
        public void ThreadColorsRed(string text) //texto en rojo
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(0);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                }
            }
        }
        public void ThreadColorsGreen(string text) //texto en verde
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(0);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                }
            }
        }
        public void ThreadColorsWhite(string text) //texto en blanco
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(0);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
        }
        public void WritePink(string text) //texto en blanco
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(0);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                }
            }
        }
        public void ThreadColorsBlue(string text) //texto en azul
        {
            for (int i = 0; i < text.Length; i = i + 1)
            {
                Thread.Sleep(0);
                Console.Write(text[i]);
                if (i % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                }
            }
        }
        public string ChoosePok()
        {
            int pok;
            IO io = new IO();
            SpeciePokemon[] starter = IndividualPokemon.starter();
            pok = int.Parse(Console.ReadLine());
            if (pok == 1)
            {
                return "Has elegido a " + starter[0].GetName() + " con " + starter[0].GetMaxHp() + " de vida, " + starter[0].GetAttack() + " de ataque, " + starter[0].GetDefense() + " de defensa, " + starter[0].GetSpeed() + " de velocidad.";
                
            }
            if (pok == 2)
            {
                return "Has elegido a " + starter[1].GetName() + " con " + starter[1].GetMaxHp() + " de vida, " + starter[1].GetAttack() + " de ataque, " + starter[1].GetDefense() + " de defensa, " + starter[1].GetSpeed() + " de velocidad.";
            }
            if (pok == 3)
            {
                return "Has elegido a " + starter[2].GetName() + " con " + starter[2].GetMaxHp() + " de vida, " + starter[2].GetAttack() + " de ataque, " + starter[2].GetDefense() + " de defensa, " + starter[2].GetSpeed() + " de velocidad.";
            }
            else
            {
                return "Como no has elegido a ninguno elegimos a " + starter[0].GetName() + " con " + starter[0].GetMaxHp() + " de vida, " + starter[0].GetAttack() + " de ataque, " + starter[0].GetDefense() + " de defensa, " + starter[0].GetSpeed() + " de velocidad.";
            }
        }    
        
        public void Write(string a) //Mostrar por pantalla
        {
            Console.WriteLine(a);
        }
        public Array[] WriteArray(Array[] a) //Mostrar por pantalla
        {
            return a;
        }
        public string Read() //Lee string
        {
            return Console.ReadLine();
        }
        public int AskNumber() //lee numero
        {
            return int.Parse(Console.ReadLine());
        }
        public char AskLetter(char lett) //Pide Letra
        {
            Console.WriteLine("Dame una letra");
            return lett;
        }
        public int RandomValues(int a, int b)
        {
            Random random = new Random();
            int number = random.Next(a, b);
            return number;
        }
        public int IntToString() //Pasa a int
        {
            int number = int.Parse(Console.ReadLine());
            return number;
        }
        public int WriteInt(int a) //Escribe int
        {
            return a;
        }
    }
}
