﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJPOK
{
    public class SpeciePokemon
    {
        int[] numrandom = new int[5];
        int maxhp;
        int actualhp;
        int attack;
        int defense;
        int speed;
        string name;
        float ratiocapture;
        bool male;
        int id;

        public SpeciePokemon(string name,int id, int maxhp, int actualhp, int att, int def, int speed) //Le das tu los valores al pokemon
        {
            this.name = name;
            this.id = id;
            this.maxhp = maxhp;
            this.actualhp = actualhp;
            this.attack = att;
            this.defense = def;
            this.speed = speed;
        }
        public SpeciePokemon() //Le das tu los valores al pokemon
        {
            name = "POKEMON";
            id = 0;
            maxhp= 20;
            actualhp = 20;
            attack = 20;
            defense = 20;
            speed = 20;
        }
        public string GetName()
        {
            return name;
        }
        public void SetName(string name)
        {
            this.name = name;
        }
        public int GetActualHp() //Devuelve el valor de la vida actual
        {
            return actualhp;
        } 
        public void SetActualHp(int actualhp) //Da valor a la vida actual
        {
            this.actualhp = actualhp;
        } 
        public int GetMaxHp() //Devuelve el valor de la vida máxima
        {
            return maxhp;
        } 
        public void SetMaxHp(int maxhp) //Da valor a la vida máxima
        {
            this.maxhp = maxhp;
        } 
        public int GetAttack()  //Devuelve el valor de el ataque
        {
            return attack;
        } 
        public void SetAttack(int att) //Da valor a el ataque
        {
            this.attack = att;
        } 
        public int GetDefense() //Devuelve el valor de la defensa
        {
            return defense;
        } 
        public void SetDefense(int def) //Da valor a la defensa
        {
            this.defense = def;
        }
        public int GetSpeed() //Devuelve el valor de la velocidad
        {
            return speed;
        } 
        public void SetSpeed(int speed) //Da valor a la velocidad
        {
            this.speed = speed;
        } 
    }
}
