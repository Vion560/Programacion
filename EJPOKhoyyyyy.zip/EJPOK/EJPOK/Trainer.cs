﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJPOK
{
    class Trainer
    {
        string UserName;
        string Gender;
        int id;
        int SecretNumber;
        int pokedolars;
        int pokemillas;
        int battlepoints;
        double gametime;
        SpeciePokemon[] MyTeam = new SpeciePokemon[6];

    }
}
